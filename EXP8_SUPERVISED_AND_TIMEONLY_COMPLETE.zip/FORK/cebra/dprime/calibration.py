"""Per-dataset calibration of the d′ budget ε* (Section 5 of ``DPRIME_DESIGN.md``).

Implements the research note's "Choosing ε per dataset: a calibration protocol,
not a number": three independent criteria, all in d′ units and all computed
from clean data,

1. ``ε_JND = 1``, "the ideal-observer threshold (sweep 0.5–3 for curves)"
   (:py:data:`EPS_JND`, :py:func:`ideal_observer_accuracy`);
2. ``ε_NN``: "for each clean trial, the whitened distance to its nearest
   same-class, same-subject neighbour; take a low quantile (e.g., the 10th)"
   (:py:func:`make_classes`, :py:func:`nearest_neighbour_dprime`,
   :py:func:`eps_nn`, :py:func:`per_index_eps_nn`);
3. ``ε_det``: "the largest ε at which a detector trained to separate clean from
   adversarial trials (plus a clean-only anomaly detector such as an
   autoencoder) stays ≤ 0.55 AUC on held-out [data]"
   (:py:class:`ConvDetector`, :py:class:`ConvAutoencoder`, :py:func:`auc`,
   :py:func:`detection_curve`, :py:func:`eps_det_from_curve`);

then "take ε* = min of the three" (:py:func:`epsilon_star`). After training,
"the ratio median(d′_boundary)/ε* is a dataset-intrinsic robustness margin"
(:py:func:`robustness_margin`).

Conventions (Section 0 of the design): a window batch is a ``(B, C, T)``
tensor and a recording a ``(n_time, C)`` array. The window of time index ``t``
is ``neural[t - offset_left : t + offset_right]`` transposed to ``(C, T)``,
exactly like :py:meth:`cebra.data.base.Dataset.expand_index`, and its label is
the label at ``t``. Collaborators are duck-typed and no other ``cebra.dprime``
module is imported: a *noise model* is any object with a linear
``whiten(delta: (B, C, T)) -> (B, C, T)`` (d′ of ``δ`` = ``‖whiten(δ)‖₂``),
and an *attack* is any callable ``attack_fn(x, eps, kind) -> x_adv``.
Calibration statistics are returned as numpy arrays / Python floats.
"""

import math
import warnings
from typing import (Callable, Dict, Iterator, Mapping, Optional, Sequence,
                    Tuple, Union)

import numpy as np
import numpy.typing as npt
import scipy.special
import scipy.stats
import sklearn.cluster
import torch
import torch.nn.functional as F
from torch import nn

__all__ = [
    "EPS_JND",
    "ATTACK_KINDS",
    "make_classes",
    "valid_indices",
    "whitened_windows",
    "nearest_neighbour_dprime",
    "eps_nn",
    "per_index_eps_nn",
    "ConvDetector",
    "ConvAutoencoder",
    "auc",
    "detection_curve",
    "eps_det_from_curve",
    "eps_det_crossing",
    "eps_energy_detector",
    "epsilon_star",
    "robustness_margin",
    "ideal_observer_accuracy",
]

#: Criterion 1: "ε_JND = 1, the ideal-observer threshold" (one just-noticeable
#: difference in d′ units; configurable by passing another value).
EPS_JND: float = 1.0

#: Attack families the detectors are trained on ("detectors overfit to one
#: attack, so train them across attacks"); ``"dprime"`` is also the held-out
#: evaluation attack.
ATTACK_KINDS: Tuple[str, ...] = ("dprime", "colored_noise", "linf")

ArrayLike = Union[npt.NDArray, torch.Tensor]

# k-means for continuous labels is fit on at most this many time points.
_KMEANS_MAX_FIT = 100_000
# Windows scored per forward pass when evaluating the detectors.
_SCORE_CHUNK = 2048


def _to_numpy(array: ArrayLike) -> np.ndarray:
    """Return ``array`` as a numpy array (tensors are detached and moved)."""
    if isinstance(array, torch.Tensor):
        return array.detach().cpu().numpy()
    return np.asarray(array)


def _check_offsets(offset_left: int, offset_right: int) -> None:
    """Validate a CEBRA offset (``left >= 0``, ``right >= 1``)."""
    if offset_left < 0 or offset_right < 1:
        raise ValueError(
            "Expected offset_left >= 0 and offset_right >= 1 (CEBRA Offset "
            f"convention), got ({offset_left}, {offset_right}).")


# ---------------------------------------------------------------------------
# Classes and windows
# ---------------------------------------------------------------------------


def make_classes(labels: Optional[ArrayLike],
                 label_kind: Optional[str] = None,
                 n_classes: int = 8,
                 seed: int = 0) -> Optional[np.ndarray]:
    """Class ids that define the "same-class" neighbours of ε_NN.

    Discrete labels are used as they are. Continuous labels have no classes,
    so they are clustered with k-means on the standardised label columns
    (zero mean, unit SD per column, so the partition does not depend on the
    label units); the clusters play the role of classes.

    Args:
        labels: ``(n_time,)`` discrete labels, ``(n_time,)`` or
            ``(n_time, d)`` continuous labels, or None.
        label_kind: ``"discrete"``, ``"continuous"``, or None / ``"auto"`` to
            infer it from the dtype (integer or bool: discrete).
        n_classes: Number of k-means clusters for continuous labels; reduced to
            the number of distinct label rows if that is smaller.
        seed: Seed of the k-means initialisation (and of the subsample used to
            fit it when there are more than 100 000 time points).

    Returns:
        ``(n_time,)`` int64 class ids, or None if ``labels`` is None. For
        continuous labels the ids are ``0 .. min(n_classes, #distinct) - 1``.
    """
    if labels is None:
        return None
    if n_classes < 1:
        raise ValueError(f"n_classes must be >= 1, got {n_classes}.")
    array = _to_numpy(labels)
    if array.ndim == 0 or array.ndim > 2:
        raise ValueError(
            f"labels must be (n_time,) or (n_time, d), got {array.shape}.")
    if label_kind in (None, "auto"):
        is_discrete = (np.issubdtype(array.dtype, np.integer) or
                       array.dtype == np.bool_)
        label_kind = "discrete" if is_discrete else "continuous"

    if label_kind == "discrete":
        if array.ndim == 2 and array.shape[1] == 1:
            array = array[:, 0]
        if array.ndim == 2:
            # Several discrete columns: one class per distinct combination.
            _, inverse = np.unique(array, axis=0, return_inverse=True)
            return inverse.reshape(-1).astype(np.int64)
        if np.issubdtype(array.dtype, np.floating):
            if not np.all(np.isfinite(array)):
                raise ValueError("Discrete labels must be finite.")
            if not np.all(array == np.round(array)):
                _, inverse = np.unique(array, return_inverse=True)
                return inverse.astype(np.int64)
        return array.astype(np.int64)

    if label_kind != "continuous":
        raise ValueError("label_kind must be 'discrete', 'continuous', 'auto' "
                         f"or None, got {label_kind!r}.")
    values = array.reshape(len(array), -1).astype(np.float64)
    if not np.all(np.isfinite(values)):
        raise ValueError("Continuous labels must be finite.")
    std = values.std(axis=0)
    std[std <= 0] = 1.0
    values = (values - values.mean(axis=0)) / std

    rng = np.random.default_rng(seed)
    fit_values = values
    if len(values) > _KMEANS_MAX_FIT:
        fit_values = values[rng.choice(len(values), _KMEANS_MAX_FIT, False)]
    n_clusters = min(n_classes, len(np.unique(fit_values, axis=0)))
    if n_clusters <= 1:
        return np.zeros(len(values), dtype=np.int64)
    kmeans = sklearn.cluster.KMeans(n_clusters=n_clusters,
                                    n_init=4,
                                    random_state=seed)
    kmeans.fit(fit_values)
    return kmeans.predict(values).astype(np.int64)


def valid_indices(n_time: int, offset_left: int,
                  offset_right: int) -> np.ndarray:
    """Time indices whose window ``[t - left, t + right)`` lies in the recording.

    These are the fixed points of the clamp in
    :py:meth:`cebra.data.base.Dataset.expand_index`.

    Args:
        n_time: Number of time points of the recording.
        offset_left: Samples before ``t`` (``Offset.left``).
        offset_right: Samples from ``t`` on, ``t`` included (``Offset.right``).

    Returns:
        int64 array ``[left, left + 1, ..., n_time - right]`` (empty if the
        recording is shorter than one window).
    """
    _check_offsets(offset_left, offset_right)
    return np.arange(offset_left, n_time - offset_right + 1, dtype=np.int64)


def _check_window_indices(indices: ArrayLike, n_time: int, offset_left: int,
                          offset_right: int) -> np.ndarray:
    """Return ``indices`` as int64 numpy, raising if a window is incomplete."""
    _check_offsets(offset_left, offset_right)
    index = _to_numpy(indices).astype(np.int64).reshape(-1)
    if index.size and (index.min() < offset_left or
                       index.max() > n_time - offset_right):
        raise ValueError(
            "All indices need a full window: expected "
            f"{offset_left} <= t <= {n_time - offset_right}, got "
            f"[{index.min()}, {index.max()}].")
    return index


def _resolve_device(device, noise_model, neural) -> torch.device:
    """Explicit device, else the noise model's, else the recording's, else CPU."""
    if device is not None:
        return torch.device(device)
    model_device = getattr(noise_model, "device", None)
    if model_device is not None:
        return torch.device(model_device)
    if isinstance(neural, torch.Tensor):
        return neural.device
    return torch.device("cpu")


def _recording_tensor(neural: ArrayLike, device: torch.device) -> torch.Tensor:
    """The ``(n_time, C)`` recording as a float32 tensor on ``device``."""
    if isinstance(neural, torch.Tensor):
        recording = neural.detach()
    else:
        recording = torch.from_numpy(np.asarray(neural))
    recording = recording.to(device=device, dtype=torch.float32)
    if recording.ndim != 2:
        raise ValueError(
            f"neural must be a (n_time, C) recording, got {recording.shape}.")
    return recording


def _iter_whitened(recording: torch.Tensor, index: np.ndarray,
                   offset_left: int, offset_right: int, noise_model,
                   batch_size: int) -> Iterator[torch.Tensor]:
    """Yield ``(b, C*T)`` flattened whitened windows, ``batch_size`` at a time."""
    if batch_size < 1:
        raise ValueError(f"batch_size must be >= 1, got {batch_size}.")
    offsets = torch.arange(-offset_left, offset_right, device=recording.device)
    for start in range(0, len(index), batch_size):
        times = torch.as_tensor(index[start:start + batch_size],
                                device=recording.device)
        # (b, T, C) -> (b, C, T), the layout of CEBRA's batch.reference.
        windows = recording[times[:, None] + offsets[None, :]]
        windows = windows.transpose(1, 2).contiguous()
        white = noise_model.whiten(windows)
        yield white.reshape(len(times), -1).float()


def whitened_windows(neural: ArrayLike,
                     indices: ArrayLike,
                     offset_left: int,
                     offset_right: int,
                     noise_model,
                     batch_size: int = 512,
                     device: Optional[Union[str, torch.device]] = None
                    ) -> torch.Tensor:
    """Flattened whitened windows of a recording.

    Because ``whiten`` is linear, the Euclidean distance between two rows is
    the d′ of the difference of the two windows: ``‖W x_t − W x_t'‖₂ =
    ‖W (x_t − x_t')‖₂``.

    Args:
        neural: ``(n_time, C)`` recording (numpy or torch).
        indices: ``(M,)`` time indices, each with a full window.
        offset_left: Samples before ``t`` (``Offset.left``).
        offset_right: Samples from ``t`` on (``Offset.right``); the window
            length is ``T = offset_left + offset_right``.
        noise_model: Object with ``whiten(delta (B, C, T)) -> (B, C, T)``.
        batch_size: Windows whitened per call (bounds the peak memory).
        device: Where to compute; default: ``noise_model.device`` if the
            attribute exists, else the device of ``neural`` (CPU for numpy).

    Returns:
        ``(M, C*T)`` float32 tensor, row ``i`` = ``whiten(window(t_i))``
        flattened channel-major (``x.reshape(M, C*T)``).
    """
    device = _resolve_device(device, noise_model, neural)
    recording = _recording_tensor(neural, device)
    index = _check_window_indices(indices, recording.shape[0], offset_left,
                                  offset_right)
    with torch.no_grad():
        chunks = list(
            _iter_whitened(recording, index, offset_left, offset_right,
                           noise_model, batch_size))
    if not chunks:
        window_dim = recording.shape[1] * (offset_left + offset_right)
        return recording.new_zeros((0, window_dim))
    return torch.cat(chunks)


# ---------------------------------------------------------------------------
# Criterion 2: ε_NN
# ---------------------------------------------------------------------------


def _bank_indices(valid: np.ndarray, bank_size: Optional[int],
                  seed: int) -> np.ndarray:
    """Sorted uniform random subset (without replacement) of ``valid``."""
    if bank_size is None or bank_size >= len(valid):
        return valid.copy()
    if bank_size < 1:
        raise ValueError(f"bank_size must be >= 1 or None, got {bank_size}.")
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(valid, size=bank_size, replace=False))


def nearest_neighbour_dprime(
    neural: ArrayLike,
    noise_model,
    offset_left: int,
    offset_right: int,
    classes: Optional[ArrayLike] = None,
    query_indices: Optional[ArrayLike] = None,
    bank_size: Optional[int] = 2000,
    exclusion: Optional[int] = None,
    batch_size: int = 512,
    seed: int = 0,
    device: Optional[Union[str, torch.device]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Whitened (d′) distance of each window to its nearest same-class neighbour.

    "For each clean trial, the whitened distance to its nearest same-class,
    same-subject neighbour". The neighbours are searched in a bank of
    ``bank_size`` windows drawn uniformly at random (without replacement) from
    all valid windows, so every distance is an upper bound of the distance to
    the nearest neighbour in the whole recording (exact for
    ``bank_size=None``). Windows at ``|t − t'| < exclusion`` are not
    neighbours: by default ``exclusion`` is the window length, so a window
    never counts a window it overlaps with as a "natural repeat". A window is
    never its own neighbour (``exclusion`` is clipped to at least 1). The
    recording is one session, so "same-subject" holds by construction; call
    this per session for multi-session data.

    Distances are computed with :py:func:`torch.cdist` in chunks of
    ``batch_size`` queries; the distance to the selected neighbour is then
    recomputed directly (no ``‖a‖² + ‖b‖² − 2ab`` cancellation).

    Args:
        neural: ``(n_time, C)`` recording.
        noise_model: Object with a linear ``whiten(delta (B, C, T))``.
        offset_left: Samples before ``t`` (``Offset.left``).
        offset_right: Samples from ``t`` on (``Offset.right``).
        classes: ``(n_time,)`` int class ids (see :py:func:`make_classes`), or
            None to treat all windows as one class.
        query_indices: Time indices to query; default: all valid indices.
        bank_size: Number of candidate neighbours; None uses all valid windows.
        exclusion: Minimum ``|t − t'|`` of a neighbour; default: window length.
        batch_size: Queries (and bank windows) processed per chunk.
        seed: Seed of the bank draw.
        device: Where to compute (see :py:func:`whitened_windows`).

    Returns:
        ``(query_indices (Q,) int64, distances (Q,) float64)`` numpy arrays;
        the distance is ``inf`` when the bank holds no eligible neighbour.
    """
    device = _resolve_device(device, noise_model, neural)
    recording = _recording_tensor(neural, device)
    n_time = recording.shape[0]
    valid = valid_indices(n_time, offset_left, offset_right)
    if len(valid) == 0:
        raise ValueError(
            f"Recording of length {n_time} is shorter than one window "
            f"({offset_left + offset_right} samples).")
    if exclusion is None:
        exclusion = offset_left + offset_right
    exclusion = max(int(exclusion), 1)
    if query_indices is None:
        queries = valid.copy()
    else:
        queries = _check_window_indices(query_indices, n_time, offset_left,
                                        offset_right)
    class_ids = None
    if classes is not None:
        class_ids = _to_numpy(classes).astype(np.int64).reshape(-1)
        if len(class_ids) != n_time:
            raise ValueError(f"classes has length {len(class_ids)}, expected "
                             f"n_time = {n_time}.")

    bank = _bank_indices(valid, bank_size, seed)
    distances = np.full(len(queries), np.inf, dtype=np.float64)
    with torch.no_grad():
        bank_white = torch.cat(
            list(
                _iter_whitened(recording, bank, offset_left, offset_right,
                               noise_model, batch_size)))
        bank_time = torch.as_tensor(bank, device=device)
        bank_class = (None if class_ids is None else torch.as_tensor(
            class_ids[bank], device=device))
        chunks = _iter_whitened(recording, queries, offset_left, offset_right,
                                noise_model, batch_size)
        for start, query_white in zip(range(0, len(queries), batch_size),
                                      chunks):
            stop = start + len(query_white)
            query_time = torch.as_tensor(queries[start:stop], device=device)
            eligible = ((query_time[:, None] - bank_time[None, :]).abs() >=
                        exclusion)
            if bank_class is not None:
                query_class = torch.as_tensor(class_ids[queries[start:stop]],
                                              device=device)
                eligible &= query_class[:, None] == bank_class[None, :]
            pairwise = torch.cdist(query_white, bank_white)
            pairwise = pairwise.masked_fill(~eligible, math.inf)
            best, neighbour = pairwise.min(dim=1)
            exact = torch.linalg.vector_norm(query_white -
                                             bank_white[neighbour],
                                             dim=1)
            exact = torch.where(torch.isinf(best), best, exact)
            distances[start:stop] = exact.double().cpu().numpy()
    return queries, distances


def eps_nn(distances: ArrayLike, quantile: float = 0.10) -> float:
    """ε_NN: a low quantile of the nearest-neighbour d′ distances.

    "Take a low quantile (e.g., the 10th). The adversarial example is then
    closer to its original than the original is to a natural repeat."

    Args:
        distances: Nearest-neighbour distances (see
            :py:func:`nearest_neighbour_dprime`).
        quantile: Quantile in ``[0, 1]`` (linear interpolation, as
            :py:func:`numpy.quantile`).

    Returns:
        The quantile of the finite distances (windows without any eligible
        neighbour are ignored); ``inf`` (no constraint) if none is finite.
    """
    if not 0.0 <= quantile <= 1.0:
        raise ValueError(f"quantile must be in [0, 1], got {quantile}.")
    values = _to_numpy(distances).astype(np.float64).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        warnings.warn("No finite nearest-neighbour distance; eps_nn = inf.")
        return math.inf
    return float(np.quantile(values, quantile))


def per_index_eps_nn(n_time: int, query_indices: ArrayLike,
                     distances: ArrayLike) -> np.ndarray:
    """Per-trial ε_NN,i as a lookup table over time indices.

    Used for the instance-adaptive budget ``ε_i = min(ε*, ε_NN,i)``. Indices
    without a distance (invalid indices, indices that were not queried, and
    queries without a neighbour) get ``inf``, i.e. no per-trial constraint.
    CEBRA samplers may draw indices outside the valid range and rely on the
    clamp in ``expand_index``; clamp such indices the same way
    (``np.clip(t, left, n_time - right)``) before the lookup.

    Args:
        n_time: Number of time points of the recording.
        query_indices: ``(Q,)`` time indices.
        distances: ``(Q,)`` distances; duplicates keep the smallest one.

    Returns:
        ``(n_time,)`` float32 array.
    """
    index = _to_numpy(query_indices).astype(np.int64).reshape(-1)
    values = _to_numpy(distances).astype(np.float64).reshape(-1)
    if index.shape != values.shape:
        raise ValueError(f"{index.size} query indices but {values.size} "
                         "distances.")
    if index.size and (index.min() < 0 or index.max() >= n_time):
        raise ValueError(f"query_indices must lie in [0, {n_time}).")
    table = np.full(n_time, np.inf, dtype=np.float64)
    np.minimum.at(table, index, np.where(np.isnan(values), np.inf, values))
    return table.astype(np.float32)


# ---------------------------------------------------------------------------
# Criterion 3: ε_det
# ---------------------------------------------------------------------------


class ConvDetector(nn.Module):
    """Supervised clean-vs-adversarial window classifier.

    ``Conv1d(C, 32, 5) – ReLU – Conv1d(32, 32, 5) – ReLU – mean over time –
    Linear(32, 1)``. Windows shorter than the receptive field (9 bins) are
    replicate-padded to 9 bins.

    Args:
        num_channels: Number of input channels ``C``.
        hidden: Number of convolution channels.
    """

    def __init__(self, num_channels: int, hidden: int = 32):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(num_channels, hidden, 5),
            nn.ReLU(),
            nn.Conv1d(hidden, hidden, 5),
            nn.ReLU(),
        )
        self.head = nn.Linear(hidden, 1)
        self.receptive_field = 9

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Detection logit (positive: adversarial).

        Args:
            x: ``(B, C, T)`` windows.

        Returns:
            ``(B,)`` logits.
        """
        missing = self.receptive_field - x.shape[-1]
        if missing > 0:
            x = F.pad(x, (missing // 2, missing - missing // 2),
                      mode="replicate")
        return self.head(self.features(x).mean(dim=-1)).squeeze(-1)


class ConvAutoencoder(nn.Module):
    """Clean-only anomaly detector ("such as an autoencoder").

    ``Conv1d(C, 32, 5, pad 2) – ReLU – Conv1d(32, 8, 5, pad 2) – ReLU –
    Conv1d(8, 32, 5, pad 2) – ReLU – Conv1d(32, C, 5, pad 2)``; the window
    length is preserved.

    Args:
        num_channels: Number of input channels ``C``.
        hidden: Channels of the outer layers.
        bottleneck: Channels of the code.
    """

    def __init__(self,
                 num_channels: int,
                 hidden: int = 32,
                 bottleneck: int = 8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(num_channels, hidden, 5, padding=2),
            nn.ReLU(),
            nn.Conv1d(hidden, bottleneck, 5, padding=2),
            nn.ReLU(),
            nn.Conv1d(bottleneck, hidden, 5, padding=2),
            nn.ReLU(),
            nn.Conv1d(hidden, num_channels, 5, padding=2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Reconstruction of ``x`` (``(B, C, T)`` -> ``(B, C, T)``)."""
        return self.net(x)

    def reconstruction_error(self, x: torch.Tensor) -> torch.Tensor:
        """Anomaly score: per-window mean squared reconstruction error ``(B,)``."""
        return (self(x) - x).pow(2).mean(dim=(1, 2))


def auc(scores_neg: ArrayLike, scores_pos: ArrayLike) -> float:
    """Area under the ROC curve via the Mann–Whitney U statistic.

    ``AUC = P(s_pos > s_neg) + 0.5 · P(s_pos = s_neg)`` (ties count one half),
    computed from average ranks.

    Args:
        scores_neg: Scores of the negatives (clean windows).
        scores_pos: Scores of the positives (adversarial windows).

    Returns:
        The AUC in ``[0, 1]``; NaN if a set is empty or a score is NaN.
    """
    neg = _to_numpy(scores_neg).astype(np.float64).reshape(-1)
    pos = _to_numpy(scores_pos).astype(np.float64).reshape(-1)
    if neg.size == 0 or pos.size == 0:
        return math.nan
    ranks = scipy.stats.rankdata(np.concatenate([neg, pos]))
    rank_sum = ranks[neg.size:].sum()
    u_statistic = rank_sum - pos.size * (pos.size + 1) / 2.0
    return float(u_statistic / (pos.size * neg.size))


def _windows_tensor(x: ArrayLike, device: torch.device) -> torch.Tensor:
    """``(B, C, T)`` windows as a detached float32 tensor on ``device``."""
    if isinstance(x, torch.Tensor):
        x = x.detach()
    else:
        x = torch.from_numpy(np.asarray(x))
    x = x.to(device=device, dtype=torch.float32)
    if x.ndim != 3:
        raise ValueError(f"Expected (B, C, T) windows, got {tuple(x.shape)}.")
    return x


def _channel_standardizer(
        clean: torch.Tensor) -> Callable[[torch.Tensor], torch.Tensor]:
    """Per-channel z-scoring fitted on clean windows.

    A fixed invertible affine map (same for clean and adversarial inputs) that
    only conditions the detector inputs. The SD is floored at 1e-3 × the mean
    channel SD (variance floor 1e-6 ×, as for the noise covariance).
    """
    data = clean.double()
    mean = data.mean(dim=(0, 2), keepdim=True)
    std = (data - mean).pow(2).mean(dim=(0, 2), keepdim=True).sqrt()
    mean_std = float(std.mean())
    std = std.clamp_min(1e-3 * mean_std if mean_std > 0 else 1.0)
    mean, std = mean.float(), std.float()
    return lambda x: (x - mean) / std


def _seeded(factory: Callable[[], nn.Module], seed: int) -> nn.Module:
    """Build a module on the CPU with seeded init, leaving the global RNG as is."""
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        return factory()


def _fit(model: nn.Module, loss_fn: Callable[[nn.Module, torch.Generator],
                                             torch.Tensor], steps: int,
         lr: float, seed: int) -> nn.Module:
    """Adam(lr) for ``steps`` steps; minibatches drawn with a seeded generator."""
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    generator = torch.Generator().manual_seed(seed)
    model.train()
    with torch.enable_grad():
        for _ in range(steps):
            loss = loss_fn(model, generator)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
    return model.eval()


def _fit_detector(clean: torch.Tensor, adversarial: torch.Tensor, steps: int,
                  batch_size: int, lr: float, seed: int) -> ConvDetector:
    """Train a :py:class:`ConvDetector` on balanced clean/adversarial batches."""
    device = clean.device
    n_neg = batch_size // 2
    n_pos = batch_size - n_neg
    target = torch.cat([torch.zeros(n_neg), torch.ones(n_pos)]).to(device)

    def loss_fn(model, generator):
        neg = torch.randint(len(clean), (n_neg,), generator=generator)
        pos = torch.randint(len(adversarial), (n_pos,), generator=generator)
        batch = torch.cat([clean[neg.to(device)], adversarial[pos.to(device)]])
        return F.binary_cross_entropy_with_logits(model(batch), target)

    model = _seeded(lambda: ConvDetector(clean.shape[1]), seed).to(device)
    return _fit(model, loss_fn, steps, lr, seed)


def _fit_autoencoder(clean: torch.Tensor, steps: int, batch_size: int,
                     lr: float, seed: int) -> ConvAutoencoder:
    """Train a :py:class:`ConvAutoencoder` on clean windows only (MSE)."""
    device = clean.device

    def loss_fn(model, generator):
        index = torch.randint(len(clean), (batch_size,), generator=generator)
        return model.reconstruction_error(clean[index.to(device)]).mean()

    model = _seeded(lambda: ConvAutoencoder(clean.shape[1]), seed).to(device)
    return _fit(model, loss_fn, steps, lr, seed)


def _score(score_fn: Callable[[torch.Tensor], torch.Tensor],
           x: torch.Tensor) -> np.ndarray:
    """Evaluate ``score_fn`` on ``x`` in chunks, without gradients."""
    with torch.no_grad():
        scores = [
            score_fn(x[start:start + _SCORE_CHUNK])
            for start in range(0, len(x), _SCORE_CHUNK)
        ]
    return torch.cat(scores).double().cpu().numpy()


def _attack(attack_fn: Callable, x: torch.Tensor, eps: float,
            kind: str) -> torch.Tensor:
    """Run ``attack_fn`` (with autograd enabled) and validate its output."""
    with torch.enable_grad():
        x_adv = attack_fn(x, eps, kind)
    x_adv = _windows_tensor(x_adv, x.device)
    if x_adv.shape != x.shape:
        raise ValueError(f"attack_fn(x, {eps}, {kind!r}) returned shape "
                         f"{tuple(x_adv.shape)}, expected {tuple(x.shape)}.")
    return x_adv


def detection_curve(
    x_train: ArrayLike,
    x_test: ArrayLike,
    attack_fn: Callable[[torch.Tensor, float, str], torch.Tensor],
    eps_grid: Sequence[float],
    detector_steps: int = 300,
    device: Optional[Union[str, torch.device]] = None,
    seed: int = 0,
    *,
    kinds: Sequence[str] = ATTACK_KINDS,
    batch_size: int = 256,
    lr: float = 1e-3,
) -> Dict[float, Dict[str, float]]:
    """Detectability AUC of the attack as a function of ε (input of ε_det).

    For every ``eps`` of the grid, a fresh :py:class:`ConvDetector` is trained
    on clean ``x_train`` vs the mixture of all attack ``kinds`` applied to
    ``x_train`` ("detectors overfit to one attack, so train them across
    attacks") and evaluated on clean ``x_test`` vs ``attack_fn(x_test, eps,
    "dprime")`` ("on held-out [data]"). The clean-only anomaly detector, a
    :py:class:`ConvAutoencoder`, is trained once on clean ``x_train`` and
    scores held-out windows by reconstruction MSE. Both detectors see the
    windows z-scored per channel with statistics of clean ``x_train``, are
    trained with Adam(``lr``) on minibatches of ``batch_size`` (half clean,
    half adversarial for the CNN) for ``detector_steps`` steps, and use the
    same ``seed`` for every ``eps`` (common random numbers across the grid).
    The global torch RNG state is left untouched.

    Args:
        x_train: ``(N, C, T)`` clean windows to train the detectors on.
        x_test: ``(M, C, T)`` held-out clean windows.
        attack_fn: ``attack_fn(x, eps, kind) -> x_adv`` with ``x_adv`` of the
            shape of ``x``, for ``kind`` in ``kinds`` and ``"dprime"``; it is
            called with autograd enabled and must not modify ``x`` in place.
        eps_grid: Budgets ε ≥ 0 (d′ units).
        detector_steps: Optimisation steps per detector.
        device: Where to train; default: the device of ``x_train``.
        seed: Seed of the detector initialisation and minibatch draws.
        kinds: Attack kinds mixed into the CNN's training positives.
        batch_size: Minibatch size.
        lr: Adam learning rate.

    Returns:
        ``{eps: {"cnn_auc": ..., "ae_auc": ..., "auc": max of both}}`` with
        float keys in grid order.
    """
    eps_values = [float(eps) for eps in eps_grid]
    if not eps_values:
        raise ValueError("eps_grid is empty.")
    if any(not math.isfinite(eps) or eps < 0 for eps in eps_values):
        raise ValueError(f"eps_grid must be finite and >= 0, got {eps_values}.")
    kinds = tuple(kinds)
    if not kinds:
        raise ValueError("kinds is empty.")
    if device is None:
        device = (x_train.device
                  if isinstance(x_train, torch.Tensor) else "cpu")
    device = torch.device(device)
    x_train = _windows_tensor(x_train, device)
    x_test = _windows_tensor(x_test, device)
    if x_train.shape[1:] != x_test.shape[1:]:
        raise ValueError(f"x_train windows {tuple(x_train.shape[1:])} and "
                         f"x_test windows {tuple(x_test.shape[1:])} differ.")
    if len(x_train) == 0 or len(x_test) == 0:
        raise ValueError("x_train and x_test must not be empty.")

    standardize = _channel_standardizer(x_train)
    z_train = standardize(x_train)
    z_test = standardize(x_test)
    autoencoder = _fit_autoencoder(z_train, detector_steps, batch_size, lr,
                                   seed)
    ae_clean = _score(autoencoder.reconstruction_error, z_test)

    curve = {}
    for eps in eps_values:
        z_adv_train = torch.cat([
            standardize(_attack(attack_fn, x_train, eps, kind))
            for kind in kinds
        ])
        z_adv_test = standardize(_attack(attack_fn, x_test, eps, "dprime"))
        detector = _fit_detector(z_train, z_adv_train, detector_steps,
                                 batch_size, lr, seed)
        cnn_auc = auc(_score(detector, z_test), _score(detector, z_adv_test))
        ae_auc = auc(ae_clean,
                     _score(autoencoder.reconstruction_error, z_adv_test))
        curve[eps] = {
            "cnn_auc": cnn_auc,
            "ae_auc": ae_auc,
            "auc": float(np.max([cnn_auc, ae_auc])),
        }
        del z_adv_train, z_adv_test, detector
    return curve


def eps_det_from_curve(curve: Mapping[float, Union[Mapping[str, float],
                                                   float]],
                       threshold: float = 0.55) -> Tuple[float, str]:
    """ε_det: the largest grid ε at which the detectors stay ≤ ``threshold`` AUC.

    "The largest ε at which a detector [...] stays ≤ 0.55 AUC": walking the
    grid upwards, ε_det is the last ε before the first ε whose AUC exceeds the
    threshold (a NaN AUC counts as exceeding it). On a curve that increases
    with ε this is the largest grid ε with AUC ≤ threshold; on a noisy,
    non-monotone curve a pass above a failure is not used.

    Args:
        curve: ``{eps: {"auc": ...}}`` (as returned by
            :py:func:`detection_curve`) or ``{eps: auc}``.
        threshold: Maximum AUC of an undetectable attack.

    Returns:
        ``(eps_det, status)``: status ``"ok"``; ``"below_grid"`` if the
        smallest grid ε already fails (ε_det = half the smallest grid ε); or
        ``"censored_above"`` if every grid ε passes (ε_det = the largest grid
        ε, a lower bound of the true ε_det).
    """
    if not curve:
        raise ValueError("curve is empty.")
    points = sorted(
        (float(eps), float(value["auc"] if isinstance(value, Mapping
                                                      ) else value))
        for eps, value in curve.items())
    eps_det = None
    for eps, area in points:
        if not area <= threshold:  # False for NaN
            break
        eps_det = eps
    if eps_det is None:
        return 0.5 * points[0][0], "below_grid"
    if eps_det == points[-1][0]:
        return eps_det, "censored_above"
    return eps_det, "ok"


def eps_det_crossing(curve: Mapping[float, Union[Mapping[str, float], float]],
                     threshold: float = 0.55,
                     key: str = "auc") -> Tuple[float, str]:
    """ε where a detection curve first exceeds ``threshold``, log-interpolated on the grid.

    Like :py:func:`eps_det_from_curve` (walking the grid upwards, a pass above a failure is
    not used), but between the last passing and the first failing grid point the AUC is
    interpolated linearly in log ε, so the result does not snap to the (factor-2) grid.

    Args:
        curve: ``{eps: {key: auc, ...}}`` or ``{eps: auc}``.
        threshold: Maximum AUC of an undetectable attack.
        key: Which AUC of the curve (``"auc"``, ``"ae_auc"`` (the clean-only anomaly detector)
            or ``"cnn_auc"``).

    Returns:
        ``(eps, status)`` with the statuses of :py:func:`eps_det_from_curve`.
    """
    if not curve:
        raise ValueError("curve is empty.")
    points = sorted(
        (float(eps), float(value[key] if isinstance(value, Mapping) else value))
        for eps, value in curve.items())
    previous = None
    for eps, area in points:
        if not area <= threshold:  # False for NaN
            if previous is None:
                return 0.5 * points[0][0], "below_grid"
            (e0, a0), (e1, a1) = previous, (eps, area)
            if not math.isfinite(a1) or a1 <= a0 or e0 <= 0:
                return e0, "ok"
            weight = (threshold - a0) / (a1 - a0)
            return float(math.exp(math.log(e0) + weight * (math.log(e1) - math.log(e0)))), "ok"
        previous = (eps, area)
    return points[-1][0], "censored_above"


def eps_energy_detector(num_channels: int, window_len: int) -> float:
    """``(2D)^{1/4}``: the d′ at which the optimal *blind* detector reaches d′ = 1.

    An observer who knows the perturbation δ detects it with d′ = ‖δ‖_Σ (the ideal observer of
    ε_JND). An observer who does not know δ (an anomaly detector) can at best test the
    whitened energy: ``‖z + ξ‖²`` has mean ``D + ‖δ‖²_Σ`` and SD ``≈ √(2D)`` under clean noise
    ξ, so its detectability is ``‖δ‖²_Σ / √(2D)``, which reaches 1 at ``‖δ‖_Σ = (2D)^{1/4}``
    (D = C·T). A reference value for the clean-only detector of ε_det.
    """
    return float((2.0 * int(num_channels) * int(window_len))**0.25)


def epsilon_star(eps_nn: Optional[float] = math.inf,
                 eps_det: Optional[float] = math.inf,
                 eps_jnd: float = EPS_JND) -> Tuple[float, str]:
    """ε* = min(ε_JND, ε_NN, ε_det): "take ε* = min of the three".

    Args:
        eps_nn: ε_NN (None or NaN: not computed, i.e. no constraint).
        eps_det: ε_det (None or NaN: not computed).
        eps_jnd: ε_JND (default :py:data:`EPS_JND` = 1).

    Returns:
        ``(eps_star, source)`` with ``source`` in ``("jnd", "nn", "det")``, the
        binding criterion (the first one on ties).
    """
    candidates = []
    for name, value in (("jnd", eps_jnd), ("nn", eps_nn), ("det", eps_det)):
        value = math.inf if value is None else float(value)
        value = math.inf if math.isnan(value) else value
        if value < 0:
            raise ValueError(f"eps_{name} must be >= 0, got {value}.")
        candidates.append((value, name))
    value, name = min(candidates, key=lambda candidate: candidate[0])
    return value, name


# ---------------------------------------------------------------------------
# Robustness margin
# ---------------------------------------------------------------------------


def _quantile_with_inf(sorted_values: np.ndarray, q: float) -> float:
    """Linear-interpolation quantile (as numpy) of right-censored data.

    ``inf`` entries are "never broken"; a quantile that interpolates with
    non-zero weight towards an ``inf`` entry is ``inf`` (numpy would give
    NaN for ``inf · 0``).
    """
    position = (len(sorted_values) - 1) * q
    lower = int(math.floor(position))
    upper = min(lower + 1, len(sorted_values) - 1)
    weight = position - lower
    low, high = sorted_values[lower], sorted_values[upper]
    if weight == 0.0:
        return float(low)
    if math.isinf(high):
        return math.inf
    return float(low + (high - low) * weight)


def robustness_margin(dprime_min: ArrayLike,
                      eps_star: float) -> Dict[str, float]:
    """Dataset-intrinsic robustness margin ``median(d′_boundary) / ε*``.

    "Below 1 the decoder can be flipped within a physiologically
    indistinguishable budget; above 1, larger attacks aren't meaningful for
    that dataset."

    Args:
        dprime_min: ``(B,)`` minimum-norm d′ to the decision boundary per
            window (``0``: already adversarial, ``inf``: never broken by the
            minimum-norm attack); NaN entries are dropped.
        eps_star: The calibrated budget ε*.

    Returns:
        Dict with ``median``, ``q10``, ``q25``, ``q75``, ``q90`` of d′ (linear
        interpolation; ``inf`` where the quantile reaches never-broken
        windows), ``frac_already_adversarial`` (d′ = 0),
        ``frac_never_broken`` (d′ = inf), ``ratio`` = median / ε* (``inf`` if
        ε* = 0 < median, NaN for 0/0), ``eps_star`` and ``n``.
    """
    values = _to_numpy(dprime_min).astype(np.float64).reshape(-1)
    values = np.sort(values[~np.isnan(values)])
    eps_star = float(eps_star)
    report = {"eps_star": eps_star, "n": int(values.size)}
    keys = ("median", "q10", "q25", "q75", "q90")
    if values.size == 0:
        report.update({key: math.nan for key in keys})
        report.update(frac_already_adversarial=math.nan,
                      frac_never_broken=math.nan,
                      ratio=math.nan)
        return report
    for key, q in zip(keys, (0.5, 0.10, 0.25, 0.75, 0.90)):
        report[key] = _quantile_with_inf(values, q)
    report["frac_already_adversarial"] = float(np.mean(values <= 0))
    report["frac_never_broken"] = float(np.mean(np.isinf(values)))
    median = report["median"]
    if eps_star > 0:
        report["ratio"] = median / eps_star
    else:
        report["ratio"] = math.inf if median > 0 else math.nan
    return report


def ideal_observer_accuracy(
        dprime: Union[float, ArrayLike]) -> Union[float, np.ndarray]:
    """Percent correct ``Φ(d′/2)`` of the unbiased ideal observer (yes/no task).

    Grounds ε_JND: at ``d′ = 1`` "an unbiased ideal observer who knows the
    perturbation exactly would still only reach about 69% correct".

    Args:
        dprime: d′ value(s).

    Returns:
        Proportion correct, a float for scalar input.
    """
    accuracy = scipy.special.ndtr(np.asarray(_to_numpy(dprime),
                                             dtype=np.float64) / 2.0)
    return float(accuracy) if np.ndim(accuracy) == 0 else accuracy
