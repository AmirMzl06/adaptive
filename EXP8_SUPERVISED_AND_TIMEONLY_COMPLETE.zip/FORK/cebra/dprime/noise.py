"""Layer 1: the dataset-level stationary noise metric (Section 1 of ``DPRIME_DESIGN.md``).

The research note replaces the L∞/L2 ball by a ball in the metric induced by the dataset's
estimated noise covariance Σ,

    δᵀ Σ⁻¹ δ ≤ ε²,

so that ε is a detectability index d′: "For Gaussian noise, √(δᵀΣ⁻¹δ) is exactly the
ideal-observer (matched-filter) detectability d′ of a known perturbation δ". Σ is modelled
as Kronecker structured, ``Σ = Σ_spatial ⊗ Σ_temporal``: "Σ_spatial is the C×C channel
covariance with shrinkage (Ledoit–Wolf/OAS), estimated per subject or session on residuals
[...]. Σ_temporal is represented by a PSD from Welch or an AR(p) fit, so temporal whitening is
just a prewhitening filter 1/√S(f)."

On a window of ``T`` bins, the prewhitening filter of a stationary process is exactly the
inverse square root of the ``T × T`` Toeplitz covariance implied by its PSD. This module
estimates the PSD (Welch on a fine frequency grid, an AR(p) fit, or the van Rossum metric of
the spike-train extension), converts it to that Toeplitz ``Σ_temporal`` (unit diagonal, so
the noise scale lives in ``Σ_spatial``), and colors / whitens windows with the symmetric matrix
square roots. Unlike an FFT filter on the window, this has no circular wrap-around between the
first and the last bin. (A circulant model, i.e. a literal FFT filter, is available through
:py:meth:`NoiseModel.from_spectrum`.)

Attacks are run on the whitened variable ``z`` with ``δ = Color(z) = Σ^{1/2} z``, so
``d′ = ‖z‖₂`` and the d′ ball is an ordinary L2 ball in ``z``.

Conventions: windows are ``(B, C, T)`` tensors (``batch.reference`` in CEBRA), recordings are
``(n_time, C)`` arrays. Estimation runs in float64 numpy; coloring and whitening run in torch
on the device and dtype of their input.
"""

import math
import warnings
from typing import Any, Dict, Optional, Sequence, Tuple, Union

import numpy as np
import numpy.typing as npt
import scipy.linalg
import scipy.signal
import sklearn.covariance
import torch

__all__ = [
    "RESIDUAL_MODES",
    "SPATIAL_ESTIMATORS",
    "TEMPORAL_METHODS",
    "compute_residuals",
    "spatial_covariance",
    "tyler_covariance",
    "temporal_covariance",
    "covariance_spectrum",
    "temporal_spectrum",
    "circulant_covariance",
    "full_spectrum",
    "fit_vanrossum_tau",
    "kronecker_check",
    "NoiseModel",
    "StationaryColoring",
    "LeadfieldColoring",
    "fit_noise_model",
]

RESIDUAL_MODES = ("auto", "whole", "class_mean", "regression", "difference")
SPATIAL_ESTIMATORS = ("ledoit_wolf", "oas", "empirical", "tyler", "isotropic")
TEMPORAL_METHODS = ("welch", "ar", "white", "vanrossum")

ArrayLike = Union[npt.NDArray, torch.Tensor]

# Relative eigenvalue floor of every covariance ("1e-6 x mean eigenvalue").
_EIGEN_FLOOR = 1e-6
# Frequency grid used to turn an AR spectrum into an autocovariance.
_AR_GRID = 4096


def _to_numpy(array: ArrayLike) -> np.ndarray:
    if isinstance(array, torch.Tensor):
        return array.detach().cpu().numpy()
    return np.asarray(array)


def _recording(neural: ArrayLike) -> np.ndarray:
    """``(n_time, C)`` float64 copy of a recording."""
    x = np.array(_to_numpy(neural), dtype=np.float64)
    if x.ndim != 2:
        raise ValueError(f"Expected a (n_time, C) recording, got shape {x.shape}.")
    if not np.all(np.isfinite(x)):
        raise ValueError("The recording contains NaN or inf values.")
    return x


def _infer_label_kind(labels: np.ndarray, label_kind: Optional[str]) -> str:
    if label_kind in ("discrete", "continuous"):
        return label_kind
    if label_kind not in (None, "auto"):
        raise ValueError(
            f"label_kind must be 'discrete', 'continuous' or None, got {label_kind!r}.")
    if np.issubdtype(labels.dtype, np.integer) or labels.dtype == np.bool_:
        return "discrete"
    return "continuous"


# ---------------------------------------------------------------------------
# Residuals: what "noise" means
# ---------------------------------------------------------------------------


def compute_residuals(neural: ArrayLike,
                      labels: Optional[ArrayLike] = None,
                      mode: str = "auto",
                      label_kind: Optional[str] = None) -> np.ndarray:
    """Noise residuals of a recording, the data the noise covariance is estimated on.

    "Estimated per subject or session on residuals (trial minus class mean for ERP data;
    whole trials for oscillatory tasks where background dominates)". For continuous labels
    (e.g. behaviour) the analogue of "minus class mean" is "minus the part of the activity
    that is linearly predictable from the labels".

    ``"difference"`` is the label-free analogue for activity whose signal is slow compared
    with its noise (e.g. firing rates driven by movement vs. spiking noise): the scaled first
    difference ``(x_t − x_{t−1}) / √2`` cancels a signal that changes little between
    neighbouring bins and keeps the covariance of temporally white noise unchanged, so its
    covariance estimates the spatial covariance of the fast fluctuations rather than of the
    whole activity. Its own spectrum is high-pass by construction, so it is meant for the
    spatial factor (use ``temporal="white"``).

    Args:
        neural: ``(n_time, C)`` recording.
        labels: ``(n_time,)`` discrete labels, ``(n_time,)`` / ``(n_time, d)`` continuous
            labels, or None.
        mode: ``"whole"`` (subtract the mean), ``"class_mean"`` (subtract the mean of each
            class; discrete labels), ``"regression"`` (subtract a ridge regression on the
            continuous labels, with intercept; ridge = 1e-6 x the trace of the centred label
            Gram matrix), ``"difference"`` (scaled first difference; label-free, see above;
            ``n_time − 1`` rows), or ``"auto"`` (class_mean for discrete labels, regression
            for continuous labels, whole without labels).
        label_kind: ``"discrete"``, ``"continuous"`` or None to infer it from the dtype.

    Returns:
        ``(n_time, C)`` (``(n_time − 1, C)`` for ``"difference"``) float64 residuals (zero
        mean per channel).
    """
    x = _recording(neural)
    if mode not in RESIDUAL_MODES:
        raise ValueError(f"mode must be one of {RESIDUAL_MODES}, got {mode!r}.")
    if mode == "difference":
        if len(x) < 3:
            raise ValueError("The difference residuals need at least three time points.")
        difference = np.diff(x, axis=0) / math.sqrt(2.0)
        return difference - difference.mean(axis=0, keepdims=True)
    if labels is None:
        if mode in ("class_mean", "regression"):
            raise ValueError(f"Residual mode {mode!r} needs labels.")
        mode = "whole"
        y = None
    else:
        y = np.asarray(_to_numpy(labels))
        if len(y) != len(x):
            raise ValueError(f"labels have {len(y)} rows, the recording {len(x)}.")
        kind = _infer_label_kind(y, label_kind)
        if mode == "auto":
            mode = "class_mean" if kind == "discrete" else "regression"

    if mode == "whole":
        return x - x.mean(axis=0, keepdims=True)

    if mode == "class_mean":
        classes = y.reshape(len(y), -1)
        if classes.shape[1] != 1:
            _, inverse = np.unique(classes, axis=0, return_inverse=True)
        else:
            _, inverse = np.unique(classes[:, 0], return_inverse=True)
        inverse = inverse.reshape(-1)
        n_classes = int(inverse.max()) + 1
        sums = np.zeros((n_classes, x.shape[1]))
        np.add.at(sums, inverse, x)
        counts = np.bincount(inverse, minlength=n_classes)[:, None]
        return x - (sums / counts)[inverse]

    # mode == "regression"
    y = y.reshape(len(y), -1).astype(np.float64)
    if not np.all(np.isfinite(y)):
        raise ValueError("Continuous labels contain NaN or inf values.")
    yc = y - y.mean(axis=0, keepdims=True)
    xc = x - x.mean(axis=0, keepdims=True)
    gram = yc.T @ yc
    ridge = _EIGEN_FLOOR * max(float(np.trace(gram)), 1e-12)
    beta = np.linalg.solve(gram + ridge * np.eye(gram.shape[0]), yc.T @ xc)
    return xc - yc @ beta


# ---------------------------------------------------------------------------
# Spatial covariance
# ---------------------------------------------------------------------------


def _floor_eigenvalues(cov: np.ndarray, relative_floor: float = _EIGEN_FLOOR) -> np.ndarray:
    """Symmetrise and floor the eigenvalues at ``relative_floor`` x the mean eigenvalue."""
    cov = 0.5 * (cov + cov.T)
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    mean_eig = max(float(np.mean(np.abs(eigenvalues))), 1e-300)
    eigenvalues = np.maximum(eigenvalues, relative_floor * mean_eig)
    return (eigenvectors * eigenvalues) @ eigenvectors.T


def tyler_covariance(residuals: ArrayLike,
                     shrinkage: float = 0.1,
                     max_iter: int = 200,
                     tol: float = 1e-7) -> np.ndarray:
    """Regularised Tyler M-estimator of scatter (Chen, Wiesel & Hero, 2011).

    Fixed point ``Σ ← (1 − ρ) (C/n) Σ_i x_i x_iᵀ / (x_iᵀ Σ⁻¹ x_i) + ρ I`` with
    ``trace Σ = C`` after every iteration ("EEG is heavy-tailed, so use robust covariance
    (Tyler's estimator)"). Tyler's estimator only identifies the shape, so the result is
    rescaled to the trace of the empirical covariance.

    Args:
        residuals: ``(n_time, C)`` zero-mean residuals.
        shrinkage: ρ, shrinkage toward the identity, in ``(0, 1]``.
        max_iter: Maximum number of fixed-point iterations.
        tol: Stop when the relative Frobenius change is below ``tol``.

    Returns:
        ``(C, C)`` float64 SPD covariance.
    """
    x = _recording(residuals)
    n_time, num_channels = x.shape
    if not 0.0 < shrinkage <= 1.0:
        raise ValueError(f"shrinkage must be in (0, 1], got {shrinkage}.")
    empirical = x.T @ x / n_time
    norms = np.einsum("ij,ij->i", x, x)
    x = x[norms > 0]
    if len(x) == 0:
        return _floor_eigenvalues(np.eye(num_channels) * 1e-12)
    shape = np.eye(num_channels)
    for _ in range(max_iter):
        inverse = np.linalg.inv(_floor_eigenvalues(shape))
        quad = np.maximum(np.einsum("ij,jk,ik->i", x, inverse, x), 1e-300)
        update = (1.0 - shrinkage) * (num_channels / len(x)) * (x.T / quad) @ x
        update += shrinkage * np.eye(num_channels)
        update *= num_channels / np.trace(update)
        change = np.linalg.norm(update - shape) / np.linalg.norm(shape)
        shape = update
        if change < tol:
            break
    scale = np.trace(empirical) / num_channels
    return _floor_eigenvalues(shape * max(scale, 1e-300))


def spatial_covariance(residuals: ArrayLike, estimator: str = "ledoit_wolf") -> np.ndarray:
    """The C×C channel covariance Σ_spatial of the noise residuals.

    "Σ_spatial is the C×C channel covariance with shrinkage (Ledoit–Wolf/OAS)"; the
    regularised Tyler estimator is the robust option for heavy-tailed data. ``"isotropic"``
    (mean residual variance × I) is the control without a noise-aware geometry: with
    ``temporal="white"`` the d′ ball is the plain L2 ball of radius ε·σ̄ in input units.

    Args:
        residuals: ``(n_time, C)`` residuals (see :py:func:`compute_residuals`).
        estimator: ``"ledoit_wolf"``, ``"oas"``, ``"empirical"``, ``"tyler"`` or
            ``"isotropic"``.

    Returns:
        ``(C, C)`` float64 SPD matrix; eigenvalues floored at 1e-6 x their mean.
    """
    x = _recording(residuals)
    if estimator not in SPATIAL_ESTIMATORS:
        raise ValueError(f"estimator must be one of {SPATIAL_ESTIMATORS}, got {estimator!r}.")
    if len(x) < 2:
        raise ValueError("Need at least two time points to estimate a covariance.")
    if estimator == "ledoit_wolf":
        cov = sklearn.covariance.LedoitWolf().fit(x).covariance_
    elif estimator == "oas":
        cov = sklearn.covariance.OAS().fit(x).covariance_
    elif estimator == "empirical":
        xc = x - x.mean(axis=0, keepdims=True)
        cov = xc.T @ xc / len(xc)
    elif estimator == "isotropic":
        cov = np.eye(x.shape[1]) * float(x.var(axis=0).mean())
    else:
        cov = tyler_covariance(x - x.mean(axis=0, keepdims=True))
    return _floor_eigenvalues(np.asarray(cov, dtype=np.float64))


# ---------------------------------------------------------------------------
# Temporal factor
# ---------------------------------------------------------------------------


def full_spectrum(spectrum_half: ArrayLike, window_len: int) -> np.ndarray:
    """Two-sided spectrum (length ``window_len``) from the one-sided ``rfft`` half."""
    half = np.asarray(_to_numpy(spectrum_half), dtype=np.float64).reshape(-1)
    num_freqs = window_len // 2 + 1
    if len(half) != num_freqs:
        raise ValueError(f"Expected {num_freqs} frequencies for window_len={window_len}, "
                         f"got {len(half)}.")
    return np.concatenate([half, half[1:window_len - num_freqs + 1][::-1]])


def _standardised_channels(residuals: np.ndarray) -> np.ndarray:
    """Residuals with every non-silent channel scaled to unit variance."""
    x = residuals - residuals.mean(axis=0, keepdims=True)
    std = x.std(axis=0)
    active = std > 0
    if not np.any(active):
        raise ValueError("All channels have zero variance.")
    return x[:, active] / std[active]


def _channel_mean_autocovariance(x: np.ndarray, max_lag: int) -> np.ndarray:
    """Biased autocovariance for lags ``0..max_lag``, averaged over channels."""
    n_time = len(x)
    num = 1 << int(math.ceil(math.log2(2 * n_time)))
    acov = np.zeros(max_lag + 1)
    for start in range(0, x.shape[1], 64):  # bounded memory for many channels
        spectrum = np.fft.rfft(x[:, start:start + 64], n=num, axis=0)
        block = np.fft.irfft(np.abs(spectrum)**2, n=num, axis=0)[:max_lag + 1]
        acov += block.sum(axis=1)
    return acov / (n_time * x.shape[1])


def _finish_temporal(cov: np.ndarray) -> np.ndarray:
    """Symmetrise, floor the eigenvalues and scale to a unit mean diagonal."""
    cov = _floor_eigenvalues(cov)
    return cov / (np.trace(cov) / len(cov))


def _toeplitz_from_autocovariance(acov: np.ndarray, window_len: int) -> np.ndarray:
    acov = np.asarray(acov, dtype=np.float64)[:window_len]
    if acov[0] <= 0:
        raise ValueError("The autocovariance at lag 0 must be positive.")
    return _finish_temporal(scipy.linalg.toeplitz(acov / acov[0]))


def fit_vanrossum_tau(residuals: ArrayLike, max_lag: int = 200) -> float:
    """Time constant τ of the van Rossum metric fitted to the data.

    "For spike trains the same logic applies with a different metric [...] budgeted by van
    Rossum distance with τ fitted to the dataset's inter-trial variability". τ is the
    e-folding time of the channel-averaged autocorrelation of the noise residuals (first lag
    where it drops below 1/e, linearly interpolated), at least half a bin.

    Args:
        residuals: ``(n_time, C)`` residuals.
        max_lag: Largest lag considered; τ = max_lag if the autocorrelation never decays.

    Returns:
        τ in bins (float ≥ 0.5).
    """
    x = _standardised_channels(_recording(residuals))
    max_lag = int(max(1, min(max_lag, len(x) // 4)))
    acov = _channel_mean_autocovariance(x, max_lag)
    rho = acov / acov[0]
    threshold = math.exp(-1.0)
    below = np.nonzero(rho < threshold)[0]
    if len(below) == 0:
        return float(max_lag)
    lag = int(below[0])
    previous = rho[lag - 1]
    tau = (lag - 1) + (previous - threshold) / max(previous - rho[lag], 1e-12)
    return float(max(tau, 0.5))


def _ar_autocovariance(x: np.ndarray, window_len: int, ar_order: int) -> np.ndarray:
    """Autocovariance (lags ``0..T-1``) of the Yule–Walker AR(p) fit.

    The AR spectrum ``σ² / |1 − Σ_k a_k e^{−2πifk}|²`` is evaluated on a fine grid and
    inverse-transformed.
    """
    if ar_order < 1:
        raise ValueError(f"ar_order must be >= 1, got {ar_order}.")
    acov = _channel_mean_autocovariance(x, ar_order)
    coefficients = scipy.linalg.solve_toeplitz(acov[:ar_order], acov[1:ar_order + 1])
    innovation = max(float(acov[0] - coefficients @ acov[1:ar_order + 1]), 1e-12 * acov[0])
    grid = max(_AR_GRID, 16 * window_len)
    freqs = np.fft.rfftfreq(grid)
    lags = np.arange(1, ar_order + 1)
    transfer = 1.0 - np.exp(-2j * np.pi * np.outer(freqs, lags)) @ coefficients
    spectrum = innovation / np.abs(transfer)**2
    return np.fft.irfft(spectrum, n=grid)[:window_len]


def _welch_autocovariance(x: np.ndarray, window_len: int,
                          nperseg: Optional[int]) -> np.ndarray:
    """Autocovariance (lags ``0..T-1``) of the channel-averaged Welch PSD on a fine grid."""
    if nperseg is None:
        nperseg = max(8 * window_len, 256)
    nperseg = int(min(nperseg, len(x)))
    if nperseg < 2 * window_len:
        raise ValueError(f"Welch needs at least {2 * window_len} bins, got {len(x)}.")
    _, power = scipy.signal.welch(x,
                                  nperseg=nperseg,
                                  noverlap=nperseg // 2,
                                  window="hann",
                                  detrend="constant",
                                  return_onesided=True,
                                  axis=0)
    power = power.mean(axis=1)
    # scipy doubles the paired one-sided bins (all but DC and, for an even nperseg, Nyquist)
    # to conserve power; undo it to get the two-sided spectral density on the rfft grid.
    if nperseg % 2 == 0:
        power[1:-1] /= 2.0
    else:
        power[1:] /= 2.0
    return np.fft.irfft(power, n=nperseg)[:window_len]


def _vanrossum_covariance(window_len: int, tau: float) -> np.ndarray:
    """``Σ_temporal = (KᵀK)⁻¹`` for the causal van Rossum kernel ``K[t, s] = exp(−(t−s)/τ)``.

    Then ``δᵀ Σ_temporal⁻¹ δ = ‖K δ‖²``: the van Rossum distance of the perturbation (up to the
    unit-diagonal normalisation).
    """
    if not tau > 0:
        raise ValueError(f"tau must be positive, got {tau}.")
    lags = np.arange(window_len)[:, None] - np.arange(window_len)[None, :]
    kernel = np.where(lags >= 0, np.exp(-np.maximum(lags, 0) / float(tau)), 0.0)
    return _finish_temporal(np.linalg.inv(kernel.T @ kernel))


def temporal_covariance(residuals: ArrayLike,
                        window_len: int,
                        method: str = "welch",
                        ar_order: int = 4,
                        tau: Optional[Union[float, str]] = None,
                        welch_nperseg: Optional[int] = None) -> np.ndarray:
    """The temporal factor Σ_temporal of the Kronecker noise model on a ``T``-bin window.

    "Σ_temporal is represented by a PSD from Welch or an AR(p) fit, so temporal whitening is
    just a prewhitening filter 1/√S(f)." The PSD is estimated on per-channel standardised
    residuals averaged over channels (the Kronecker model has one temporal factor) and turned
    into the ``T × T`` Toeplitz covariance of the window; ``Σ_temporal^{-1/2}`` is then the
    exact prewhitening filter of the window.

    Args:
        residuals: ``(n_time, C)`` residuals.
        window_len: Number of bins ``T`` of a window.
        method: ``"welch"`` (Hann, 50% overlap, constant detrend, ``nperseg =
            welch_nperseg`` or ``max(8T, 256)``, capped by the recording length), ``"ar"``
            (Yule–Walker AR(``ar_order``)), ``"white"`` (identity), or ``"vanrossum"``
            (``(KᵀK)⁻¹`` with the van Rossum kernel; the spike-train extension).
        ar_order: Order p of the AR fit.
        tau: τ of the van Rossum kernel in bins; ``None`` / ``"auto"`` fits it with
            :py:func:`fit_vanrossum_tau`.
        welch_nperseg: Welch segment length (the frequency resolution of the PSD).

    Returns:
        ``(T, T)`` float64 SPD matrix with unit mean diagonal (Toeplitz for welch/ar/white).
    """
    if method not in TEMPORAL_METHODS:
        raise ValueError(f"method must be one of {TEMPORAL_METHODS}, got {method!r}.")
    window_len = int(window_len)
    if window_len < 1:
        raise ValueError(f"window_len must be >= 1, got {window_len}.")
    if method == "white" or window_len == 1:
        return np.eye(window_len)
    if method == "vanrossum":
        if tau is None or tau == "auto":
            tau = fit_vanrossum_tau(residuals)
        return _vanrossum_covariance(window_len, float(tau))
    x = _standardised_channels(_recording(residuals))
    if method == "ar":
        return _toeplitz_from_autocovariance(_ar_autocovariance(x, window_len, ar_order),
                                             window_len)
    if len(x) < 2 * window_len:
        warnings.warn(f"Recording ({len(x)} bins) too short for a Welch PSD on "
                      f"{window_len}-bin windows; using an AR({ar_order}) fit instead.")
        return _toeplitz_from_autocovariance(_ar_autocovariance(x, window_len, ar_order),
                                             window_len)
    return _toeplitz_from_autocovariance(_welch_autocovariance(x, window_len, welch_nperseg),
                                         window_len)


def covariance_spectrum(temporal_cov: ArrayLike) -> np.ndarray:
    """One-sided spectrum ``S_k = e_kᴴ Σ_temporal e_k`` on ``numpy.fft.rfftfreq(T)``.

    ``e_k`` are the unit DFT vectors; for a circulant Σ_temporal these are its eigenvalues,
    for a Toeplitz one the window-averaged power at each frequency. With a unit diagonal the
    two-sided spectrum has mean 1.
    """
    cov = np.asarray(_to_numpy(temporal_cov), dtype=np.float64)
    window_len = len(cov)
    dft = np.fft.fft(np.eye(window_len), norm="ortho")
    power = np.real(np.einsum("ki,ij,kj->k", dft, cov, dft.conj()))
    return power[:window_len // 2 + 1]


def temporal_spectrum(residuals: ArrayLike,
                      window_len: int,
                      method: str = "welch",
                      ar_order: int = 4,
                      tau: Optional[Union[float, str]] = None,
                      welch_nperseg: Optional[int] = None) -> np.ndarray:
    """One-sided spectrum of :py:func:`temporal_covariance` (``(T // 2 + 1,)``, two-sided mean 1)."""
    return covariance_spectrum(
        temporal_covariance(residuals, window_len, method, ar_order, tau, welch_nperseg))


def circulant_covariance(spectrum_half: ArrayLike, window_len: int) -> np.ndarray:
    """Circulant ``T × T`` covariance with the given one-sided spectrum (an FFT filter model).

    The spectrum is floored at 1e-6 x its maximum and scaled to a unit mean diagonal.
    """
    half = np.asarray(_to_numpy(spectrum_half), dtype=np.float64).reshape(-1)
    if not np.all(np.isfinite(half)) or np.max(half) <= 0:
        raise ValueError("The spectrum must be finite and positive somewhere.")
    half = np.maximum(half, _EIGEN_FLOOR * np.max(half))
    column = np.fft.ifft(full_spectrum(half, window_len)).real
    lags = (np.arange(window_len)[:, None] - np.arange(window_len)[None, :]) % window_len
    return _finish_temporal(column[lags])


def kronecker_check(residuals: ArrayLike,
                    window_len: int,
                    n_channels: int = 8,
                    max_windows: int = 5000,
                    spatial_cov: Optional[ArrayLike] = None,
                    temporal_cov: Optional[ArrayLike] = None) -> Dict[str, Any]:
    """How well a Kronecker product describes the noise covariance of a window.

    "The Kronecker assumption should be checked against a full covariance on a small C·T
    slice." On the ``n_channels`` highest-variance channels, the full ``(c·T) × (c·T)``
    covariance of residual windows (stride ``T // 4``) is compared with (a) the nearest
    Kronecker product ``A ⊗ B`` (Van Loan & Pitsianis rank-1 rearrangement) and (b) the
    model's own ``Σ_spatial ⊗ Σ_temporal`` if both are given. The error of (a) is a lower
    bound for any Kronecker model; the gap between (b) and (a) is the estimation error of the
    model's factors.

    Args:
        residuals: ``(n_time, C)`` residuals.
        window_len: Window length ``T``.
        n_channels: Number of channels of the slice.
        max_windows: Maximum number of windows used for the full covariance.
        spatial_cov: Optional ``(C, C)`` model Σ_spatial.
        temporal_cov: Optional ``(T, T)`` model Σ_temporal.

    The empirical full covariance is itself noisy (overlapping windows, (c·T)² entries), so
    every error is compared with its sampling floor: the full covariance is also estimated on
    two interleaved halves of the recording (alternating blocks of 8 windows) and
    ``sampling_floor_rel_error = ‖S_a − S_b‖ / (2‖S‖)`` estimates the error of the full-data
    estimate itself. A correct Kronecker model has ``model_rel_error ≈ sampling floor``;
    ``model_excess_rel_error = √(model² − floor²)`` is the part of the error not explained
    by sampling noise.

    Returns:
        Dict with ``nearest_kronecker_rel_error``, ``model_rel_error`` (None without a
        model), ``sampling_floor_rel_error``, ``model_excess_rel_error`` (None without a
        model), ``channels``, ``n_channels``, ``window_len`` and ``n_windows``; relative errors
        are Frobenius norms relative to the full covariance.
    """
    x = _recording(residuals)
    window_len = int(window_len)
    order = np.argsort(-x.var(axis=0), kind="stable")
    channels = np.sort(order[:min(n_channels, x.shape[1])])
    sub = x[:, channels]
    c = len(channels)
    stride = max(1, window_len // 4)
    starts = np.arange(0, len(sub) - window_len + 1, stride)
    if len(starts) == 0:
        raise ValueError("The recording is shorter than one window.")
    if len(starts) > max_windows:
        starts = starts[np.linspace(0, len(starts) - 1, max_windows).astype(int)]
    windows = np.stack([sub[s:s + window_len].T for s in starts])  # (M, c, T)
    flat = windows.reshape(len(windows), -1)
    flat = flat - flat.mean(axis=0, keepdims=True)
    full = flat.T @ flat / len(flat)  # index (channel, time), channel-major
    norm = np.linalg.norm(full)
    halves = (np.arange(len(flat)) // 8) % 2
    floor = None
    if (halves == 0).sum() > 1 and (halves == 1).sum() > 1:
        covs = []
        for half in (0, 1):
            part = flat[halves == half]
            part = part - part.mean(axis=0, keepdims=True)
            covs.append(part.T @ part / len(part))
        floor = float(np.linalg.norm(covs[0] - covs[1]) / (2.0 * norm))

    # Van Loan–Pitsianis: R[(i, j), (t, s)] = full[i*T + t, j*T + s]; Σ ≈ σ₁ u₁ ⊗ v₁.
    rearranged = full.reshape(c, window_len, c, window_len).transpose(0, 2, 1, 3)
    rearranged = rearranged.reshape(c * c, window_len * window_len)
    u, s, vt = np.linalg.svd(rearranged, full_matrices=False)
    nearest = np.kron(s[0] * u[:, 0].reshape(c, c), vt[0].reshape(window_len, window_len))
    report = {
        "nearest_kronecker_rel_error": float(np.linalg.norm(full - nearest) / norm),
        "model_rel_error": None,
        "sampling_floor_rel_error": floor,
        "model_excess_rel_error": None,
        "channels": channels.tolist(),
        "n_channels": int(c),
        "window_len": window_len,
        "n_windows": int(len(windows)),
    }
    if spatial_cov is not None and temporal_cov is not None:
        spatial = np.asarray(_to_numpy(spatial_cov), dtype=np.float64)[np.ix_(channels, channels)]
        model = np.kron(spatial, np.asarray(_to_numpy(temporal_cov), dtype=np.float64))
        report["model_rel_error"] = float(np.linalg.norm(full - model) / norm)
        if floor is not None:
            report["model_excess_rel_error"] = float(
                np.sqrt(max(report["model_rel_error"]**2 - floor**2, 0.0)))
    return report


# ---------------------------------------------------------------------------
# Noise model and colorings
# ---------------------------------------------------------------------------


def _symmetric_roots(cov: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Symmetric square root and inverse square root of an SPD matrix (floored eigh)."""
    cov = _floor_eigenvalues(np.asarray(cov, dtype=np.float64))
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    eigenvalues = np.maximum(eigenvalues, _EIGEN_FLOOR * float(np.mean(eigenvalues)))
    root = (eigenvectors * np.sqrt(eigenvalues)) @ eigenvectors.T
    inverse_root = (eigenvectors / np.sqrt(eigenvalues)) @ eigenvectors.T
    return root, inverse_root


def _per_sample_norm(z: torch.Tensor) -> torch.Tensor:
    return torch.linalg.vector_norm(z.reshape(z.shape[0], -1), dim=1)


def _radius_tensor(radius, batch_size: int, like: torch.Tensor) -> torch.Tensor:
    radius = torch.as_tensor(radius, dtype=like.dtype, device=like.device)
    if radius.ndim == 0:
        radius = radius.expand(batch_size)
    if radius.shape != (batch_size,):
        raise ValueError(f"radius must be a float or a ({batch_size},) tensor, "
                         f"got shape {tuple(radius.shape)}.")
    return radius


def _random_direction(shape, like: torch.Tensor, radius,
                      generator: Optional[torch.Generator]) -> torch.Tensor:
    """Uniform random direction per sample, scaled to the per-sample ``radius``."""
    if generator is not None:
        z = torch.randn(shape, generator=generator, device=generator.device, dtype=like.dtype)
        z = z.to(like.device)
    else:
        z = torch.randn(shape, device=like.device, dtype=like.dtype)
    norm = _per_sample_norm(z).clamp_min(1e-12)
    radius = _radius_tensor(radius, shape[0], z)
    return z * (radius / norm).view(-1, *([1] * (z.ndim - 1)))


class NoiseModel:
    """Kronecker noise model ``Σ = Σ_spatial ⊗ Σ_temporal`` with coloring and whitening.

    ``color(z) = Σ^{1/2} z`` maps the whitened attack variable to a perturbation and
    ``whiten(δ) = Σ^{-1/2} δ`` is its exact inverse, so ``d′(δ) = ‖whiten(δ)‖₂``. Both
    factors use symmetric matrix square roots: ``Σ_spatial^{1/2}`` acts on the channel axis,
    ``Σ_temporal^{1/2}`` on the time axis.

    Args:
        spatial_cov: ``(C, C)`` Σ_spatial of the dataset.
        temporal_cov: ``(T, T)`` Σ_temporal (see :py:func:`temporal_covariance`), rescaled to
            a unit mean diagonal.
        cov_pool: Optional extra ``(C, C)`` spatial covariances; "sample Σ from the pool of
            per-subject covariances during training". ``pool_index`` 0 is ``spatial_cov``,
            ``1..`` the pool.
        leadfield: Optional ``(C, S)`` leadfield for source-space perturbations.
        leadfield_noise: Scale of the sensor noise added to leadfield perturbations.
        device: Device of the tensors.
    """

    def __init__(self,
                 spatial_cov: ArrayLike,
                 temporal_cov: ArrayLike,
                 cov_pool: Optional[Sequence[ArrayLike]] = None,
                 leadfield: Optional[ArrayLike] = None,
                 leadfield_noise: float = 0.0,
                 device: Optional[Union[str, torch.device]] = None):
        spatial_cov = np.asarray(_to_numpy(spatial_cov), dtype=np.float64)
        temporal_cov = np.asarray(_to_numpy(temporal_cov), dtype=np.float64)
        if spatial_cov.ndim != 2 or spatial_cov.shape[0] != spatial_cov.shape[1]:
            raise ValueError(f"spatial_cov must be square, got {spatial_cov.shape}.")
        if temporal_cov.ndim != 2 or temporal_cov.shape[0] != temporal_cov.shape[1]:
            raise ValueError(f"temporal_cov must be square, got {temporal_cov.shape}.")
        self.num_channels = spatial_cov.shape[0]
        self.window_len = temporal_cov.shape[0]
        covariances = [spatial_cov] + [
            np.asarray(_to_numpy(cov), dtype=np.float64) for cov in (cov_pool or [])
        ]
        for cov in covariances:
            if cov.shape != (self.num_channels, self.num_channels):
                raise ValueError("Every covariance of cov_pool must be "
                                 f"{self.num_channels}x{self.num_channels}, got {cov.shape}.")
        self.spatial_cov = _floor_eigenvalues(spatial_cov)
        self.temporal_cov = _finish_temporal(temporal_cov)
        self.spectrum_half = covariance_spectrum(self.temporal_cov)
        roots = [_symmetric_roots(cov) for cov in covariances]
        self._sqrt = [torch.from_numpy(root).float() for root, _ in roots]
        self._isqrt = [torch.from_numpy(inverse).float() for _, inverse in roots]
        temporal_root, temporal_inverse = _symmetric_roots(self.temporal_cov)
        self._tsqrt = torch.from_numpy(temporal_root).float()
        self._tisqrt = torch.from_numpy(temporal_inverse).float()
        self.leadfield = None
        if leadfield is not None:
            leadfield = np.asarray(_to_numpy(leadfield), dtype=np.float64)
            if leadfield.ndim != 2 or leadfield.shape[0] != self.num_channels:
                raise ValueError(f"leadfield must be ({self.num_channels}, S), "
                                 f"got {leadfield.shape}.")
            self.leadfield = torch.from_numpy(leadfield).float()
        self.leadfield_noise = float(leadfield_noise)
        if self.leadfield_noise < 0:
            raise ValueError("leadfield_noise must be >= 0.")
        self.device = torch.device("cpu")
        if device is not None:
            self.to(device)

    @classmethod
    def from_spectrum(cls, spatial_cov: ArrayLike, spectrum_half: ArrayLike, window_len: int,
                      **kwargs) -> "NoiseModel":
        """Noise model with a circulant Σ_temporal, i.e. a literal FFT prewhitening filter."""
        return cls(spatial_cov, circulant_covariance(spectrum_half, window_len), **kwargs)

    @property
    def pool_size(self) -> int:
        """Number of spatial covariances (the dataset's own plus the pool)."""
        return len(self._sqrt)

    @property
    def spatial_sqrt(self) -> torch.Tensor:
        """Symmetric square root of the dataset's own Σ_spatial, ``(C, C)``."""
        return self._sqrt[0]

    def spatial_sqrt_of(self, pool_index: Optional[int] = None) -> torch.Tensor:
        """Symmetric square root of the Σ_spatial selected by ``pool_index``."""
        return self._sqrt[self._pool(pool_index)]

    def to(self, device: Union[str, torch.device]) -> "NoiseModel":
        """Move all tensors to ``device`` (in place); returns ``self``."""
        self.device = torch.device(device)
        self._sqrt = [m.to(self.device) for m in self._sqrt]
        self._isqrt = [m.to(self.device) for m in self._isqrt]
        self._tsqrt = self._tsqrt.to(self.device)
        self._tisqrt = self._tisqrt.to(self.device)
        if self.leadfield is not None:
            self.leadfield = self.leadfield.to(self.device)
        return self

    def _pool(self, pool_index: Optional[int]) -> int:
        index = 0 if pool_index is None else int(pool_index)
        if not 0 <= index < self.pool_size:
            raise IndexError(f"pool_index {index} out of range [0, {self.pool_size}).")
        return index

    def _check(self, x: torch.Tensor, channels: Optional[int] = None) -> None:
        channels = self.num_channels if channels is None else channels
        if x.ndim != 3 or x.shape[1] != channels or x.shape[2] != self.window_len:
            raise ValueError(f"Expected (B, {channels}, {self.window_len}) tensors, "
                             f"got {tuple(x.shape)}.")

    def temporal(self, x: torch.Tensor, inverse: bool = False) -> torch.Tensor:
        """``Σ_temporal^{1/2}`` (or ``Σ_temporal^{-1/2}``, the prewhitening filter) on the time axis."""
        matrix = self._tisqrt if inverse else self._tsqrt
        return torch.einsum("ts,bcs->bct", matrix.to(device=x.device, dtype=x.dtype), x)

    @staticmethod
    def _spatial(x: torch.Tensor, matrix: torch.Tensor) -> torch.Tensor:
        return torch.einsum("ij,bjt->bit", matrix.to(device=x.device, dtype=x.dtype), x)

    def color(self, z: torch.Tensor, pool_index: Optional[int] = None) -> torch.Tensor:
        """``δ = Σ^{1/2} z`` for whitened ``z`` of shape ``(B, C, T)`` (linear in ``z``)."""
        self._check(z)
        return self.temporal(self._spatial(z, self._sqrt[self._pool(pool_index)]))

    def whiten(self, delta: torch.Tensor, pool_index: Optional[int] = None) -> torch.Tensor:
        """``z = Σ^{-1/2} δ``, the exact inverse of :py:meth:`color`."""
        self._check(delta)
        return self._spatial(self.temporal(delta, inverse=True),
                             self._isqrt[self._pool(pool_index)])

    def dprime(self, delta: torch.Tensor, pool_index: Optional[int] = None) -> torch.Tensor:
        """d′ of each perturbation, ``‖Σ^{-1/2} δ‖₂`` over (C, T): ``(B,)``."""
        return _per_sample_norm(self.whiten(delta, pool_index))

    def sample(self,
               batch_size: int,
               generator: Optional[torch.Generator] = None,
               pool_index: Optional[int] = None,
               dtype: torch.dtype = torch.float32) -> torch.Tensor:
        """Colored Gaussian noise ``Σ^{1/2} ξ``, ``ξ ~ N(0, I)``: ``(B, C, T)`` (d′² ~ χ²_{CT})."""
        shape = (int(batch_size), self.num_channels, self.window_len)
        if generator is not None:
            xi = torch.randn(shape, generator=generator, device=generator.device, dtype=dtype)
            xi = xi.to(self.device)
        else:
            xi = torch.randn(shape, device=self.device, dtype=dtype)
        return self.color(xi, pool_index)

    def stationary_coloring(self, pool_index: Optional[int] = None) -> "StationaryColoring":
        """Layer-1 coloring for the attacks (whitened variable ``z`` of shape ``(B, C, T)``)."""
        return StationaryColoring(self, pool_index)

    def leadfield_coloring(self,
                           x0: torch.Tensor,
                           generator: Optional[torch.Generator] = None) -> "LeadfieldColoring":
        """Source-space coloring ``δ = L·s + n`` (needs a leadfield)."""
        return LeadfieldColoring(self, x0, generator)

    def noise_std(self) -> np.ndarray:
        """Per-channel noise standard deviation ``sqrt(diag Σ_spatial)``."""
        return np.sqrt(np.diag(self.spatial_cov))

    def summary(self) -> Dict[str, Any]:
        """JSON-serialisable description of the model."""
        std = self.noise_std()
        lag1 = (float(np.mean(np.diag(self.temporal_cov, 1))) if self.window_len > 1 else None)
        return {
            "num_channels": int(self.num_channels),
            "window_len": int(self.window_len),
            "pool_size": int(self.pool_size),
            "noise_std_median": float(np.median(std)),
            "noise_std_mean": float(np.mean(std)),
            "temporal_lag1_correlation": lag1,
            "spectrum_half": [float(v) for v in self.spectrum_half],
            "spatial_condition_number": float(np.linalg.cond(self.spatial_cov)),
            "leadfield_sources": (None if self.leadfield is None else int(self.leadfield.shape[1])),
            "leadfield_noise": self.leadfield_noise,
        }


class StationaryColoring:
    """Layer-1 coloring: ``δ = Σ^{1/2} z`` with ``z`` of shape ``(B, C, T)`` and ``d′ = ‖z‖₂``.

    Args:
        noise_model: The :py:class:`NoiseModel`.
        pool_index: Which Σ_spatial of the pool to use (0: the dataset's own).
    """

    def __init__(self, noise_model: NoiseModel, pool_index: Optional[int] = None):
        self.noise_model = noise_model
        self.pool_index = noise_model._pool(pool_index)

    def init_z(self, x0: torch.Tensor) -> torch.Tensor:
        """Zero perturbation for the batch ``x0``."""
        self.noise_model._check(x0)
        return torch.zeros_like(x0)

    def color(self, z: torch.Tensor) -> torch.Tensor:
        """Perturbation ``(B, C, T)`` of the whitened variable ``z``."""
        return self.noise_model.color(z, self.pool_index)

    def dprime(self, z: torch.Tensor) -> torch.Tensor:
        """d′ = ``‖z‖₂`` per sample."""
        return _per_sample_norm(z)

    def random_z(self, x0: torch.Tensor, radius, generator: Optional[torch.Generator] = None):
        """Random ``z`` with ``‖z_i‖₂ = radius_i`` (uniform direction)."""
        return _random_direction(tuple(x0.shape), x0, radius, generator)


class LeadfieldColoring:
    """Source-space coloring ``δ = L · s + n`` with the budget in source space.

    "For EEG/MEG with a leadfield L you can go further: δ = L·s + n (source-space
    perturbation plus sensor noise) with the budget in source space — physically realizable,
    not just plausible." The attack variable ``s`` has shape ``(B, S, T)``, is temporally
    colored with Σ_temporal (unit-variance sources), and ``d′ = ‖s‖₂`` (the budget in source
    space). ``n`` is natural sensor noise drawn once from the noise model at construction and
    scaled by ``leadfield_noise`` (no noise if 0); it is part of every perturbation, so
    ``color`` is affine rather than linear when ``leadfield_noise > 0``.

    Args:
        noise_model: :py:class:`NoiseModel` with a leadfield.
        x0: ``(B, C, T)`` clean windows (sets the batch size and device).
        generator: Generator of the sensor-noise draw.
    """

    def __init__(self,
                 noise_model: NoiseModel,
                 x0: torch.Tensor,
                 generator: Optional[torch.Generator] = None):
        if noise_model.leadfield is None:
            raise ValueError("The noise model has no leadfield.")
        noise_model._check(x0)
        self.noise_model = noise_model
        self.leadfield = noise_model.leadfield
        self.num_sources = int(self.leadfield.shape[1])
        self.noise = None
        if noise_model.leadfield_noise > 0:
            noise = noise_model.sample(x0.shape[0], generator=generator)
            self.noise = (noise_model.leadfield_noise * noise).to(device=x0.device,
                                                                 dtype=x0.dtype)

    def init_z(self, x0: torch.Tensor) -> torch.Tensor:
        """Zero source perturbation ``(B, S, T)``."""
        return x0.new_zeros((x0.shape[0], self.num_sources, x0.shape[2]))

    def color(self, z: torch.Tensor) -> torch.Tensor:
        """Sensor-space perturbation ``L · Σ_temporal^{1/2} s (+ n)``: ``(B, C, T)``."""
        sources = self.noise_model.temporal(z)
        delta = torch.einsum("cs,bst->bct",
                             self.leadfield.to(device=z.device, dtype=z.dtype), sources)
        if self.noise is not None:
            delta = delta + self.noise.to(device=z.device, dtype=z.dtype)
        return delta

    def dprime(self, z: torch.Tensor) -> torch.Tensor:
        """Source-space budget ``‖s‖₂`` per sample."""
        return _per_sample_norm(z)

    def random_z(self, x0: torch.Tensor, radius, generator: Optional[torch.Generator] = None):
        """Random source perturbation with ``‖s_i‖₂ = radius_i``."""
        shape = (x0.shape[0], self.num_sources, x0.shape[2])
        return _random_direction(shape, x0, radius, generator)


def fit_noise_model(neural: ArrayLike,
                    labels: Optional[ArrayLike] = None,
                    label_kind: Optional[str] = None,
                    window_len: int = 36,
                    residual_mode: str = "auto",
                    spatial_estimator: str = "ledoit_wolf",
                    temporal_method: str = "welch",
                    ar_order: int = 4,
                    vanrossum_tau: Optional[Union[float, str]] = "auto",
                    welch_nperseg: Optional[int] = None,
                    cov_pool: Optional[Sequence[ArrayLike]] = None,
                    leadfield: Optional[ArrayLike] = None,
                    leadfield_noise: float = 0.0,
                    kronecker_channels: int = 8,
                    device: Optional[Union[str, torch.device]] = None
                   ) -> Tuple[NoiseModel, Dict[str, Any]]:
    """Fit the Layer-1 noise model of a recording.

    Residuals (:py:func:`compute_residuals`) → Σ_spatial (:py:func:`spatial_covariance`) →
    Σ_temporal (:py:func:`temporal_covariance`) → :py:class:`NoiseModel`, plus the Kronecker
    check of the "Risks" paragraph.

    Args:
        neural: ``(n_time, C)`` recording (training data only).
        labels: Labels of the recording or None.
        label_kind: ``"discrete"``, ``"continuous"`` or None (inferred).
        window_len: Window length ``T`` (the receptive field of the model).
        residual_mode: See :py:func:`compute_residuals`.
        spatial_estimator: See :py:func:`spatial_covariance`.
        temporal_method: See :py:func:`temporal_covariance`.
        ar_order: AR order for ``temporal_method="ar"``.
        vanrossum_tau: τ for ``temporal_method="vanrossum"`` (``"auto"``: fitted).
        welch_nperseg: Welch segment length (default ``max(8T, 256)``).
        cov_pool: Extra spatial covariances (see :py:class:`NoiseModel`): ``(C, C)`` arrays, or
            names of estimators applied to this recording's residuals (e.g. ``"isotropic"``:
            mean residual variance × I), so that a pool of geometries can be configured
            without arrays ("sample Σ from the pool [...] so robustness isn't tied to one
            [...] noise structure").
        leadfield: Optional ``(C, S)`` leadfield.
        leadfield_noise: Sensor-noise scale of leadfield perturbations.
        kronecker_channels: Channels of the Kronecker check (0 disables it).
        device: Device of the model tensors.

    Returns:
        ``(noise_model, info)``; ``info`` is JSON-serialisable.
    """
    x = _recording(neural)
    used_mode = residual_mode
    kind = None
    if labels is not None:
        kind = _infer_label_kind(np.asarray(_to_numpy(labels)), label_kind)
        if residual_mode == "auto":
            used_mode = "class_mean" if kind == "discrete" else "regression"
    elif residual_mode == "auto":
        used_mode = "whole"
    if used_mode == "difference" and temporal_method in ("welch", "ar"):
        warnings.warn("The difference residuals are high-pass by construction, so a Welch / AR "
                      "temporal factor fitted on them is not the spectrum of the noise; use "
                      "temporal_method='white' with residual_mode='difference'.")
    residuals = compute_residuals(x, labels, used_mode, kind)
    spatial = spatial_covariance(residuals, spatial_estimator)
    tau = None
    if temporal_method == "vanrossum":
        tau = (fit_vanrossum_tau(residuals)
               if vanrossum_tau in (None, "auto") else float(vanrossum_tau))
    temporal = temporal_covariance(residuals, window_len, temporal_method, ar_order, tau,
                                   welch_nperseg)
    pool = None
    if cov_pool is not None:
        pool = [spatial_covariance(residuals, cov) if isinstance(cov, str) else cov
                for cov in cov_pool]
    model = NoiseModel(spatial,
                       temporal,
                       cov_pool=pool,
                       leadfield=leadfield,
                       leadfield_noise=leadfield_noise,
                       device=device)
    kronecker = None
    if kronecker_channels and kronecker_channels > 0 and len(residuals) >= window_len:
        kronecker = kronecker_check(residuals,
                                    window_len,
                                    n_channels=kronecker_channels,
                                    spatial_cov=model.spatial_cov,
                                    temporal_cov=model.temporal_cov)
    info = {
        "residual_mode": used_mode,
        "label_kind": kind,
        "spatial_estimator": spatial_estimator,
        "temporal_method": temporal_method,
        "ar_order": int(ar_order) if temporal_method == "ar" else None,
        "vanrossum_tau": tau,
        "n_time": int(len(x)),
        "kronecker_check": kronecker,
    }
    info.update(model.summary())
    return model, info
