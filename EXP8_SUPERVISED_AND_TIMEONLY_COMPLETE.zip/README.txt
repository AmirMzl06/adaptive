Exp8 behavior-supervised CEBRA: 216 successful models.
Time-only Exp5+Exp6: 162 matched models.
9 sessions; seeds 42, 43, 44.
Main baseline: PGD_L2_EPS6.
Extra supervised arms: PGD_L2_EPS3, MADRY_SPREG_D8.
All robustness curves, reports, configs and logs included.
Model .pt checkpoints were verified but excluded to save space.
Half-R2 epsilon values should be checked for lower-grid clipping.
