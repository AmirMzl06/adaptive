"""Layer 3: physiological invariants (Section 3 of ``DPRIME_DESIGN.md``).

"Define a small set of guards whose tolerances come from *natural within-class,
within-subject variability* rather than hand-picked thresholds:

- log band power per channel (change ≤ τ × within-class SD);
- aperiodic exponent and offset from specparam/FOOOF;
- the trial covariance on the SPD manifold: affine-invariant Riemannian distance
  d_R(C_x, C_{x+δ}) ≤ median same-class nearest-neighbour d_R;
- ERP peak latency/amplitude in the component window, for ERP tasks;
- an artifact-rejection pass (Autoreject thresholds, ICLabel) at the same rate as clean trials.

Enforce them with a backtracking rule inside PGD [...] plus a final accept/reject; d_R is
differentiable, so it can also be a soft penalty."

The backtracking itself lives in :py:func:`cebra.dprime.attacks.dprime_pgd`; this module
provides the features, the tolerances (:py:meth:`GuardSet.fit`), the hard check
(:py:meth:`GuardSet.check`) and the soft penalty (:py:meth:`GuardSet.soft_penalty`).
Spectral features use frequencies in cycles per bin times ``sampling_rate``. ICLabel needs an
ICA of EEG montages and has no analogue for spike data; it is not implemented.
"""

import math
import warnings
from typing import Dict, Optional, Sequence, Tuple, Union

import numpy as np
import torch

__all__ = [
    "GUARD_NAMES",
    "DEFAULT_GUARDS",
    "DEFAULT_BANDS",
    "periodogram",
    "log_band_power",
    "aperiodic_params",
    "window_covariance",
    "riemann_distance",
    "erp_features",
    "peak_to_peak",
    "GuardSet",
]

GUARD_NAMES = ("band_power", "aperiodic", "riemann", "erp", "artifact")
DEFAULT_GUARDS = ("band_power", "aperiodic", "riemann", "artifact")
#: Default bands in cycles per bin (multiplied by ``sampling_rate``).
DEFAULT_BANDS = ((0.0, 0.05), (0.05, 0.15), (0.15, 0.30), (0.30, 0.50))

#: Minimum window length of the spectral guards (band power, aperiodic).
MIN_SPECTRAL_LEN = 4

_SD_FLOOR = 1e-6
_CHUNK = 4096


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------


def periodogram(x: torch.Tensor,
                fs: float = 1.0,
                tapers: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
    """Hann-windowed (or multitaper) periodogram of each channel (mean removed).

    Args:
        x: ``(B, C, T)`` windows.
        fs: Sampling rate (bins per unit of frequency).
        tapers: Optional ``(K, T)`` tapers (e.g. :py:func:`cebra.dprime.trial_mask.dpss_tapers`);
            the estimate is then the average of the K tapered periodograms (multitaper), which
            has ``2K`` instead of 2 degrees of freedom per bin.

    Returns:
        ``(power (B, C, T // 2 + 1), freqs (T // 2 + 1,))``; the power is the two-sided
        spectral density on the rfft grid, so its two-sided sum is ``≈ variance / fs``.
    """
    window_len = x.shape[-1]
    centred = x - x.mean(dim=-1, keepdim=True)
    freqs = torch.fft.rfftfreq(window_len, d=1.0 / fs).to(device=x.device, dtype=x.dtype)
    if tapers is None:
        window = torch.hann_window(window_len, periodic=True, device=x.device, dtype=x.dtype)
        spectrum = torch.fft.rfft(centred * window, dim=-1)
        power = (spectrum.real**2 + spectrum.imag**2) / (fs * window.pow(2).sum())
        return power, freqs
    tapers = tapers.to(device=x.device, dtype=x.dtype)
    spectrum = torch.fft.rfft(centred[..., None, :] * tapers, dim=-1)  # (B, C, K, F)
    power = (spectrum.real**2 + spectrum.imag**2) / (fs * tapers.pow(2).sum(dim=-1, keepdim=True))
    return power.mean(dim=-2), freqs


def _band_masks(freqs: torch.Tensor, bands: Sequence[Tuple[float, float]]) -> torch.Tensor:
    """``(n_bands, F)`` float masks; an empty band takes the nearest frequency bin.

    The DC bin is never used: the windows are mean-removed, so its power is a residual of the
    taper that crosses zero and makes the log power arbitrarily sensitive.
    """
    masks = []
    top = float(freqs.max())
    nonzero = freqs > 0
    if not bool(nonzero.any()):
        raise ValueError("Band power needs windows with at least two samples.")
    for low, high in bands:
        mask = nonzero & (freqs >= low) & ((freqs < high) | ((freqs <= high) & (high >= top)))
        if not bool(mask.any()):
            centre = 0.5 * (low + high)
            distance = (freqs - centre).abs().masked_fill(~nonzero, math.inf)
            mask = torch.zeros_like(freqs, dtype=torch.bool)
            mask[int(torch.argmin(distance))] = True
        masks.append(mask)
    return torch.stack(masks).to(freqs.dtype)


def log_band_power(x: torch.Tensor,
                   bands: Optional[Sequence[Tuple[float, float]]] = None,
                   fs: float = 1.0,
                   tapers: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Log mean power in each band of each channel: ``(B, C, n_bands)`` (differentiable).

    Args:
        x: ``(B, C, T)`` windows.
        bands: ``(low, high)`` pairs in the units of ``fs``; default :py:data:`DEFAULT_BANDS`
            scaled by ``fs``.
        fs: Sampling rate.
        tapers: Optional multitaper tapers (see :py:func:`periodogram`).
    """
    power, freqs = periodogram(x, fs, tapers)
    bands = bands if bands is not None else tuple((lo * fs, hi * fs) for lo, hi in DEFAULT_BANDS)
    masks = _band_masks(freqs, bands)
    mean_power = torch.einsum("bcf,nf->bcn", power, masks) / masks.sum(dim=1)
    return torch.log(mean_power + 1e-12)


def aperiodic_params(x: torch.Tensor,
                     fs: float = 1.0,
                     f_range: Optional[Tuple[float, float]] = None,
                     tapers: Optional[torch.Tensor] = None
                    ) -> Tuple[torch.Tensor, torch.Tensor]:
    """Aperiodic offset and exponent of each channel's spectrum (specparam "fixed" mode).

    Least-squares fit of ``log10 P(f) = offset − exponent · log10 f`` over the non-zero
    frequencies in ``f_range`` (no knee, no periodic peaks).

    Args:
        x: ``(B, C, T)`` windows.
        fs: Sampling rate.
        f_range: ``(low, high)`` frequency range; default all non-zero frequencies.
        tapers: Optional multitaper tapers (see :py:func:`periodogram`).

    Returns:
        ``(offset (B, C), exponent (B, C))``.
    """
    power, freqs = periodogram(x, fs, tapers)
    mask = freqs > 0
    if f_range is not None:
        mask &= (freqs >= f_range[0]) & (freqs <= f_range[1])
    if int(mask.sum()) < 2:
        raise ValueError("Need at least two non-zero frequencies for the aperiodic fit.")
    log_f = torch.log10(freqs[mask])
    log_p = torch.log10(power[..., mask] + 1e-12)
    centred_f = log_f - log_f.mean()
    slope = (log_p * centred_f).sum(dim=-1) / centred_f.pow(2).sum()
    offset = log_p.mean(dim=-1) - slope * log_f.mean()
    return offset, -slope


def window_covariance(x: torch.Tensor,
                      channels: Optional[torch.Tensor] = None,
                      shrink: float = 0.1) -> torch.Tensor:
    """Shrunk channel covariance of each window: ``(B, c, c)``.

    ``cov + (shrink · trace(cov)/c + 1e-6) · I``; the shrinkage keeps windows with fewer time
    bins than channels (and silent channels) positive definite.
    """
    if channels is not None:
        x = x[:, channels]
    centred = x - x.mean(dim=-1, keepdim=True)
    cov = centred @ centred.transpose(1, 2) / x.shape[-1]
    c = cov.shape[-1]
    trace = torch.diagonal(cov, dim1=-2, dim2=-1).sum(-1)
    ridge = shrink * trace / c + 1e-6
    eye = torch.eye(c, device=x.device, dtype=x.dtype)
    return cov + ridge[:, None, None] * eye


def riemann_distance(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Affine-invariant Riemannian distance between SPD matrices: ``(B,)``.

    ``d_R(A, B) = ‖log(A^{-1/2} B A^{-1/2})‖_F = sqrt(Σ_i log² λ_i)`` with ``λ_i`` the
    eigenvalues of ``L⁻¹ B L⁻ᵀ`` (``A = L Lᵀ``). Differentiable in both arguments.
    """
    a = 0.5 * (a + a.transpose(-1, -2))
    chol, info = torch.linalg.cholesky_ex(a)
    if bool((info > 0).any()):
        jitter = 1e-6 * torch.diagonal(a, dim1=-2, dim2=-1).abs().mean(-1).clamp_min(1e-12)
        eye = torch.eye(a.shape[-1], device=a.device, dtype=a.dtype)
        chol = torch.linalg.cholesky(a + jitter[:, None, None] * eye)
    left = torch.linalg.solve_triangular(chol, b, upper=False)
    whitened = torch.linalg.solve_triangular(chol, left.transpose(-1, -2), upper=False)
    whitened = 0.5 * (whitened + whitened.transpose(-1, -2))
    eigenvalues = torch.linalg.eigvalsh(whitened).clamp_min(1e-12)
    # Clamp before the square root: d_R = 0 (x_adv == x0 at the start of every attack) would
    # otherwise give a 0/0 = NaN gradient through the soft penalty.
    return torch.log(eigenvalues).pow(2).sum(dim=-1).clamp_min(1e-24).sqrt()


def _log_euclidean(cov: torch.Tensor) -> torch.Tensor:
    """Matrix logarithm, vectorised with √2 off-diagonal weights: ``(B, c(c+1)/2)``."""
    eigenvalues, eigenvectors = torch.linalg.eigh(cov)
    log = (eigenvectors * torch.log(eigenvalues.clamp_min(1e-12))[:, None, :]) \
        @ eigenvectors.transpose(-1, -2)
    c = cov.shape[-1]
    rows, cols = torch.triu_indices(c, c, device=cov.device)
    weights = torch.where(rows == cols, 1.0, math.sqrt(2.0)).to(cov.dtype)
    return log[:, rows, cols] * weights


def erp_features(x: torch.Tensor, window: Tuple[int, int]) -> Tuple[torch.Tensor, torch.Tensor]:
    """ERP peak amplitude and latency of each channel in a component window.

    Args:
        x: ``(B, C, T)`` windows.
        window: ``(start, stop)`` bins of the component window.

    Returns:
        ``(amplitude (B, C), latency (B, C))``: the signed value at the largest ``|x|`` inside
        the window and its position (bins from the window start of ``x``).
    """
    start, stop = int(window[0]), int(window[1])
    if not 0 <= start < stop <= x.shape[-1]:
        raise ValueError(f"Invalid ERP window {window} for windows of {x.shape[-1]} bins.")
    segment = x[..., start:stop]
    index = segment.abs().argmax(dim=-1, keepdim=True)
    amplitude = segment.gather(-1, index).squeeze(-1)
    return amplitude, (index.squeeze(-1) + start).to(x.dtype)


def peak_to_peak(x: torch.Tensor) -> torch.Tensor:
    """Peak-to-peak amplitude of each channel: ``(B, C)``."""
    return x.amax(dim=-1) - x.amin(dim=-1)


# ---------------------------------------------------------------------------
# Guard set
# ---------------------------------------------------------------------------


def _within_class_sd(features: torch.Tensor, classes: torch.Tensor) -> torch.Tensor:
    """Pooled within-class standard deviation of ``(M, ...)`` features."""
    flat = features.reshape(len(features), -1).double()
    total = torch.zeros(flat.shape[1], dtype=torch.float64, device=flat.device)
    dof = 0
    for value in torch.unique(classes):
        group = flat[classes == value]
        if len(group) < 2:
            continue
        total += (group - group.mean(dim=0)).pow(2).sum(dim=0)
        dof += len(group) - 1
    if dof == 0:
        sd = flat.std(dim=0) if len(flat) > 1 else torch.zeros_like(total)
    else:
        sd = (total / dof).sqrt()
    floor = _SD_FLOOR * (1.0 + float(sd.mean()) if sd.numel() else 1.0)
    return sd.clamp_min(floor).float().reshape(features.shape[1:])


class GuardSet:
    """Physiological guards with tolerances from natural within-class variability.

    Args:
        guards: Names among :py:data:`GUARD_NAMES` (``"erp"`` needs ``erp_window``).
        tau: Multiplier τ of the within-class SD ("change ≤ τ × within-class SD").
        bands: Frequency bands for the band-power guard (units of ``sampling_rate``).
        sampling_rate: Sampling rate of the windows (1: frequencies in cycles per bin).
        erp_window: ``(start, stop)`` bins of the ERP component window.
        riemann_channels: Number of highest-variance channels of the covariance guard.
        riemann_shrink: Shrinkage of the window covariances (see :py:func:`window_covariance`).
        artifact_rate: Fraction of clean windows rejected by the artifact thresholds.
        nn_max_per_class: Windows per class used for the nearest-neighbour tolerance.
        seed: Seed of the subsampling.
        multitaper_nw: Time-half-bandwidth of the DPSS tapers of the spectral guards.
        multitaper_k: Number of DPSS tapers (0: a single Hann window). Single-window log
            powers of short windows have 2 degrees of freedom per bin and are often near zero,
            where a tiny δ moves the log power by more than its natural SD; the multitaper
            estimate (2K degrees of freedom) is the standard remedy.

    Spectral guards (band power, aperiodic) need windows of at least
    :py:data:`MIN_SPECTRAL_LEN` samples and the others at least 2; for shorter windows (e.g.
    ``offset1`` models) they are dropped with a warning in :py:meth:`fit` (see ``disabled`` in
    :py:meth:`report`).
    """

    def __init__(self,
                 guards: Sequence[str] = DEFAULT_GUARDS,
                 tau: float = 1.0,
                 bands: Optional[Sequence[Tuple[float, float]]] = None,
                 sampling_rate: float = 1.0,
                 erp_window: Optional[Tuple[int, int]] = None,
                 riemann_channels: int = 32,
                 riemann_shrink: float = 0.1,
                 artifact_rate: float = 0.01,
                 nn_max_per_class: int = 256,
                 seed: int = 0,
                 multitaper_nw: float = 2.0,
                 multitaper_k: int = 3):
        self.guards = tuple(guards)
        unknown = [g for g in self.guards if g not in GUARD_NAMES]
        if unknown:
            raise ValueError(f"Unknown guards {unknown}; choose from {GUARD_NAMES}.")
        if "erp" in self.guards and erp_window is None:
            raise ValueError("The 'erp' guard needs erp_window=(start, stop).")
        if not tau > 0:
            raise ValueError(f"tau must be positive, got {tau}.")
        if not 0.0 <= artifact_rate < 1.0:
            raise ValueError(f"artifact_rate must be in [0, 1), got {artifact_rate}.")
        self.tau = float(tau)
        self.sampling_rate = float(sampling_rate)
        self.bands = (tuple((float(lo), float(hi)) for lo, hi in bands) if bands is not None
                      else tuple((lo * self.sampling_rate, hi * self.sampling_rate)
                                 for lo, hi in DEFAULT_BANDS))
        self.erp_window = None if erp_window is None else (int(erp_window[0]), int(erp_window[1]))
        self.riemann_channels = int(riemann_channels)
        self.riemann_shrink = float(riemann_shrink)
        self.artifact_rate = float(artifact_rate)
        self.nn_max_per_class = int(nn_max_per_class)
        self.seed = int(seed)
        self.multitaper_nw = float(multitaper_nw)
        self.multitaper_k = int(multitaper_k)
        self.tapers: Optional[torch.Tensor] = None
        self.disabled: Tuple[str, ...] = ()
        self.tolerances: Dict[str, torch.Tensor] = {}
        self.channels: Optional[torch.Tensor] = None
        self.fitted = False

    def _make_tapers(self, window_len: int) -> Optional[torch.Tensor]:
        if self.multitaper_k <= 0:
            return None
        from cebra.dprime.trial_mask import dpss_tapers
        nw = min(self.multitaper_nw, 0.5 * (window_len - 1))
        k = max(1, min(self.multitaper_k, int(2 * nw) - 1))
        return dpss_tapers(window_len, nw, k)

    # -- fitting ------------------------------------------------------------------------
    def fit(self,
            windows: torch.Tensor,
            classes: Optional[Union[torch.Tensor, np.ndarray]] = None,
            times: Optional[Union[torch.Tensor, np.ndarray]] = None,
            exclusion: int = 0) -> "GuardSet":
        """Tolerances from clean training windows.

        Args:
            windows: ``(M, C, T)`` clean windows.
            classes: ``(M,)`` class ids (None: one class).
            times: ``(M,)`` time indices of the windows (for the temporal exclusion).
            exclusion: Windows with ``|t − t'| < exclusion`` are not nearest neighbours.

        Returns:
            ``self``.
        """
        windows = windows.detach().float()
        device = windows.device
        num = len(windows)
        if num < 2:
            raise ValueError("Need at least two windows to fit the guards.")
        classes = (torch.zeros(num, dtype=torch.long, device=device) if classes is None else
                   torch.as_tensor(np.asarray(classes) if not torch.is_tensor(classes) else classes,
                                   device=device).long().reshape(-1))
        times = (None if times is None else torch.as_tensor(
            np.asarray(times) if not torch.is_tensor(times) else times, device=device).long())
        self.tolerances = {}
        window_len = windows.shape[-1]
        too_short = tuple(g for g in self.guards
                          if (g in ("band_power", "aperiodic") and window_len < MIN_SPECTRAL_LEN)
                          or (g in ("riemann", "artifact", "erp") and window_len < 2))
        if too_short:
            warnings.warn(f"Windows of {window_len} samples are too short for the guards "
                          f"{too_short}; they are disabled.")
            self.disabled = self.disabled + too_short
            self.guards = tuple(g for g in self.guards if g not in too_short)
        self.tapers = self._make_tapers(window_len) if window_len >= MIN_SPECTRAL_LEN else None
        if "band_power" in self.guards:
            features = log_band_power(windows, self.bands, self.sampling_rate, self.tapers)
            self.tolerances["band_power"] = self.tau * _within_class_sd(features, classes)
        if "aperiodic" in self.guards:
            offset, exponent = aperiodic_params(windows, self.sampling_rate, tapers=self.tapers)
            self.tolerances["aperiodic_offset"] = self.tau * _within_class_sd(offset, classes)
            self.tolerances["aperiodic_exponent"] = self.tau * _within_class_sd(exponent, classes)
        if "erp" in self.guards:
            amplitude, latency = erp_features(windows, self.erp_window)
            self.tolerances["erp_amplitude"] = self.tau * _within_class_sd(amplitude, classes)
            self.tolerances["erp_latency"] = (self.tau * _within_class_sd(latency, classes)
                                              ).clamp_min(0.5)
        if "riemann" in self.guards:
            self._fit_riemann(windows, classes, times, int(exclusion))
        if "artifact" in self.guards:
            self._fit_artifact(windows)
        self.fitted = True
        return self

    def _fit_riemann(self, windows, classes, times, exclusion):
        variance = windows.var(dim=(0, 2))
        count = min(self.riemann_channels, windows.shape[1])
        self.channels = torch.sort(torch.argsort(variance, descending=True)[:count]).values
        generator = torch.Generator().manual_seed(self.seed)
        distances = []
        for value in torch.unique(classes):
            index = torch.nonzero(classes == value).reshape(-1)
            if len(index) > self.nn_max_per_class:
                pick = torch.randperm(len(index), generator=generator)[:self.nn_max_per_class]
                index = index[pick.to(index.device)]
            if len(index) < 2:
                continue
            covs = window_covariance(windows[index], self.channels, self.riemann_shrink)
            embedding = _log_euclidean(covs.double())
            pairwise = torch.cdist(embedding, embedding)
            pairwise.fill_diagonal_(math.inf)
            if times is not None and exclusion > 1:
                t = times[index]
                pairwise = pairwise.masked_fill((t[:, None] - t[None, :]).abs() < exclusion, math.inf)
            best, neighbour = pairwise.min(dim=1)
            valid = torch.isfinite(best)
            if bool(valid.any()):
                distances.append(riemann_distance(covs[valid].double(),
                                                  covs[neighbour[valid]].double()).float())
        if distances:
            tolerance = torch.cat(distances).median()
        else:
            warnings.warn("No same-class nearest neighbour for the Riemannian guard; disabled.")
            tolerance = torch.tensor(math.inf)
        self.tolerances["riemann"] = tolerance.to(windows.device)

    def _fit_artifact(self, windows):
        ptp = peak_to_peak(windows)  # (M, C)
        if self.artifact_rate <= 0:
            self.tolerances["artifact"] = ptp.amax(dim=0)
            return
        low, high = 0.5, 1.0
        for _ in range(40):
            q = 0.5 * (low + high)
            thresholds = torch.quantile(ptp, q, dim=0)
            rate = float((ptp > thresholds).any(dim=1).float().mean())
            if rate > self.artifact_rate:
                low = q
            else:
                high = q
        thresholds = torch.quantile(ptp, high, dim=0)
        # Move each threshold half-way to the next larger observed peak-to-peak value: the same
        # clean windows are rejected, but with discrete data (spike counts) the many clean windows
        # sitting exactly at the threshold are no longer rejected by an arbitrarily small δ.
        # Without a larger value (threshold = maximum) use half the spacing below it instead.
        above = ptp.masked_fill(ptp <= thresholds, math.inf).amin(dim=0)
        below = ptp.masked_fill(ptp >= thresholds, -math.inf).amax(dim=0)
        gap = torch.where(torch.isfinite(above), 0.5 * (above - thresholds),
                          torch.where(torch.isfinite(below), 0.5 * (thresholds - below),
                                      torch.zeros_like(thresholds)))
        self.tolerances["artifact"] = thresholds + gap

    # -- checks -------------------------------------------------------------------------
    def _tol(self, name, like):
        return self.tolerances[name].to(device=like.device, dtype=like.dtype)

    def check(self, x0: torch.Tensor,
              x_adv: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Which perturbed windows satisfy every guard.

        Args:
            x0: ``(B, C, T)`` clean windows.
            x_adv: ``(B, C, T)`` perturbed windows.

        Returns:
            ``(ok (B,) bool, {guard: (B,) bool})``.
        """
        if not self.fitted:
            raise RuntimeError("Call GuardSet.fit before check.")
        details = {}
        with torch.no_grad():
            if "band_power" in self.guards:
                change = (log_band_power(x_adv, self.bands, self.sampling_rate, self.tapers) -
                          log_band_power(x0, self.bands, self.sampling_rate, self.tapers)).abs()
                details["band_power"] = (change <= self._tol("band_power", change)).flatten(1).all(1)
            if "aperiodic" in self.guards:
                off0, exp0 = aperiodic_params(x0, self.sampling_rate, tapers=self.tapers)
                off1, exp1 = aperiodic_params(x_adv, self.sampling_rate, tapers=self.tapers)
                details["aperiodic"] = (
                    ((off1 - off0).abs() <= self._tol("aperiodic_offset", off0)).all(1) &
                    ((exp1 - exp0).abs() <= self._tol("aperiodic_exponent", exp0)).all(1))
            if "erp" in self.guards:
                amp0, lat0 = erp_features(x0, self.erp_window)
                amp1, lat1 = erp_features(x_adv, self.erp_window)
                details["erp"] = (((amp1 - amp0).abs() <= self._tol("erp_amplitude", amp0)).all(1) &
                                  ((lat1 - lat0).abs() <= self._tol("erp_latency", lat0)).all(1))
            if "riemann" in self.guards:
                # The slack covers the 1e-12 floor of riemann_distance (zero tolerance case).
                tolerance = self._tol("riemann", x0)
                details["riemann"] = self.riemann_change(x0, x_adv) <= tolerance * (1 + 1e-6) + 1e-9
            if "artifact" in self.guards:
                thresholds = self._tol("artifact", x0)
                rejected_adv = (peak_to_peak(x_adv) > thresholds).any(dim=1)
                rejected_clean = (peak_to_peak(x0) > thresholds).any(dim=1)
                details["artifact"] = ~rejected_adv | rejected_clean
        ok = torch.ones(len(x0), dtype=torch.bool, device=x0.device)
        for passed in details.values():
            ok &= passed
        return ok, details

    def riemann_change(self, x0: torch.Tensor, x_adv: torch.Tensor) -> torch.Tensor:
        """``d_R(C_x0, C_xadv)`` on the guard's channels: ``(B,)`` (differentiable in x_adv)."""
        channels = None if self.channels is None else self.channels.to(x0.device)
        dtype = torch.float64 if x0.device.type == "cpu" else x0.dtype
        cov0 = window_covariance(x0.detach().to(dtype), channels, self.riemann_shrink)
        cov1 = window_covariance(x_adv.to(dtype), channels, self.riemann_shrink)
        return riemann_distance(cov0, cov1).to(x0.dtype)

    def soft_penalty(self, x0: torch.Tensor, x_adv: torch.Tensor) -> torch.Tensor:
        """``relu(d_R − tolerance)²`` per sample (differentiable); zeros without the guard."""
        if "riemann" not in self.guards or not self.fitted:
            return x_adv.new_zeros(len(x_adv))
        tolerance = self._tol("riemann", x_adv)
        if not bool(torch.isfinite(tolerance)):
            return x_adv.new_zeros(len(x_adv))
        return torch.relu(self.riemann_change(x0, x_adv) - tolerance).pow(2)

    def report(self) -> Dict[str, object]:
        """JSON-serialisable summary of the guards and their tolerances."""
        summary: Dict[str, object] = {
            "guards": list(self.guards),
            "tau": self.tau,
            "bands": [list(b) for b in self.bands],
            "sampling_rate": self.sampling_rate,
            "erp_window": None if self.erp_window is None else list(self.erp_window),
            "artifact_rate": self.artifact_rate,
            "spectrum": ("hann" if self.tapers is None else
                         f"multitaper(nw={self.multitaper_nw}, k={len(self.tapers)})"),
            "disabled": list(self.disabled),
        }
        for name, value in self.tolerances.items():
            value = value.detach().float().cpu()
            if value.numel() == 1:
                summary[f"tol_{name}"] = float(value)
            else:
                summary[f"tol_{name}_median"] = float(value.median())
        if self.channels is not None:
            summary["riemann_channels"] = int(len(self.channels))
        return summary
