"""Robustness of a fitted CEBRA encoder + behaviour decoder in the d′ metric (Section 7 of
``DPRIME_DESIGN.md``).

The note: "run a minimum-norm attack (FMN/DDN in the whitened metric) to measure each trial's
distance to the decision boundary in d′. The ratio median(d′_boundary)/ε* is a
dataset-intrinsic robustness margin [...] Reporting this margin across datasets and models is
arguably the headline result"; the key figures include "ASR vs ε(d′) overlaid across datasets
on one axis" and "the robustness-margin table"; and "evaluate with the min-norm attack
alongside PGD to rule out gradient masking".

:py:func:`evaluate_decoding` measures this on held-out data for any fitted single-session
``cebra.CEBRA`` (clean, constant-ε PGD or d′ training) followed by a differentiable decoder
(a ``torch.nn.Module`` from the embedding to the behaviour):

* ``robust_r2``: R² of ``decoder(encoder(x + δ))`` when every window is attacked by d′-APGD
  maximising its standardised squared decoding error (the loss of the per-output R²) under
  ``‖δ‖_Σ ≤ ε``, for every ε of ``epsilons`` (the "ASR vs ε" curve of a regression decoder);
  ``eps_at_half_r2`` is the ε (log-interpolated) where it falls to half the clean R². The
  budgets are attacked in increasing order, each APGD run warm-started at the solution of the
  previous budget, and every window keeps its worst perturbation found at any budget ≤ ε
  (feasible at ε), so the curve is a monotone worst-case estimate (``r2``); ``r2_single`` is
  the R² of that budget's own run; with ``refine`` > 0, ``eps_at_half_r2_refined`` narrows the
  bracket of the crossing by bisection in log ε (one extra attack per step, warm-started at the
  bracket's lower end) and, when the smallest budget already halves the R², first searches
  below the grid (budgets halved down to ``refine_floor``), so floor values become measurements;
* ``decoding_margin``: per window, the minimum d′ (DDN with scale-free steps) that moves the
  decoded behaviour by ``shift_threshold`` behaviour SDs (RMS over the outputs), summarised
  by :py:func:`cebra.dprime.calibration.robustness_margin` with ε_JND as the reference;
* ``contrastive_margin``: the margin of the time-contrastive objective (decision ``"chance"``:
  the window one time offset later is no longer identified better than a random window) on
  held-out windows, the held-out version of the margin of :py:mod:`cebra.dprime.training`;
* ``natural_noise_r2``: R² after adding one draw of the metric's noise (d′ ≈ √(C·T)), the
  scale of natural variability;
* with ``behaviour_train``: ``eps_beh``, the behavioural separation of the training recording in
  the metric (:py:func:`cebra.dprime.calibration.eps_behaviour`), and ``kappa`` = ε½ / ε_beh,
  the robustness in units of the separation between behavioural states (comparable across
  sessions and datasets; on Perich ε½ ≈ κ·ε_beh with a κ per training method).

:py:func:`evaluate_detectability` asks which threat geometry is the stealthier one: the same
decoder attacks, scored by the note's two detectors ("a detector trained to separate clean from
adversarial trials (plus a clean-only anomaly detector such as an autoencoder)") and compared at
equal damage to the decoder.

Every quantity is computed in fixed metrics fitted on the training recording, so all models
are on the same axes whatever their training geometry: ``"reference"`` (the note's
Ledoit–Wolf ⊗ Welch metric) and ``"isotropic"`` (``‖δ‖₂ / σ̄`` with σ̄² the mean residual
variance; ``σ̄ · ε`` is the raw L2 radius in input units).
"""

import math
import time
from typing import Any, Callable, Dict, List, Optional, Sequence

import numpy as np
import numpy.typing as npt
import sklearn.metrics
import torch

from cebra.dprime import attacks
from cebra.dprime import calibration
from cebra.dprime import noise
from cebra.dprime.training import DprimeTrainer

__all__ = ["METRICS", "common_metrics", "evaluate_decoding", "evaluate_detectability"]

METRICS = ("reference", "isotropic")
# Growth of the DDN norm per step before the first adversarial iterate (margin searches).
_MARGIN_GROWTH = 0.3


def common_metrics(x_train: npt.ArrayLike,
                   window_len: int,
                   labels: Optional[npt.ArrayLike] = None,
                   residuals: str = "whole",
                   device=None) -> Dict[str, noise.NoiseModel]:
    """The fixed metrics of the evaluation, fitted on the training recording.

    Args:
        x_train: ``(n_time, C)`` training recording.
        window_len: Receptive field ``T`` of the encoder.
        labels: Labels for the residuals (None: the label-free ``"whole"`` residuals, as in
            time-only training).
        residuals: Residual mode (see :py:func:`cebra.dprime.noise.compute_residuals`).
        device: Device of the models.

    Returns:
        ``{"reference": Ledoit–Wolf ⊗ Welch model, "isotropic": σ̄² I ⊗ I model}``.
    """
    reference, info = noise.fit_noise_model(x_train,
                                            labels,
                                            window_len=window_len,
                                            residual_mode=residuals,
                                            spatial_estimator="ledoit_wolf",
                                            temporal_method="welch",
                                            kronecker_channels=0,
                                            device=device)
    residual = noise.compute_residuals(x_train, labels, info["residual_mode"])
    variance = max(float(residual.var(axis=0).mean()), 1e-12)
    isotropic = noise.NoiseModel(np.eye(reference.num_channels) * variance,
                                 np.eye(window_len),
                                 device=device)
    return {"reference": reference, "isotropic": isotropic}


def _encoder_model(encoder):
    """The torch model of a fitted single-session ``cebra.CEBRA`` and its receptive field."""
    if getattr(encoder, "num_sessions", None) is not None:
        raise ValueError("evaluate_decoding supports single-session models only.")
    if not getattr(encoder, "pad_before_transform", True):
        raise ValueError("evaluate_decoding mirrors CEBRA.transform with "
                         "pad_before_transform=True (one embedding per time bin).")
    model = encoder.model_
    offset = model.get_offset()
    return model, int(offset.left), int(offset.right)


class _Windows:
    """Receptive-field windows ``(B, C, T)`` of a recording, edge-padded like
    ``CEBRA.transform``: the window of bin ``t`` is the input of its embedding."""

    def __init__(self, recording: np.ndarray, left: int, right: int, device):
        padded = np.pad(recording, ((left, right - 1), (0, 0)), mode="edge")
        self.padded = torch.from_numpy(np.ascontiguousarray(padded, dtype=np.float32)).to(device)
        self.offsets = torch.arange(left + right, device=device)

    def __call__(self, index: torch.Tensor) -> torch.Tensor:
        return self.padded[index[:, None] + self.offsets[None, :]].transpose(1, 2).contiguous()


def _embed(model, x: torch.Tensor) -> torch.Tensor:
    out = model(x)
    if out.ndim == 3:
        if out.shape[-1] != 1:
            raise ValueError(f"Expected one embedding per window, got {tuple(out.shape)}.")
        out = out[..., 0]
    return out


def _r2(target: np.ndarray, prediction: np.ndarray) -> float:
    """Mean over the outputs of the per-output R² (the runner's metric)."""
    return float(
        np.mean(sklearn.metrics.r2_score(target, prediction, multioutput="raw_values")))


def _crossing(curve: List[Dict[str, Any]], level: float) -> Optional[float]:
    """Smallest ε where the robust R² reaches ``level`` (log-ε interpolation; None: never)."""
    previous = None
    for point in curve:
        eps, r2 = point["epsilon"], point["r2"]
        if r2 <= level:
            if previous is None or previous[0] <= 0 or eps <= 0:
                return eps
            (e0, r0), (e1, r1) = previous, (eps, r2)
            if r0 == r1:
                return e1
            weight = (r0 - level) / (r0 - r1)
            return float(math.exp(math.log(e0) + weight * (math.log(e1) - math.log(e0))))
        previous = (eps, r2)
    return None


def _refine_half(run_budget, below, above, level: float, steps: int, floor: float,
                 generator) -> Dict[str, Any]:
    """Bisection (log ε) of the half-R² crossing between the last budget of the curve above
    ``level`` (``below`` = (ε, state, r2); ε = 0: the clean state) and the first one at or below
    it (``above`` = (ε, r2) or None). Below the grid, budgets are first halved from the clean state
    down to ``floor``. Every new budget is warm-started at the state of the bracket's lower end
    and keeps its worst case, like the curve itself."""
    points: List[Dict[str, Any]] = []
    if above is None:
        return {"epsilon": None, "status": "above_grid", "lower_bound": below[0],
                "points": points}
    lo_eps, lo_state, lo_r2 = below
    hi_eps, hi_r2 = above
    if lo_eps <= 0:
        clean_state, eps = lo_state, hi_eps / 2
        while eps >= floor * (1 - 1e-9):
            point, state = run_budget(eps, clean_state, generator)
            points.append(point)
            if point["r2"] > level:
                lo_eps, lo_state, lo_r2 = eps, state, point["r2"]
                break
            hi_eps, hi_r2 = eps, point["r2"]
            eps /= 2
        if lo_eps <= 0:
            return {"epsilon": None, "status": "below_floor", "upper_bound": hi_eps,
                    "points": sorted(points, key=lambda p: p["epsilon"])}
    for _ in range(int(steps)):
        middle = math.sqrt(lo_eps * hi_eps)
        point, state = run_budget(middle, lo_state, generator)
        points.append(point)
        if point["r2"] > level:
            lo_eps, lo_state, lo_r2 = middle, state, point["r2"]
        else:
            hi_eps, hi_r2 = middle, point["r2"]
    estimate = _crossing([{"epsilon": lo_eps, "r2": lo_r2}, {"epsilon": hi_eps, "r2": hi_r2}],
                         level)
    return {"epsilon": estimate, "status": "ok", "bracket": [lo_eps, hi_eps],
            "points": sorted(points, key=lambda p: p["epsilon"])}


def _time_offset(encoder) -> int:
    offsets = getattr(encoder, "time_offsets", 1)
    if isinstance(offsets, (list, tuple)):
        offsets = offsets[0]
    return max(int(offsets), 1)


def evaluate_decoding(encoder,
                      decoder: Callable[[torch.Tensor], torch.Tensor],
                      x_train: npt.ArrayLike,
                      x_eval: npt.ArrayLike,
                      y_eval: npt.ArrayLike,
                      epsilons: Sequence[float] = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0),
                      metrics: Sequence[str] = METRICS,
                      steps: int = 20,
                      batch_size: int = 1024,
                      margin_windows: int = 1024,
                      margin_steps: int = 100,
                      shift_threshold: float = 0.5,
                      contrastive: bool = True,
                      residuals: str = "whole",
                      labels_train: Optional[npt.ArrayLike] = None,
                      jnd: float = 1.0,
                      seed: int = 0,
                      restarts: int = 1,
                      margins: bool = True,
                      refine: int = 0,
                      refine_floor: Optional[float] = None,
                      behaviour_train: Optional[npt.ArrayLike] = None) -> Dict[str, Any]:
    """Robust decoding R² and robustness margins of an encoder + decoder (see the module).

    Args:
        encoder: Fitted single-session ``cebra.CEBRA`` (``pad_before_transform=True``).
        decoder: Differentiable map from the embedding ``(B, D)`` to the behaviour
            ``(B, K)`` (evaluated in eval mode; its mode is restored afterwards).
        x_train: Training recording ``(n_train, C)``: the metrics are fitted on it.
        x_eval: Held-out recording ``(n, C)``.
        y_eval: Behaviour ``(n,)`` or ``(n, K)`` of ``x_eval``.
        epsilons: d′ budgets of the robust-R² curve.
        metrics: Subset of :py:data:`METRICS`.
        steps: APGD iterations per budget.
        batch_size: Windows per attack batch.
        margin_windows: Windows (evenly spaced) of the decoding margin; also the number of
            references and of negatives of the contrastive margin.
        margin_steps: DDN iterations.
        shift_threshold: Decoding decision: the prediction moved by this many behaviour SDs
            (RMS over the outputs).
        contrastive: Also compute the contrastive margin (needs ``encoder.solver_``).
        residuals: Residual mode of the metrics (``"whole"``: label-free).
        labels_train: Labels of ``x_train`` for label-based residual modes.
        jnd: ε_JND, the reference of the margin ratios and the start of the DDN search.
        seed: Seed of the noise draws and of the contrastive batch.
        restarts: APGD restarts per budget (1: the warm start only, the default). Further
            restarts start at random points of radius ε/2 (own generator, seed + 1); the
            per-window best is kept, so the curve can only get stronger (a stronger-attack
            check of the same models).
        margins: Also compute the decoding and contrastive DDN margins (False: robust R²
            curves and natural noise only).
        refine: Bisection steps of the half-R² crossing (0: off). Each step is one more
            attack over all windows and halves the bracket in log ε (4 steps: ±4 %).
        refine_floor: Smallest budget of the search below the grid (default: the smallest
            budget / 16).
        behaviour_train: Continuous behaviour of ``x_train`` ``(n_train,)`` or
            ``(n_train, K)``: also report ``eps_beh`` and ``kappa`` per metric.

    Returns:
        JSON-safe dict: ``clean_r2``, ``window_len``, ``n_windows``, ``isotropic_sigma``,
        ``sqrt_D`` and, per metric, ``robust_r2`` (list of {epsilon, r2, r2_single,
        dprime_mean, raw_l2_median} in increasing ε), ``eps_at_half_r2``,
        ``natural_noise_r2``, ``decoding_margin`` and ``contrastive_margin`` (with
        ``margins``); with ``refine``: ``eps_at_half_r2_refined`` and ``half_r2_refined``
        ({epsilon, status ``"ok"`` / ``"below_floor"`` / ``"above_grid"``, bracket or bound,
        points}); with ``behaviour_train``: ``eps_beh`` and ``kappa`` (refined ε½ if available)
        and the top-level ``behaviour_model``.
    """
    if int(restarts) < 1:
        raise ValueError(f"restarts must be >= 1, got {restarts}.")
    if int(refine) < 0:
        raise ValueError(f"refine must be >= 0, got {refine}.")
    unknown = set(metrics) - set(METRICS)
    if unknown:
        raise ValueError(f"Unknown metrics {sorted(unknown)}; choose from {METRICS}.")
    start_time = time.monotonic()
    model, left, right = _encoder_model(encoder)
    device = torch.device(encoder.device_)
    x_train = np.asarray(x_train, dtype=np.float32)
    x_eval = np.asarray(x_eval, dtype=np.float32)
    y = np.asarray(y_eval, dtype=np.float64)
    if y.ndim == 1:
        y = y[:, None]
    if len(y) != len(x_eval):
        raise ValueError(f"y_eval has {len(y)} rows, x_eval {len(x_eval)}.")
    n = len(x_eval)
    window_len = left + right
    windows = _Windows(x_eval, left, right, device)
    scale = y.std(axis=0)
    scale = np.where(scale > 0, scale, 1.0)
    target = y / scale
    target_t = torch.as_tensor(target, dtype=torch.float32, device=device)
    scale_t = torch.as_tensor(scale, dtype=torch.float32, device=device)
    models = common_metrics(x_train, window_len, labels_train, residuals, device)
    sqrt_d = math.sqrt(models["reference"].num_channels * window_len)
    generator = torch.Generator().manual_seed(int(seed))
    # Random restarts use their own stream, so the noise draws do not depend on them.
    attack_generator = torch.Generator().manual_seed(int(seed) + 1) if restarts > 1 else None
    # ... and so do the restarts of the refinement (the curves do not depend on ``refine``).
    refine_generator = torch.Generator().manual_seed(int(seed) + 2) if restarts > 1 else None
    if refine_floor is None:
        refine_floor = min(float(e) for e in epsilons) / 16
    eps_beh, behaviour_model = {}, None
    if behaviour_train is not None:
        behaviour = np.asarray(behaviour_train, dtype=np.float64)
        if len(behaviour) != len(x_train):
            raise ValueError(f"behaviour_train has {len(behaviour)} rows, x_train {len(x_train)}.")
        prediction, behaviour_model = calibration.behaviour_prediction(x_train, behaviour)
        for name in metrics:
            eps_beh[name] = calibration.eps_behaviour(x_train, prediction,
                                                      models[name].spatial_cov,
                                                      models[name].temporal_cov)
    batches = [torch.arange(first, min(n, first + batch_size), device=device)
               for first in range(0, n, batch_size)]

    def predict(x: torch.Tensor) -> torch.Tensor:
        """Standardised predictions (the R² of each output is scale-free)."""
        return decoder(_embed(model, x)) / scale_t

    def squared_error(goal: torch.Tensor):
        return lambda x: ((predict(x) - goal)**2).sum(dim=1)

    encoder_training = model.training
    decoder_training = getattr(decoder, "training", None)
    model.eval()
    if decoder_training is not None:
        decoder.eval()
    try:
        with torch.no_grad():
            clean = torch.cat([predict(windows(index)) for index in batches])
        report: Dict[str, Any] = {
            "clean_r2": _r2(target, clean.cpu().numpy()),
            "window_len": window_len,
            "n_windows": n,
            "isotropic_sigma": math.sqrt(float(models["isotropic"].spatial_cov[0, 0])),
            "sqrt_D": sqrt_d,
            "settings": {"epsilons": [float(e) for e in epsilons], "steps": int(steps),
                         "shift_threshold": float(shift_threshold),
                         "margin_windows": int(margin_windows),
                         "margin_steps": int(margin_steps), "residuals": residuals,
                         "jnd": float(jnd)},
        }
        if restarts != 1 or not margins:  # the default report is unchanged
            report["settings"].update(restarts=int(restarts), margins=bool(margins))
        if refine:
            report["settings"].update(refine=int(refine), refine_floor=float(refine_floor))
        if behaviour_model is not None:
            report["behaviour_model"] = behaviour_model
        margin_index = torch.as_tensor(
            np.unique(np.linspace(0, n - 1, min(int(margin_windows), n)).round().astype(int)),
            device=device)
        margin_batches = torch.split(margin_index, batch_size)

        for name in metrics:
            coloring = models[name].stationary_coloring(0)
            entry: Dict[str, Any] = {}

            def run_budget(eps, state, attack_rng, coloring=coloring):
                """One budget from ``state`` = (worst predictions, their errors, per-batch warm
                starts): d′-APGD warm-started at the state's solutions, and every window keeps
                its worst prediction over the state and this budget."""
                worst, worst_error, starts = state[0].clone(), state[1].clone(), list(state[2])
                single, reached, raw = [], [], []
                for b, index in enumerate(batches):
                    x0 = windows(index)
                    x_adv, info = attacks.dprime_pgd(squared_error(target_t[index]),
                                                     x0,
                                                     coloring,
                                                     eps,
                                                     steps=steps,
                                                     optimizer="apgd",
                                                     restarts=int(restarts),
                                                     generator=attack_rng,
                                                     z_init=starts[b])
                    starts[b] = info["z"]
                    with torch.no_grad():
                        prediction = predict(x_adv)
                        error = ((prediction - target_t[index])**2).sum(dim=1)
                        worse = error > worst_error[index]
                        worst_error[index] = torch.where(worse, error, worst_error[index])
                        worst[index] = torch.where(worse[:, None], prediction, worst[index])
                        single.append(prediction)
                        raw.append(torch.linalg.vector_norm((x_adv - x0).flatten(1), dim=1))
                    reached.append(info["dprime"])
                point = {
                    "epsilon": eps,
                    "r2": _r2(target, worst.cpu().numpy()),
                    "r2_single": _r2(target, torch.cat(single).cpu().numpy()),
                    "dprime_mean": float(torch.cat(reached).mean()),
                    "raw_l2_median": float(torch.cat(raw).median()),
                }
                return point, (worst, worst_error, starts)

            # Robust R² curve (per-window d′-APGD on the squared decoding error), budgets in
            # increasing order with warm starts and the per-window worst case over budgets ≤ ε.
            level = 0.5 * report["clean_r2"]
            state = (clean, ((clean - target_t)**2).sum(dim=1), [None] * len(batches))
            below, above = (0.0, state, report["clean_r2"]), None  # the bracket of the crossing
            curve = []
            for eps in sorted(float(e) for e in epsilons):
                point, state = run_budget(eps, state, attack_generator)
                curve.append(point)
                if above is None and point["r2"] > level:
                    below = (eps, state, point["r2"])
                elif above is None:
                    above = (eps, point["r2"])
            entry["robust_r2"] = curve
            entry["eps_at_half_r2"] = _crossing(curve, level)
            del state
            if refine:
                entry["half_r2_refined"] = _refine_half(run_budget, below, above, level, refine,
                                                        refine_floor, refine_generator)
                entry["eps_at_half_r2_refined"] = entry["half_r2_refined"]["epsilon"]
            del below
            if name in eps_beh:
                half = entry.get("eps_at_half_r2_refined", entry["eps_at_half_r2"])
                entry["eps_beh"] = eps_beh[name]
                entry["kappa"] = (half / eps_beh[name] if half is not None
                                  and math.isfinite(eps_beh[name]) else None)

            # One draw of the metric's own noise: the scale of natural variability.
            with torch.no_grad():
                noisy = torch.cat([
                    predict(windows(index) +
                            models[name].sample(len(index), generator=generator).to(device))
                    for index in batches
                ])
            entry["natural_noise_r2"] = _r2(target, noisy.cpu().numpy())
            if not margins:
                report[name] = entry
                continue

            # Decoding margin: minimum d′ that moves the decoded behaviour by the threshold.
            distances = []
            for index in margin_batches:
                x0 = windows(index)
                with torch.no_grad():
                    p0 = predict(x0)

                def moved(x, p0=p0):
                    with torch.no_grad():
                        return ((predict(x) - p0)**2).mean(dim=1).sqrt() >= shift_threshold

                distance, _ = attacks.min_norm_ddn(moved,
                                                   squared_error(target_t[index]),
                                                   x0,
                                                   coloring,
                                                   steps=margin_steps,
                                                   init_epsilon=jnd,
                                                   relative_step=True,
                                                   growth=_MARGIN_GROWTH)
                distances.append(distance)
            entry["decoding_margin"] = calibration.robustness_margin(torch.cat(distances), jnd)

            if contrastive and getattr(encoder, "solver_", None) is not None and n > 2:
                entry["contrastive_margin"] = _contrastive_margin(encoder, model, windows, n,
                                                                  coloring, margin_windows,
                                                                  margin_steps, jnd, seed,
                                                                  device)
            report[name] = entry
        report["seconds"] = round(time.monotonic() - start_time, 1)
        return DprimeTrainer._jsonable(report)
    finally:
        model.train(encoder_training)
        if decoder_training is not None:
            decoder.train(decoder_training)


def _contrastive_margin(encoder, model, windows: _Windows, n: int, coloring,
                        count: int, steps: int, jnd: float, seed: int,
                        device) -> Dict[str, Any]:
    """Margin of the time-contrastive decision on held-out windows (``"chance"`` rule)."""
    criterion = encoder.solver_.criterion
    offset = _time_offset(encoder)
    if n <= offset:
        return {"n": 0}
    rng = np.random.default_rng(seed)
    count = int(min(count, n - offset))
    reference = np.sort(rng.choice(n - offset, size=count, replace=False))
    negative = rng.integers(0, n, size=count)
    reference_t = torch.as_tensor(reference, device=device)
    with torch.no_grad():
        positive = _embed(model, windows(reference_t + offset))
        negatives = _embed(model, windows(torch.as_tensor(negative, device=device)))
    x0 = windows(reference_t)
    log_m = math.log(count)

    def distances(x):
        return criterion._distance(_embed(model, x), positive, negatives)

    def is_adv(x):
        with torch.no_grad():
            pos, neg = distances(x)
            return pos - (torch.logsumexp(neg, dim=1) - log_m) <= 0

    def infonce(x):
        pos, neg = distances(x)
        return -pos + torch.logsumexp(neg, dim=1)

    distance, _ = attacks.min_norm_ddn(is_adv, infonce, x0, coloring, steps=steps,
                                       init_epsilon=jnd, relative_step=True,
                                       growth=_MARGIN_GROWTH)
    margin = calibration.robustness_margin(distance, jnd)
    margin["decision"] = "chance"
    margin["time_offset"] = offset
    return margin


_DETECTOR_KEYS = ("r2", "ae_auc", "cnn_auc", "dprime_reference", "dprime_isotropic", "raw_l2")


def _at_level(points: List[Dict[str, Any]], level: float) -> Optional[Dict[str, Any]]:
    """Every quantity of a budget curve at the (log-ε interpolated) budget where ``r2 = level``.

    None if the R² never falls to ``level``; the first grid point (``status="below_grid"``) if it
    is already below there.
    """
    previous = None
    for point in points:
        if point["r2"] <= level:
            if previous is None or previous["epsilon"] <= 0 or point["epsilon"] <= 0:
                return {**{key: point[key] for key in _DETECTOR_KEYS},
                        "epsilon": point["epsilon"], "status": "below_grid"}
            weight = (previous["r2"] - level) / max(previous["r2"] - point["r2"], 1e-12)
            result = {key: previous[key] + weight * (point[key] - previous[key])
                      for key in _DETECTOR_KEYS}
            result["epsilon"] = float(
                math.exp(math.log(previous["epsilon"]) + weight *
                         (math.log(point["epsilon"]) - math.log(previous["epsilon"]))))
            result["status"] = "ok"
            return result
        previous = point
    return None


def evaluate_detectability(encoder,
                           decoder: Callable[[torch.Tensor], torch.Tensor],
                           x_train: npt.ArrayLike,
                           x_eval: npt.ArrayLike,
                           y_eval: npt.ArrayLike,
                           epsilons: Sequence[float] = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0),
                           metrics: Sequence[str] = METRICS,
                           n_windows: int = 2048,
                           steps: int = 20,
                           detector_steps: int = 300,
                           batch_size: int = 1024,
                           residuals: str = "whole",
                           labels_train: Optional[npt.ArrayLike] = None,
                           seed: int = 0) -> Dict[str, Any]:
    """How detectable is each threat geometry at equal damage to the decoder?

    A decoder trained with one geometry is more robust to attacks of that geometry (noise-aware
    training: noise-shaped attacks; L2 training: isotropic attacks), so the threat model itself
    has to be justified. The note's criterion is detectability: "ε_det: the largest ε at which a
    detector trained to separate clean from adversarial trials (plus a clean-only anomaly
    detector such as an autoencoder) stays ≤ 0.55 AUC on held-out [data]". For every common
    metric and budget, the decoder attack of :py:func:`evaluate_decoding` (APGD on the
    standardised squared decoding error, warm-started along the budgets) is applied to
    ``n_windows`` evenly spaced held-out windows; the earlier half trains the supervised
    detector, the later half is the test set of everything:

    * ``r2``: decoding R² of the attacked test windows (the damage);
    * ``ae_auc``: the clean-only convolutional autoencoder of the calibration, fitted on clean
      training windows (blind: it never sees an attack);
    * ``cnn_auc``: the convolutional detector of the calibration, trained on clean vs attacked
      windows of the earlier half (it knows the attack distribution);
    * ``dprime_reference``, ``dprime_isotropic``, ``raw_l2``: medians of the realised δ.

    ``at_half_r2`` interpolates them at the budget where the R² falls to half its clean value,
    so the geometries are compared at equal damage: the stealthier threat is the one that does
    the same damage with lower detector AUCs (and lower reference d′, the ideal observer).

    Args:
        encoder, decoder, x_train, x_eval, y_eval, epsilons, metrics, steps, batch_size,
            residuals, labels_train, seed: As in :py:func:`evaluate_decoding`.
        n_windows: Held-out windows (half for the supervised detector, half for testing).
        detector_steps: Training steps of each detector (Adam 1e-3, minibatch 256).

    Returns:
        JSON-safe dict: ``clean_r2`` (test half), ``n_fit``, ``n_test`` and, per metric,
        ``curve`` (list of {epsilon, r2, ae_auc, cnn_auc, dprime_reference, dprime_isotropic,
        raw_l2}) and ``at_half_r2`` (the same keys plus ``epsilon`` and ``status``, or None).
    """
    unknown = set(metrics) - set(METRICS)
    if unknown:
        raise ValueError(f"Unknown metrics {sorted(unknown)}; choose from {METRICS}.")
    start_time = time.monotonic()
    model, left, right = _encoder_model(encoder)
    device = torch.device(encoder.device_)
    x_train = np.asarray(x_train, dtype=np.float32)
    x_eval = np.asarray(x_eval, dtype=np.float32)
    y = np.asarray(y_eval, dtype=np.float64)
    if y.ndim == 1:
        y = y[:, None]
    if len(y) != len(x_eval):
        raise ValueError(f"y_eval has {len(y)} rows, x_eval {len(x_eval)}.")
    n = len(x_eval)
    window_len = left + right
    eval_windows = _Windows(x_eval, left, right, device)
    train_windows = _Windows(x_train, left, right, device)
    scale = y.std(axis=0)
    scale = np.where(scale > 0, scale, 1.0)
    target = y / scale
    target_t = torch.as_tensor(target, dtype=torch.float32, device=device)
    scale_t = torch.as_tensor(scale, dtype=torch.float32, device=device)
    models = common_metrics(x_train, window_len, labels_train, residuals, device)

    def evenly(length: int, count: int) -> torch.Tensor:
        index = np.unique(np.linspace(0, length - 1, min(int(count), length)).round().astype(int))
        return torch.as_tensor(index, device=device)

    index = evenly(n, n_windows)
    half = len(index) // 2
    if half < 2:
        raise ValueError("Too few held-out windows for the detectors.")
    parts = {"fit": index[:half], "test": index[half:]}
    test_numpy = parts["test"].cpu().numpy()

    def predict(x: torch.Tensor) -> torch.Tensor:
        return decoder(_embed(model, x)) / scale_t

    def squared_error(goal: torch.Tensor):
        return lambda x: ((predict(x) - goal)**2).sum(dim=1)

    def gather(windows: _Windows, idx: torch.Tensor) -> torch.Tensor:
        return torch.cat([windows(chunk) for chunk in torch.split(idx, batch_size)])

    def predictions(x: torch.Tensor) -> np.ndarray:
        with torch.no_grad():
            return torch.cat([predict(chunk) for chunk in torch.split(x, batch_size)]).cpu().numpy()

    encoder_training = model.training
    decoder_training = getattr(decoder, "training", None)
    model.eval()
    if decoder_training is not None:
        decoder.eval()
    try:
        with torch.no_grad():
            clean_train = gather(train_windows, evenly(len(x_train), 4 * n_windows))
            clean = {name: gather(eval_windows, idx) for name, idx in parts.items()}
        clean_r2 = _r2(target[test_numpy], predictions(clean["test"]))
        standardize = calibration._channel_standardizer(clean_train)
        autoencoder = calibration._fit_autoencoder(standardize(clean_train), detector_steps,
                                                   256, 1e-3, seed)
        ae_clean = calibration._score(autoencoder.reconstruction_error,
                                      standardize(clean["test"]))
        z_fit_clean = standardize(clean["fit"])
        z_test_clean = standardize(clean["test"])
        report: Dict[str, Any] = {
            "clean_r2": clean_r2,
            "n_fit": int(half),
            "n_test": int(len(index) - half),
            "isotropic_sigma": math.sqrt(float(models["isotropic"].spatial_cov[0, 0])),
            "settings": {"epsilons": [float(e) for e in epsilons], "steps": int(steps),
                         "detector_steps": int(detector_steps), "n_windows": int(n_windows),
                         "residuals": residuals},
        }
        for name in metrics:
            coloring = models[name].stationary_coloring(0)
            starts = {part: [None] * len(torch.split(idx, batch_size))
                      for part, idx in parts.items()}
            curve = []
            for eps in sorted(float(e) for e in epsilons):
                attacked = {}
                for part, idx in parts.items():
                    chunks = []
                    for b, chunk in enumerate(torch.split(idx, batch_size)):
                        x_adv, info = attacks.dprime_pgd(squared_error(target_t[chunk]),
                                                         eval_windows(chunk),
                                                         coloring,
                                                         eps,
                                                         steps=steps,
                                                         optimizer="apgd",
                                                         restarts=1,
                                                         z_init=starts[part][b])
                        starts[part][b] = info["z"]
                        chunks.append(x_adv)
                    attacked[part] = torch.cat(chunks)
                with torch.no_grad():
                    delta = attacked["test"] - clean["test"]
                    sizes = {
                        "dprime_reference": float(models["reference"].dprime(delta).median()),
                        "dprime_isotropic": float(models["isotropic"].dprime(delta).median()),
                        "raw_l2": float(torch.linalg.vector_norm(delta.flatten(1), dim=1).median()),
                    }
                z_test_adv = standardize(attacked["test"])
                ae_auc = calibration.auc(ae_clean,
                                         calibration._score(autoencoder.reconstruction_error,
                                                            z_test_adv))
                detector = calibration._fit_detector(z_fit_clean, standardize(attacked["fit"]),
                                                     detector_steps, 256, 1e-3, seed)
                cnn_auc = calibration.auc(calibration._score(detector, z_test_clean),
                                          calibration._score(detector, z_test_adv))
                curve.append({
                    "epsilon": eps,
                    "r2": _r2(target[test_numpy], predictions(attacked["test"])),
                    "ae_auc": float(ae_auc),
                    "cnn_auc": float(cnn_auc),
                    **sizes,
                })
                del detector, attacked
            report[name] = {"curve": curve, "at_half_r2": _at_level(curve, 0.5 * clean_r2)}
        report["seconds"] = round(time.monotonic() - start_time, 1)
        return DprimeTrainer._jsonable(report)
    finally:
        model.train(encoder_training)
        if decoder_training is not None:
            decoder.train(decoder_training)
