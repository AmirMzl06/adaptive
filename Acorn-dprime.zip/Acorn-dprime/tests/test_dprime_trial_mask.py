"""Tests of cebra.dprime.trial_mask (Layer 2: trial-level nonstationary masking)."""

import numpy as np
import pytest
import torch

from cebra.dprime import trial_mask


def test_dpss_unit_energy():
    tapers = trial_mask.dpss_tapers(16, 2.0, 3)
    assert tapers.shape == (3, 16)
    np.testing.assert_allclose(tapers.norm(dim=1).numpy(), 1.0, rtol=1e-6)


def test_multitaper_peak_frequency():
    t = torch.arange(64, dtype=torch.float32)
    x = torch.sin(2 * np.pi * 4 / 16 * t).view(1, 1, -1)  # bin 4 of a 16-point FFT
    power = trial_mask.multitaper_spectrogram(x, n_fft=16, hop=4)
    assert power.shape[:3] == (1, 1, 9)
    assert int(power[0, 0, :, 2:-2].mean(dim=-1).argmax()) == 4


@pytest.mark.parametrize("window_len", [36, 35])
def test_tight_frame_and_shapes(window_len):
    torch.manual_seed(0)
    x0 = torch.randn(3, 4, window_len)
    coloring = trial_mask.TrialMaskColoring(x0, torch.eye(4), unit_gain=True)
    np.testing.assert_allclose(coloring.synthesis(coloring.analysis(x0)).numpy(), x0.numpy(),
                               atol=1e-4)
    ratio = coloring.analysis(x0).norm() / x0.norm()
    assert 0.9 < float(ratio) < 1.15
    z = coloring.random_z(x0, 3.0)
    assert coloring.color(z).shape == (3, 4, window_len)
    # Least-squares synthesis never increases the norm (up to window-edge effects).
    assert torch.all(coloring.color(z).flatten(1).norm(dim=1) <= 1.15 * 3.0)


def test_color_linear_differentiable_and_spatial():
    torch.manual_seed(1)
    x0 = torch.randn(2, 3, 36)
    root = torch.tensor([[2.0, 0.5, 0.0], [0.5, 1.0, 0.0], [0.0, 0.0, 3.0]])
    coloring = trial_mask.TrialMaskColoring(x0, root)
    z1, z2 = coloring.random_z(x0, 1.0), coloring.random_z(x0, 2.0)
    np.testing.assert_allclose(coloring.color(z1 - 3 * z2).detach().numpy(),
                               (coloring.color(z1) - 3 * coloring.color(z2)).detach().numpy(),
                               atol=1e-4)
    z = z1.clone().requires_grad_(True)
    coloring.color(z).pow(2).sum().backward()
    assert torch.isfinite(z.grad).all() and z.grad.abs().sum() > 0
    unit = trial_mask.TrialMaskColoring(x0, torch.eye(3))
    np.testing.assert_allclose(coloring.color(z1).detach().numpy(),
                               torch.einsum("ij,bjt->bit", root, unit.color(z1)).detach().numpy(),
                               atol=1e-4)


def test_gain_normalisation_and_floor():
    x0 = torch.randn(4, 2, 36)
    x0[1, 0, :18] = 0.0  # a bursty trial: silent first half
    x0[2, 1] = 0.0  # a silent channel
    coloring = trial_mask.TrialMaskColoring(x0, torch.eye(2), floor=1e-2)
    power = coloring.gain**2
    np.testing.assert_allclose(power.mean(dim=(2, 3)).numpy(), 1.0, rtol=1e-5)
    assert float(power.min()) >= 0.99e-2 / (1 + 1e-2)
    assert torch.allclose(coloring.gain[2, 1], torch.ones_like(coloring.gain[2, 1]))
    # The burst: the masked perturbation lives where the trial has power.
    z = coloring.random_z(x0, 5.0, generator=torch.Generator().manual_seed(0))
    delta = coloring.color(z)[1, 0]
    assert delta[:14].pow(2).sum() < delta[22:].pow(2).sum()
