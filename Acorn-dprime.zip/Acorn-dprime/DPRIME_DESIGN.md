# Acorn-dprime: epsilon as a detectability index (d′) for ACORN / CEBRA

This fork implements Part 1 of the research note "Adversarial Attacks and Learnable
Augmentation for Neural Data" ("ε as a detectability index (d′)") on top of the ACORN
CEBRA fork (`CEBRA-main`). The original PGD (`adv_epsilon_mode="constant"`) is untouched
(bit-identical training step); everything new lives behind `adv_epsilon_mode="dprime"` and in
the package `cebra/dprime/`. One change applies to every mode: CEBRA's batch sampler is seeded
from `torch.manual_seed` instead of non-deterministically, so fits are reproducible (Section 6,
"Reproducibility of CEBRA's batches").

This document is the binding specification for the implementation (module APIs, tensor
conventions, math) and later the user documentation (Section 10 lists every new `cebra.CEBRA`
argument).

---------------------------------------------------------------------------------------------

## 0. Conventions (all modules)

* A **window** batch is a torch tensor `x` of shape `(B, C, T)`: B samples, C channels
  (neurons / electrodes), T time bins (the receptive field of the CEBRA model, e.g. 36 for
  `offset36-*`). This is exactly `batch.reference` in CEBRA.
* A **recording** is a `(n_time, C)` array (numpy or torch), e.g. `loader.dataset.neural`.
* Labels: `(n_time,)` int (discrete) or `(n_time, d)` float (continuous), or None.
* `D = C * T` is the dimension of one window.
* All public functions accept torch tensors on any device and return tensors on the same
  device; estimation code may use numpy/float64 internally. No in-place modification of inputs.
* "d′" of a perturbation `δ` is `‖Σ^{-1/2} δ‖₂` (Mahalanobis norm in the noise metric).
  Attacks are parameterised in the **whitened** variable `z`, with `δ = Color(z)` and
  `d′ = ‖z‖₂`, so the d′ ball is an ordinary L2 ball in z (Section 2 of the note).
* Randomness only through an explicit `torch.Generator` / numpy seed argument.
* Python ≥ 3.8, torch ≥ 1.12 (tested on 2.0.1), numpy, scipy ≥ 1.1, scikit-learn.
  Only these dependencies. No new package dependencies (no pyriemann, no fooof, no mne).

## 1. The core idea → `cebra/dprime/noise.py` (Layer 1: dataset-level stationary metric)

Ball: `δᵀ Σ⁻¹ δ ≤ ε²`, Σ = noise covariance of the dataset, Kronecker structured
`Σ = Σ_spatial ⊗ Σ_temporal`.

* **Residuals** (what "noise" means), `compute_residuals(neural, labels=None, mode="auto", label_kind=None)`
  returns `(n_time, C)` float64 numpy:
  * `"whole"`: neural minus its mean ("whole trials for oscillatory tasks where background dominates");
  * `"class_mean"`: neural minus the mean of its class (discrete labels) ("trial minus class mean for ERP data");
  * `"regression"`: neural minus a ridge regression of neural on the continuous labels (with
    intercept; ridge = 1e-6 x trace of the label Gram matrix) — the continuous-label analogue of
    "minus class mean";
  * `"difference"`: the scaled first difference `(x_t − x_{t−1}) / √2` (label-free; `n_time − 1`
    rows). It cancels a signal that changes little between neighbouring bins (e.g. firing rates
    driven by movement) and keeps the covariance of temporally white noise, so its covariance is
    the spatial covariance of the fast fluctuations rather than of the whole activity. It is
    high-pass by construction, so it is meant for the spatial factor: use `temporal="white"`
    (a Welch / AR factor on it warns);
  * `"auto"`: class_mean for discrete labels, regression for continuous labels, whole otherwise.
* **Spatial covariance** `spatial_covariance(residuals, estimator)` → `(C, C)` float64, SPD:
  `"isotropic"` (mean residual variance × I: the control without a noise-aware geometry; with
  `temporal="white"` the d′ ball is the plain L2 ball of radius ε·σ̄),
  `"ledoit_wolf"` (sklearn LedoitWolf), `"oas"` (sklearn OAS), `"empirical"`, `"tyler"`
  (regularised Tyler M-estimator, Chen–Wiesel–Hero fixed point with shrinkage ρ = 0.1 toward
  identity, trace-normalised shape rescaled to the trace of the empirical covariance; "EEG is
  heavy-tailed, so use robust covariance (Tyler's estimator)"). Eigenvalues floored at
  `1e-6 * mean eigenvalue`.
* **Temporal covariance** `temporal_covariance(residuals, window_len, method="welch",
  ar_order=4, tau=None, welch_nperseg=None)` → `(T, T)` float64 SPD matrix with unit mean
  diagonal (the scale lives in Σ_spatial). The PSD is estimated on per-channel standardised
  residuals, averaged over channels (the Kronecker model has one temporal factor), and turned
  into the **Toeplitz** covariance of the T-bin window (autocovariance = inverse FFT of the PSD
  on a fine grid). `Σ_temporal^{-1/2}` is then the exact prewhitening filter of the window
  ("temporal whitening is just a prewhitening filter 1/√S(f)") without the wrap-around of a
  circulant/FFT approximation (which biased d′ at the window edges; the model's Kronecker error
  now equals the sampling floor):
  * `"welch"`: `scipy.signal.welch(window="hann", noverlap=50%, detrend="constant", nperseg =
    welch_nperseg or max(8T, 256))` ("a PSD from Welch"; scipy's one-sided doubling undone);
  * `"ar"`: Yule–Walker AR(p) ("or an AR(p) fit"), autocovariance of the fitted process;
  * `"white"`: identity;
  * `"vanrossum"`: spike-train extension (Section 7): metric `‖K_τ ∗ δ‖` with the causal kernel
    `K_τ(t) = exp(−t/τ)`, i.e. `Σ_temporal = (KᵀK)⁻¹`. `tau="auto"` uses `fit_vanrossum_tau`.
  `temporal_spectrum`, `covariance_spectrum`, `circulant_covariance` and `full_spectrum` remain
  as spectral helpers (and for `NoiseModel.from_spectrum`).
* `fit_vanrossum_tau(residuals)` → e-folding time (bins, ≥ 0.5) of the channel-averaged
  residual autocorrelation ("τ fitted to the dataset's inter-trial variability").
* `kronecker_check(residuals, window_len, n_channels=8, max_windows=5000)` → dict with the
  relative Frobenius error `‖Σ_full − Σ_kron‖/‖Σ_full‖` of (a) the nearest Kronecker product
  (Van Loan–Pitsianis rank-1 rearrangement) and (b) the model's own `Σ_s ⊗ Σ_t` restricted to the
  slice, on the `n_channels` highest-variance channels ("the Kronecker assumption should be
  checked against a full covariance on a small C·T slice"). The empirical full covariance is
  itself noisy (overlapping windows, (c·T)² entries), so the check also reports its sampling
  floor `‖S_a − S_b‖ / (2‖S‖)` (two interleaved halves of the recording) and
  `model_excess_rel_error = √(model² − floor²)`: a correct Kronecker model has
  `model_rel_error ≈ floor`, whatever the size of the floor.
* `class NoiseModel`:
  ```
  NoiseModel(spatial_cov (C,C), temporal_cov (T,T), cov_pool=None,
             leadfield=None, leadfield_noise=0.0, device=None)
  NoiseModel.from_spectrum(spatial_cov, spectrum_half, window_len, ...)   (circulant Σ_temporal)
  .to(device) -> self
  .temporal(x, inverse=False)  Σ_t^{1/2} (or Σ_t^{-1/2}) along the time axis
  .spatial_sqrt / .spatial_sqrt_of(pool_index)
  .color(z, pool_index=None)   (B,C,T) -> (B,C,T): Σ_s^{1/2} then Σ_t^{1/2}   (linear in z)
  .whiten(delta, pool_index=None) (B,C,T) -> (B,C,T): exact inverse of color
  .dprime(delta, pool_index=None) -> (B,) = ‖whiten(delta)‖₂ over (C,T)
  .sample(B, generator=None, pool_index=None) -> (B,C,T) colored Gaussian noise (d′² ~ χ²_D)
  .stationary_coloring(pool_index=None) -> Coloring          (Layer 1)
  .leadfield_coloring(x0, generator=None) -> Coloring          (Section 7, needs leadfield)
  .pool_size -> int  (1 + len(cov_pool))
  .noise_std() / .summary()   (summary: noise_std_median, temporal_lag1_correlation, ...)
  ```
  Matrix square roots via `eigh` (symmetric sqrt / inverse sqrt). `cov_pool` is an optional
  list of extra `(C,C)` spatial covariances (same C) — "sample Σ from the pool of per-subject
  covariances during training"; `pool_index=0` is the dataset's own Σ, `1..` the pool.
* `fit_noise_model(neural, labels=None, label_kind=None, window_len=..., residual_mode="auto",
  spatial_estimator="ledoit_wolf", temporal_method="welch", ar_order=4, vanrossum_tau="auto",
  cov_pool=None, leadfield=None, leadfield_noise=0.0, kronecker_channels=8, device=None)`
  → `(NoiseModel, info: dict)`; info holds residual mode used, estimator, τ, spectrum,
  Kronecker check, noise std (JSON-serialisable floats/lists only).

### The Coloring interface (implemented by noise.py and trial_mask.py)

```
coloring.init_z(x0)            -> zeros in the attack variable space, batch size B, on x0.device
coloring.color(z)              -> δ of shape (B, C, T); linear and differentiable in z
coloring.dprime(z)             -> (B,) d′ of the perturbation = ‖z‖₂ per sample (flattened)
coloring.random_z(x0, radius, generator=None) -> random z with ‖z_i‖ = radius_i (uniform direction)
```
`radius`/`epsilon` arguments are floats or `(B,)` tensors everywhere.

## 2. Layer 2: trial-level nonstationary masking → `cebra/dprime/trial_mask.py`

"Replace [Σ_temporal] per trial with a local time–frequency gain: compute the trial's multitaper
spectrogram P_c(t,f), parametrize δ = ISTFT(m ⊙ z) with m_c(t,f) = √P_c(t,f), and run PGD on z
with ‖z‖₂ ≤ ε."

* `dpss_tapers(n_fft, nw=2.0, k=3)` → `(k, n_fft)` torch float32 (scipy.signal.windows.dpss, unit energy).
* `multitaper_spectrogram(x, n_fft=16, hop=4, tapers=...)` → `(B, C, F, frames)`, F = n_fft//2+1,
  the average over tapers of `|STFT_taper(x)|²` (`torch.stft(center=True, pad_mode="reflect",
  return_complex=True)` with each taper as window).
* `class TrialMaskColoring(x0, spatial_sqrt, n_fft=16, hop=4, nw=2.0, k=3, floor=1e-3)`:
  the gain is `m = sqrt(P / mean_{f,t} P)` per (sample, channel) (unit mean power, relative
  floor `floor`), computed once from the clean window x0 (no gradient). The variable z is real
  `(B, C, F, frames, 2)`; `color(z) = Σ_s^{1/2} · ISTFT(m ⊙ complex(z))` with
  `torch.istft(window=hann(n_fft), center=True, length=T)`; the spatial factor `Σ_s^{1/2}` keeps
  the Kronecker structure "Σ_spatial ⊗ local time-frequency gain", so the ε scale stays comparable
  with Layer 1 ("conceptually this is still Layer 1 — d′ against a time-varying noise model").
  The STFT is normalised as a **tight frame** (orthonormal DFT, one-sided bins weighted by √2,
  divided by the root window overlap), so `‖analysis(x)‖ ≈ ‖x‖` and synthesis∘analysis = identity.
  `dprime(z) = ‖z‖₂` (exact for a consistent STFT; ISTFT of an arbitrary z is its least-squares
  projection, so the realised d′ can only be smaller). `n_fft` is shrunk for short windows; the
  trainer falls back to Layer 1 (warning) when the receptive field has fewer than 4 bins
  (e.g. `offset1-model`).

## 3. Layer 3: physiological guards → `cebra/dprime/guards.py`

"Tolerances come from natural within-class, within-subject variability rather than hand-picked
thresholds." Features (torch, differentiable where noted):

* `periodogram(x, fs=1.0, tapers=None)` → power `(B,C,F)` (mean removed; Hann-windowed rfft, or
  the multitaper average over `tapers`, F = T//2+1) and freqs (F,). The guards use DPSS
  multitaper estimates (`adv_dprime_multitaper_nw/k`): single-window log powers of short windows
  have 2 degrees of freedom per bin and are often near zero, where a tiny δ moves the log power
  by more than its natural SD.
* `log_band_power(x, bands, fs, tapers=None)` → `(B,C,n_bands)`, log of the mean power in each band
  (+1e-12). The DC bin is never used (the windows are mean-removed). Default bands, in
  cycles/bin × fs: `((0, .05), (.05, .15), (.15, .30), (.30, .50))`; an empty band takes the
  nearest non-zero bin.
* `aperiodic_params(x, fs, f_range=None, tapers=None)` → `(offset (B,C), exponent (B,C))`, least-squares fit of
  `log10 P(f) = offset − exponent·log10 f` over the non-zero frequencies in f_range
  (specparam/FOOOF "fixed" aperiodic mode, no knee) ("aperiodic exponent and offset").
* `window_covariance(x, channels, shrink=0.1)` → `(B,c,c)` centred covariance of the selected
  channels + `shrink·trace/c·I`.
* `riemann_distance(A, B)` → `(B,)`, affine-invariant `sqrt(Σ log² λ_i(A^{-1/2} B A^{-1/2}))`
  via Cholesky of A and `eigvalsh` (differentiable).
* `erp_features(x, window)` → `(amplitude (B,C), latency (B,C))`: amplitude = value at the peak
  of |x| inside `window=(start, stop)` bins, latency = its position (bins).
* `peak_to_peak(x)` → `(B,C)`.
* `class GuardSet(guards=("band_power","aperiodic","riemann","artifact"), tau=1.0, bands=None,
  sampling_rate=1.0, erp_window=None, riemann_channels=32, riemann_shrink=0.1,
  artifact_rate=0.01, nn_max_per_class=256, seed=0, multitaper_nw=2.0, multitaper_k=3)`:
  * `.fit(windows (M,C,T), classes=None, times=None, exclusion=0) -> self` computes tolerances:
    - band_power / aperiodic / erp: `tau × within-class SD` per channel (SD within each class,
      averaged over classes weighted by count; SD floor 1e-6);
    - riemann: `median same-class nearest-neighbour d_R` over the training windows (NN search in
      the log-Euclidean embedding, exact d_R for the NN pair; neighbours with
      `|t − t'| < exclusion` excluded; ≤ nn_max_per_class windows per class); channels = the
      `riemann_channels` highest-variance channels (all if C ≤ riemann_channels);
    - artifact: per-channel peak-to-peak thresholds at a common quantile q chosen (bisection) so
      that a fraction `artifact_rate` of the clean windows is rejected (Autoreject-style
      thresholds), each moved half-way to the next larger observed value (same clean rejection
      rate; with discrete data such as spike counts the many clean windows sitting exactly at
      the threshold are no longer rejected by an arbitrarily small δ); "ICLabel" has no analogue
      for non-EEG data and is not implemented;
    - windows shorter than 4 bins disable the spectral guards, shorter than 2 all guards
      (warning; listed under `disabled` in the report).
  * `.check(x0, x_adv) -> (ok (B,) bool, details {guard: (B,) bool})`: all channels/bands within
    tolerance; riemann `d_R(C_x0, C_xadv) ≤ tol`; artifact: x_adv is not rejected unless x0 is
    rejected too ("at the same rate as clean trials").
  * `.soft_penalty(x0, x_adv) -> (B,)` = `relu(d_R − tol)²` (differentiable; zeros if riemann is
    off) ("d_R is differentiable, so it can also be a soft penalty").
  * `.report() -> dict` (JSON-serialisable summary of the tolerances).

## 4. Attacks → `cebra/dprime/attacks.py`

* `dprime_pgd(loss_fn, x0, coloring, epsilon, steps=10, optimizer="apgd", restarts=1,
  guards=None, guard_mode="backtrack", max_backtrack=3, soft_penalty_weight=0.0, generator=None,
  z_init=None)`
  → `(x_adv (B,C,T) detached, info)`.
  * `loss_fn(x) -> (B,)` per-sample loss to MAXIMISE (differentiable in x).
  * Optimises z in the L2 ball `‖z_i‖ ≤ ε_i` (ε float or (B,) tensor; ε_i = 0 → no perturbation).
    Objective: `loss_fn(x0 + color(z)) − soft_penalty_weight · guards.soft_penalty(x0, x)`.
  * `optimizer="apgd"`: APGD (Croce & Hein 2020) for L2 in z: η₀ = 2ε, momentum α = 0.75,
    checkpoints p₀=0, p₁=0.22, p_{j+1}=p_j+max(p_j−p_{j−1}−0.03, 0.06), ρ = 0.75; at a
    checkpoint halve η and restart from the best point when (i) fewer than ρ·(w_j−w_{j−1})
    steps increased the loss or (ii) η and the best loss were both unchanged since the last
    checkpoint; per-sample best iterate returned ("APGD-style step adaptation").
    `optimizer="pgd"`: `z ← Proj(z + α g/‖g‖)`, α = 2.5 ε / steps.
  * Restart 0 starts at z = 0 (the note's sketch) or at `z_init` projected onto the ball (warm
    start, e.g. from the solution of a smaller budget); restarts ≥ 1 start at a random point of
    radius ε/2; the per-sample best restart is kept ("and restarts").
  * Guards, `guard_mode="backtrack"`: after each step, samples whose candidate violates a guard
    get their step halved and retried up to `max_backtrack` times; if still violating, they keep
    their previous z ("if a guard is violated after a step, halve the step and retry (≤ K_bt)").
    `"backtrack"` and `"final"` both apply the final accept/reject: a rejected sample returns
    x0 (clean) ("return x + Color(z) if all guards pass else reject"). `"off"`: no guards.
  * `info`: `dprime (B,)` realised ‖z‖, `accepted (B,)` bool, `loss (B,)` final loss,
    `loss_start (B,)` loss at the start of restart 0, `z` the returned whitened variable,
    `backtracks` int, `guard_failures` {guard: int} (final check), `epsilon (B,)`.
* `min_norm_ddn(is_adv_fn, loss_fn, x0, coloring, steps=50, init_epsilon=1.0, gamma=0.05,
  alpha=None, max_epsilon=None, relative_step=False, growth=None)` → `(dprime_min (B,),
  success (B,) bool)`: Decoupled Direction and Norm (Rony et al. 2019) in the whitened metric
  ("a minimum-norm attack (FMN/DDN in the whitened metric) to measure each trial's distance to
  the decision boundary in d′"). `is_adv_fn(x) -> (B,) bool`. Samples adversarial at x0 have
  distance 0. Never-adversarial samples: `inf` and success False. DDN was designed for images
  (distances O(1)); d′ margins range from about 1 to above 10, so `relative_step=True` uses the
  step `α_k · ε_k` (the direction turns by about α_k radians whatever the norm) and `growth`
  multiplies ε by `1 + growth` per step until the sample has been adversarial once. The margins
  of the training report and of the evaluation use both (`growth = 0.3`); with the absolute step
  a far boundary was often reported as never broken.
* `linf_pgd(loss_fn, x0, epsilon_abs, steps=10, alpha=None, generator=None)` → x_adv: plain
  L∞ PGD in input units (used to train detectors "across attacks").

## 5. Calibration → `cebra/dprime/calibration.py`

"Choosing ε per dataset: a calibration protocol, not a number":
1. **ε_JND = 1** (ideal-observer threshold; configurable).
2. **ε_NN**: "for each clean trial, the whitened distance to its nearest same-class, same-subject
   neighbour; take a low quantile (e.g., the 10th)".
3. **ε_det**: "the largest ε at which a detector trained to separate clean from adversarial
   trials (plus a clean-only anomaly detector such as an autoencoder) stays ≤ 0.55 AUC on
   held-out [data]".
`ε* = min(ε_JND, ε_NN, ε_det)`; robustness margin = `median(d′_boundary) / ε*`.

* `make_classes(labels, label_kind, n_classes=8, seed=0)` → `(n_time,)` int64 numpy or None
  (discrete labels as is; continuous labels → k-means on standardised labels; None → None).
* `valid_indices(n_time, offset_left, offset_right)` → indices t with a full window
  `[t − left, t + right)`.
* `whitened_windows(neural, indices, offset_left, offset_right, noise_model, batch_size)` →
  generator/tensor of flattened whitened windows `(M, D)`.
* `nearest_neighbour_dprime(neural, noise_model, offset_left, offset_right, classes=None,
  query_indices=None, bank_size=2000, exclusion=None, batch_size=512, seed=0, device=None)` →
  `(query_indices (Q,), distances (Q,))`: whitened (d′) distance of each query window to its
  nearest same-class window in a random bank, excluding temporal neighbours `|t − t'| <
  exclusion` (default: the window length, so overlapping windows never count). Distances via
  `torch.cdist` in chunks.
* `eps_nn(distances, quantile=0.10)` → float.
* `per_index_eps_nn(n_time, query_indices, distances)` → `(n_time,)` float32 array with the
  per-trial ε_NN,i (inf for invalid indices) (used for instance-adaptive budgets).
* Detectors: `ConvDetector(C)` (Conv1d(C,32,5)–ReLU–Conv1d(32,32,5)–ReLU–global mean–Linear(32,1))
  and `ConvAutoencoder(C)` (Conv1d(C,32,5,pad 2)–ReLU–Conv1d(32,8,5,pad 2)–ReLU–Conv1d(8,32,5,pad 2)
  –ReLU–Conv1d(32,C,5,pad 2)), trained with Adam(1e-3), minibatch 256, `detector_steps` steps.
* `auc(scores_neg, scores_pos)` → Mann–Whitney AUC (ties = 0.5).
* `detection_curve(x_train, x_test, attack_fn, eps_grid, detector_steps=300, device=None,
  seed=0)` → `{eps: {"cnn_auc", "ae_auc", "auc"(=max)}}`. `attack_fn(x, eps, kind) -> x_adv` for
  `kind in ("dprime", "colored_noise", "linf")`; the CNN detector is trained on clean vs the
  mixture of all three kinds on x_train ("detectors overfit to one attack, so train them across
  attacks") and evaluated on clean vs `"dprime"` on the held-out x_test; the autoencoder is trained
  on clean x_train only and scored by reconstruction error on x_test. In training, the
  `"dprime"` attack of the calibration runs **without guards**: ε_det calibrates the d′ ball
  itself, and a guard-capped attack would make the curve flat above the cap. The realised mean
  d′ of every grid point is stored in the curve (`mean_dprime`).
* `eps_det_from_curve(curve, threshold=0.55)` → `(eps_det, status)`: the largest grid ε with
  AUC ≤ threshold (status "ok"); if none → half the smallest grid value (status "below_grid");
  if all pass → the largest grid value (status "censored_above").
* `eps_det_crossing(curve, threshold=0.55, key="auc")` → `(eps, status)`: the same walk, but the
  AUC is interpolated linearly in log ε between the last passing and the first failing grid
  point (no snapping to the factor-2 grid); `key="ae_auc"` uses the clean-only anomaly
  detector alone.
* `eps_energy_detector(C, T)` → `(2D)^{1/4}` (D = C·T): the d′ at which the optimal *blind*
  detector reaches d′ = 1. The ideal observer of ε_JND knows δ (d′ = ‖δ‖_Σ); an observer who
  does not can at best test the whitened energy, whose mean shifts by ‖δ‖²_Σ against an SD of
  ≈ √(2D), i.e. detectability ‖δ‖²_Σ / √(2D). A reference value for the anomaly detector
  (C = 86, T = 36: 8.87).
* `robustness_margin(dprime_min, eps_star)` → dict(median, quantiles 10/25/75/90, fraction
  already adversarial (d′=0), fraction never broken, ratio = median / eps_star).
* `signal_lag_traces(neural, spatial_cov, max_lag)` → `g_k = tr(Σ_s⁻¹ Γ_k)`, `k = 0…max_lag`,
  `Γ_k = Cov(x_{t+k}, x_t)` (lagged inner products of the whitened recording).
* `eps_signal(neural, spatial_cov, temporal_cov, lag=1)` → ε_sig, the typical d′ distance
  between the *signal* parts of two windows in the metric `Σ_s ⊗ Σ_t`:
  `ε_sig² = 2 Σ_{i,j} (Σ_t⁻¹)_{ij} g^sig_{|i−j|}`, with `g^sig_k = g_k` for `k ≥ lag` (noise taken
  as temporally white) and `g_lag` for the shorter lags (a slow signal is flat there). With
  `lag = 1` this is the difference-residual decomposition `Cov(x) − Cov(Δx/√2) = sym Γ_1`, and for a
  white temporal factor `ε_sig² = 2T · tr(Σ_s⁻¹ sym Γ_1)`. In the noise metric it is the note's
  natural-repeat distance without its noise floor, `E[d′²(x_a − x_b)] − 2D` over window pairs
  (checked on Perich: within 2 %).
* `signal_projector(neural, metric_cov, noise_cov, window_len, remove="jnd")` → `(P, info)`: the
  projector of the whitened attack variable onto the nuisance directions. Signal modes
  `S w = ψ N w` (S = sym Γ_1, N = noise covariance, `wᵀ N w = 1`); `"jnd"` removes the modes
  detectable within a window and above the sampling noise of the estimate,
  `ψ > max(1/T, 1.2·√(2C/n))` (for white noise the largest eigenvalue of the noise-whitened
  sym Γ_1 is ≈ √(2C/n), and T·√(2C/n) = 2–8 on Perich, so 1/T alone would remove noise modes);
  an int removes the leading ones. The perturbation keeps the
  signal readouts fixed (`wᵀ δ = 0`, i.e. `z ⟂ M^{1/2} w` for `δ = M^{1/2} z`), so
  `P = I − Q Qᵀ` with Q an orthonormal basis of `M^{1/2} W`; at least one direction is kept.
* `behaviour_prediction(neural, labels, lags=(−8, −4, 0, 4, 8), features=400, folds=5, seed=0)`
  → `(x̂, info)`: the behavioural signal, i.e. the activity predicted from the behaviour at
  `t + lag` (standardised) and random Fourier features of it, by ridge regression cross-fitted
  over contiguous blocks (penalty chosen from `BEHAVIOUR_ALPHAS` by the held-out R²).
* `eps_behaviour(neural, x̂, spatial_cov, temporal_cov)` → ε_beh, the analogue of ε_sig for the
  behavioural part of the activity: `ε_beh² = 2 Σ_{i,j} (Σ_t⁻¹)_{ij} g_{|i−j|}`,
  `g_k = tr(Σ_s⁻¹ sym Cov(x̂_{t+k}, x_t))` (the held-out prediction is independent of the noise,
  so the cross-covariance is noise-free; an imperfect prediction makes ε_beh smaller).

### Threat budget and training budget (`auto_sig`)

ε* = min(ε_JND, ε_NN, ε_det) is the *threat* budget: on Perich spike counts it is always one JND
(ε_NN ≈ 0.75–0.89·√(2D) never binds, ε_det(CNN) = 1–4), and it is the budget of the evaluation and
of the JND margin. Training at ε* is too weak (Exp3: clean R² rises with the budget up to d′ ≈ 8).
The *training* budget must stay below the size of natural changes of the signal, or adversarial
training asks the encoder to ignore the signal itself. `adv_dprime_epsilon="auto_sig"` sets

    ε_train = min( (2D)^{1/4},  x* · ε_sig(M_train) )

with the two remaining ideas of the note's calibration: ε_sig is ε_NN without its noise floor, and
the cap (2D)^{1/4} is ε_det for an observer who does not know the attack (blind detector). x* =
`adv_dprime_sig_fraction` = 0.24 was fixed retrospectively on Exp5–8 (no training): it is the mean
of 8 / ε_sig over the nine sessions for the difference-residual metric (DIFF8, the best fixed arm),
about 20 % below the supervised failure boundary x ≈ 0.31 (decoders broken at the smallest
evaluation budget when ε / ε_sig ≥ 0.31; stable when any session is left out). ε_sig depends on
the metric: whole residuals count the slow signal as noise (per mode ψ/(1+ψ) instead of the SNR
ψ), so on Perich ε_sig(difference) = 1.3–1.6 × ε_sig(whole) and ε_sig(regression) = only
1.03–1.18 × ε_sig(whole), which is why REG8 broke like SP8 in supervised CEBRA and DIFF8 did not.
Every member of a covariance pool gets its own budget at the same x*. Not captured by ε_sig: the
five Perich sessions C-RT6, M-RT3, T-RT1, T-RT4 and J-CO0 break first under every over-large
budget. They are also the five shortest recordings, but Exp9 ruled out the training length: SP8
(supervised) stayed broken in 15/15 runs at ~340 epochs (E1), while C-CO12 stayed robust when
truncated to 9,174 bins (E2) or trained for 6,000 iterations (E2b). The failure is a property of
the session's signal and noise structure; the size of the budget (ε_sig) does not predict it,
which pointed to the *direction* of the training perturbations. Exp9 and Exp10 answered it the
other way: the size, but measured against the *behavioural* signal. AUTO_SIG rescued four of the
five sessions; M-RT3, the fifth, has the smallest ε_beh / ε_sig of all sessions (0.36; the
behaviour explains 6.5 % of its activity variance). Over all supervised Exp8/Exp9 runs the
decoders broke when ε_train / ε_beh(M_train) ≥ 0.50 (AUC 0.97, against 0.86 for ε / ε_sig and 0.67
for the nominal ε; leave-one-session-out boundary 0.505–0.53), i.e. at the midpoint between two
behavioural states. Hence `auto_beh` for behaviour-supervised encoders (Section 6). A
stronger-attack check (100 APGD steps, 3 restarts) changed the half-damage thresholds of all
432 Exp5–9 models by ≤ 3 % and none of the paired ratios to PGD6.

## 6. Adversarial training (integration in `cebra/solver/base.py`)

"Drop d′-PGD into Madry-style AT or TRADES with a per-trial budget ε_i = min(ε*, ε_NN,i), i.e.,
instance-adaptive AT in the spirit of IAAT/MMA, with a curriculum from 0.25 up to ε*."

* `adv_epsilon_mode="dprime"` in `Solver` and `MultiobjectiveSolver`.
* `cebra/dprime/training.py::DprimeTrainer(solver, loader)` holds the state. In `fit()`, before
  the first step: read `loader.dataset.neural` (n_time, C) and labels (`continuous_index` /
  `discrete_index`), window = `offset.left + offset.right` bins; fit the NoiseModel (Layer 1),
  the GuardSet (Layer 3) on ≤ `adv_dprime_guard_fit_windows` training windows, classes, ε_NN
  (global quantile + per-index), the Kronecker check. Single-session only (clear error
  otherwise). `Solver.step` / `MultiobjectiveSolver.step` delegate to `DprimeTrainer.step` in
  d′ mode; the solvers provide the hooks `_dprime_forward`, `_dprime_split`, `_dprime_subset`
  and `_dprime_clean_stats`, so hybrid (behaviour + time) solvers sum both objectives in every
  loss, probability and decision.
* `adv_dprime_optimizer="random"` is the matched control of d′-PGD training: same metric, same
  budget (fixed, `auto_sig` or `auto_beh`), same Madry/TRADES update, but `δ = Σ^{1/2} z` with `z`
  uniform on the sphere `‖z‖ = ε` instead of the attack (the training generator draws `z`; the
  ε_det calibration of `auto` / `auto_blind` still attacks with APGD). It separates what the
  noise-aware geometry buys by itself (structured noise augmentation) from what the adversary
  adds.
* Batches carry the reference time indices: the single-session dataset returns an
  `IndexedBatch` (subclass of `Batch` with an extra `reference_index` slot); nothing else in
  CEBRA changes behaviour.
* ε*: `adv_dprime_epsilon="auto"` → calibrated after `adv_dprime_warmup × max_iterations` clean
  steps (ε_det needs the current model as the attacked decoder), using the current batch sorted
  by time (`reference_index`; earlier half = train, later half = held-out); a float → used as ε*
  directly (no warm-up, no detectors).
* `adv_dprime_epsilon="auto_blind"`: the same calibration, but the training budget is the ε_det
  of the clean-only anomaly detector alone (`eps_det_crossing(curve, key="ae_auc")`), bounded by
  ε_NN and not by ε_JND: the largest perturbation that an observer who does not know the attack
  cannot detect. The note's ε* = min(ε_JND, ε_NN, ε_det) remains the threat budget of the
  evaluation and is still reported (`epsilon.eps_star_note`), with `eps_det_blind` and
  `eps_energy_detector`. Motivation (C-CO12, Exp4): the anomaly detector stayed at AUC ≈ 0.5 up
  to d′ = 4 and crossed 0.55 near d′ ≈ 7.6, close to `(2D)^{1/4}` = 8.9 and to the best fixed
  training budgets (d′ ≈ 8), while ε* = 1 trained clearly worse.
* `adv_dprime_epsilon="auto_sig"`: set in `DprimeTrainer.__init__` from the training data alone
  (no warm-up, no detectors): `ε* = min(cap, adv_dprime_sig_fraction · ε_sig)` of the training
  metric (Section 5), with `cap = (2D)^{1/4}` (`adv_dprime_sig_cap="blind"`) or none
  (`"none"`), and ε_sig from `calibration.eps_signal(recording, Σ_s, Σ_t, adv_dprime_sig_lag)`.
  With a covariance pool every member k gets `ε_k = min(cap, x* · ε_sig(Σ_k ⊗ Σ_t))`, and the step
  uses ε_t · ε_k / ε_0 for the drawn member (the member is drawn before the budget; the generator
  stream is unchanged for all other modes). Stationary layer only. Reported in `epsilon`:
  `source`, `eps_star`, `eps_sig`, `sig_fraction`, `sig_lag`, `sig_cap`, `eps_cap`, `binding`
  (`"signal"` or `"blind_cap"`), `x_train` (= ε*/ε_sig), `eps_jnd`, `eps_nn` and `pool` (per member).
* `adv_dprime_epsilon="auto_beh"` (behaviour-supervised fits only: needs the continuous labels
  of `fit(X, y)`): `ε* = max(ε_JND, min(cap, adv_dprime_beh_fraction · ε_beh))` with ε_beh of the
  training metric from `calibration.behaviour_prediction` (lags `adv_dprime_beh_lags`,
  `adv_dprime_beh_features` random features, seed 0: the budget is a property of the data, the
  same for every training seed) and `calibration.eps_behaviour`; per pool member as `auto_sig`.
  x* = 0.363 is the DIFF8 calibration of `auto_sig` applied to ε_beh (the mean of 8 / ε_beh over
  the nine Perich sessions in the difference metric), ≈ 27 % below the boundary 0.50. The floor
  ε_JND also covers recordings without a detectable behavioural signal. Reported in `epsilon`:
  `source`, `eps_star`, `eps_beh`, `eps_sig`, `beh_fraction`, `x_train` (= ε*/ε_beh), `eps_cap`,
  `eps_floor`, `binding` (`"behaviour"`, `"blind_cap"` or `"floor_jnd"`), `behaviour_model`
  (held-out R², ridge penalty, settings) and `pool`.
* `adv_dprime_signal_projection` (`None` = off, `"jnd"`, or a number of modes): "run the d′-PGD
  attack restricted to the nuisance latent [...] adversarial training where the adversary can
  only move along directions the model has learned are nuisance" (Part 2 of the note), with the
  nuisance estimated from the data: `calibration.signal_projector` on the training recording,
  the metric's Σ_s (every pool member) and the Ledoit–Wolf noise covariance of the difference
  residuals; the step uses `noise.ProjectedColoring` (`δ = Σ^{1/2} P z`, `d′ = ‖P z‖`). The
  budget is unchanged. Stationary layer only; reported in `signal_projection` (removed modes and
  leading ψ per member). Motivation: whole residuals make the slow behavioural signal cheap for
  the attacker, so a behaviour-supervised encoder is trained to ignore it (SP8 and REG8 broke in
  5 and 4 of 9 supervised sessions, also under natural noise); the projection tests that
  mechanism at an unchanged budget and geometry.
* Curriculum: `ε_t = ε₀ + (ε* − ε₀) · min(1, progress / adv_dprime_curriculum)` with
  `ε₀ = min(0.25, ε*)`, progress = fraction of the post-warm-up steps.
* Per-trial budget (`adv_dprime_instance_adaptive=True`): `ε_i = min(ε_t, ε_NN,i)`.
* Coloring per step: Layer 1 (`adv_dprime_layer="stationary"`) or Layer 2 (`"trial_mask"`);
  leadfield coloring if a leadfield is given; Σ sampled uniformly from the pool if `cov_pool`.
* Objective: `"madry"` = the original ACORN structure (clean update, then an update on the d′
  adversarial reference); `"trades"` = one update on `InfoNCE(clean) + β·KL(p(x) ‖ p(x_adv))`
  where p is the softmax over the similarities of the reference to [positive, negatives], and
  the attack maximises that KL.
* End of `fit()`: robustness margin with `min_norm_ddn` on the last batch, decision = the positive
  is no longer above chance (`"chance"`, default) or no longer the most similar candidate
  (`"top1"`; with time-contrastive batches of thousands of negatives the clean top-1 already
  fails for about half the windows, so its margin is 0 for them). The search starts at
  `max(ε*, ε_JND)` (from ε* ≈ 0 the DDN norm could never grow to the boundary) and is
  scale-free (`relative_step`, `growth = 0.3`, Section 4). The margin is computed in three
  metrics: the run's own (`robustness_margin`, ratio to ε*) and the two
  common metrics below (`robustness_margin_reference`, `robustness_margin_isotropic`, ratio to
  ε_JND), which are the same for every run and so compare runs of different geometries.
* Common metrics (`common_metrics` in the report; the same as in the evaluation of Section 7):
  `"reference"` = the note's default Ledoit–Wolf ⊗ Welch metric on the label-free `"whole"`
  residuals of the training recording, and `"isotropic"` = `‖δ‖₂ / σ̄` with σ̄² the mean
  variance of these residuals (raw L2 in noise-SD units; `isotropic_sigma` = σ̄). They do not
  depend on the run's own residual mode, estimators or layer. An equal nominal
  d′ is not an equal perturbation across geometries: the noise-aware ball puts its budget along
  the high-variance modes, so at the same ε it is larger in input units than the isotropic one.
* `training.realized` in the report: the realised training perturbations of the sampled
  references (accepted ones) in all units — `dprime_training`, `dprime_reference`,
  `dprime_isotropic`, `raw_l2` (input units, whole window), `rms_per_entry` (`raw_l2 / √(C·T)`)
  and `loss_gain` (attack objective minus the unperturbed one); mean / q10 / median / q90 each.
  Runs of different geometries can then be compared at a matched realised size or attack
  strength instead of a matched nominal ε.
* Randomness: training attacks use `torch.Generator(adv_dprime_seed)`, the ε_det calibration
  its own generator (`adv_dprime_seed + 1`), and the detectors fork the global RNG, so the
  training stream does not depend on whether the calibration ran ("auto" with ε* = 1 trains
  bit-identically to a fixed ε = 1 on the CPU; tested).
* `adv_dprime_curriculum = 0`: no curriculum (ε* from the first adversarial step).
* `training.epsilon_per_reference` in the report: min / q10 / median / q90 / max of the
  per-reference budgets ε_i actually used and the fraction bound by ε_NN,i.
* `eps_nn.noise_floor_sqrt_2D`: two independent noise draws differ by ≈ √(2D) (D = C·T) in the
  whitened metric, so ε_NN ≈ √(2D) ≫ ε_JND for high-dimensional windows and the per-trial bound
  `ε_i = min(ε_t, ε_NN,i)` cannot bind (e.g. C = 86, T = 36: √(2D) ≈ 79, ε_NN ≈ 71).
* Report: `solver.dprime_report` (dict, plain Python types only) → `cebra.CEBRA.dprime_report_`
  after fit (also saved / loaded with `save(..., backend="sklearn")`). Per-step stats in
  `solver.log`: `dprime_eps`, `dprime_mean`, `dprime_accept` (+ `dprime_trades_kl`).

### Reproducibility of CEBRA's batches

Upstream CEBRA seeds every sampler with `torch.Generator.seed()` (non-deterministic; see
`cebra/distributions/base.py`), so two fits after the same `torch.manual_seed` see different
batches: "identical" configurations differ by their batch sequence (on C-CO12 about ±0.01 R²).
This fork draws the sampler seed from the global torch RNG instead: a fit is reproducible under
`torch.manual_seed` (bit-identical on the CPU; GPU kernels may still add tiny differences), and
the arms of a comparison with the same seed see the same batches (the sampler has its own
generator, so attacks and dropout do not shift it). The algorithm of every mode is unchanged.

## 7. Evaluation of any fitted model → `cebra/dprime/evaluation.py`

"Run a minimum-norm attack (FMN/DDN in the whitened metric) to measure each trial's distance to
the decision boundary in d′ [...] Reporting this margin across datasets and models is arguably
the headline result", "ASR vs ε(d′) overlaid across datasets on one axis", and "evaluate with the
min-norm attack alongside PGD to rule out gradient masking". `evaluate_decoding(encoder,
decoder, x_train, x_eval, y_eval)` does this for any fitted single-session `cebra.CEBRA` (clean,
constant-ε PGD or d′) followed by a differentiable behaviour decoder (`torch.nn.Module`
embedding → behaviour), on held-out data, in the two common metrics fitted on `x_train`
(`"reference"`: Ledoit–Wolf ⊗ Welch; `"isotropic"`: `‖δ‖₂ / σ̄`, raw L2 radius = σ̄·ε):

* `robust_r2`: R² of `decoder(encoder(x + δ))`, every window attacked by d′-APGD (`steps`)
  maximising its standardised squared decoding error (the loss of the per-output R²) with
  `‖δ‖_Σ ≤ ε`, for every ε of `epsilons` (default 0.5 … 16); `eps_at_half_r2` = the ε where it
  falls to half the clean R² (log interpolation). The budgets run in increasing order, each
  APGD warm-started at the solution of the previous budget, and every window keeps its worst
  perturbation over all budgets ≤ ε (all feasible at ε): `r2` is this monotone worst case,
  `r2_single` the R² of the budget's own run (a non-monotone `r2_single` curve flags an
  optimisation problem of the attack, e.g. at large ε). Stronger-attack check: `restarts` > 1
  adds APGD restarts from random points of radius ε/2 (own generator, seed + 1, so the noise
  draws are unchanged) and keeps each window's best, so the curve can only get stronger;
  `margins=False` skips the DDN margins. The defaults (`restarts=1`, `margins=True`) give the
  original report bit for bit.
* `refine=k` (default 0, off) measures ε½ instead of interpolating it: the bracket of the
  crossing (last budget above half the clean R², first one at or below) is bisected `k` times in
  log ε, each new budget attacked once more over all windows, warm-started at the bracket's
  lower end and keeping its worst case like the curve (4 steps: ±4 %). If the smallest budget
  already halves the R², the budgets are first halved from the clean state down to
  `refine_floor` (default smallest budget / 16), so the former floor values (ε½ = 0.5) become
  measurements. `eps_at_half_r2_refined` plus `half_r2_refined` = {epsilon, status `"ok"` /
  `"below_floor"` / `"above_grid"`, bracket or bound, points}; the grid curve is unchanged. Why:
  on short recordings the robust R² can fall from just above half at ε = 2 to strongly negative
  values at ε = 4 (Exp11: 42 % of the reference ε½ within 7 % above a grid point, against 11 %
  in Exp5–8), and 18 of 210 supervised Exp11 runs were censored at the smallest budget.
* `behaviour_train=y_train` (default None) adds `eps_beh` per metric, the behavioural separation
  of the training recording in that metric (`calibration.eps_behaviour` of the cross-fitted
  `behaviour_prediction`), and `kappa` = ε½ / ε_beh (refined ε½ when available): robustness in
  units of the distance between behavioural states. On Perich, ε½ in the reference metric tracks
  ε_beh across sessions for every training method (9 sessions of Exp5–8: r = 0.92–0.96 in log–log
  against 0.15–0.46 for ε_sig), with a constant per method: κ(DIFF8) = 0.131 in Exp8 and again
  0.131 in the 10 new sessions of Exp11 (supervised; time-only 0.122 / 0.123), κ(PGD6) ≈ 0.10–0.11,
  κ(CLEAN) ≈ 0.07. For the Bayes-optimal linear decoder of a linear-Gaussian model, ε½ / ε_beh
  rises from 0.25 to 0.5 with the SNR: the same ½ as the training-budget boundary of `auto_beh`.
* `decoding_margin`: per window (`margin_windows`, evenly spaced) the minimum d′ (DDN) that
  moves the decoded behaviour by `shift_threshold` behaviour SDs (RMS over the outputs; default
  0.5), summarised by `robustness_margin` with ε_JND as the reference.
* `contrastive_margin`: the training decision (`"chance"`: the window one time offset later is no
  longer identified better than a random window) on held-out windows.
* `natural_noise_r2`: R² with one extra draw of the metric's noise (d′ ≈ √(C·T)).

The windows are the encoder's receptive fields edge-padded exactly like `CEBRA.transform`
(tested: identical embeddings), the encoder and decoder run in eval mode (modes restored), and
the result is JSON-safe. A few seconds to a minute per model on a GPU.

`evaluate_detectability(encoder, decoder, x_train, x_eval, y_eval)`: which threat geometry is the
stealthier one? Training with one geometry makes a decoder robust to attacks of that geometry
(Exp5: noise-aware training wins against noise-shaped attacks and loses against isotropic ones in
9/9 sessions), so the threat model itself needs the note's criterion, detectability. For each
common metric and budget, the same decoder attack (APGD on the standardised squared error,
warm-started along the budgets, so every window's error is non-decreasing in ε) is applied to
`n_windows` evenly spaced held-out windows; the earlier half trains the supervised detector and
the later half is the test set of:
* `r2` (damage), `ae_auc` (the calibration's clean-only autoencoder, fitted on clean training
  windows: a blind detector), `cnn_auc` (the calibration's CNN, trained on clean vs attacked
  windows of the earlier half: it knows the attack distribution), and the medians of the realised
  `dprime_reference`, `dprime_isotropic` and `raw_l2`;
* `at_half_r2`: all of these interpolated (log ε) at the budget that halves the clean R², so the
  geometries are compared at equal damage: the stealthier threat does the same damage with lower
  detector AUCs. `reeval_detectability.py` (next to the fork) runs it on saved models.

```python
from cebra.dprime import evaluation
robust = evaluation.evaluate_decoding(encoder, decoder, x_train, x_valid, y_valid, seed=42)
robust["reference"]["robust_r2"]          # [{epsilon, r2, r2_single, dprime_mean, raw_l2_median}, ...]
robust["reference"]["decoding_margin"]    # {median, q10, ..., ratio = median / ε_JND, ...}
```

## 8. Extensions

* **Leadfield** (`adv_dprime_leadfield`, (C, S) array): `δ = L·s + n`, budget in source space
  (`‖s‖₂ ≤ ε`, s temporally coloured), `n` = natural sensor noise sampled from the NoiseModel
  with scale `adv_dprime_leadfield_noise` (0 = none) ("source-space perturbation plus sensor noise
  with the budget in source space").
* **Spike trains**: `adv_dprime_temporal="vanrossum"` (van Rossum metric, τ fitted to the data).
  Discrete jitter/insertion/deletion are not differentiable and are not implemented.

## 9. Risks addressed

Tyler estimator (heavy tails); shrinkage (few trials); Kronecker check; detectors trained across
attacks and evaluated on held-out data; min-norm attack alongside PGD (gradient masking).

## 10. New `cebra.CEBRA(...)` arguments

All existing ACORN arguments are unchanged (`training_mode`, `adv_epsilon`, `adv_alpha`,
`adv_steps`, `attack_norm`, ...). The d′ mode is enabled by
`training_mode="adversarial", adv_epsilon_mode="dprime"`; `adv_steps` is then the number of
d′-PGD steps, and `adv_epsilon` / `adv_alpha` / `attack_norm` are not used.

| Argument | Default | Meaning (note section) |
|---|---|---|
| `adv_epsilon_mode` | `"constant"` | `"constant"`: original ACORN PGD (bit-identical); `"dprime"`: this fork |
| **ε (Sec. 5)** | | |
| `adv_dprime_epsilon` | `"auto"` | `"auto"`: ε* = min(ε_JND, ε_NN, ε_det) calibrated after the warm-up; `"auto_blind"`: the anomaly-detector ε_det (log-interpolated) bounded by ε_NN; `"auto_sig"`: min((2D)^{1/4}, x*·ε_sig) of the training metric, from the data (Section 5); `"auto_beh"` (supervised): max(ε_JND, min((2D)^{1/4}, x*·ε_beh)); a float: ε* in d′ units |
| `adv_dprime_jnd` | `1.0` | ε_JND (ideal-observer threshold) |
| `adv_dprime_sig_fraction` | `0.24` | x* of `auto_sig` (fraction of the signal separation ε_sig) |
| `adv_dprime_sig_lag` | `1` | lag of the signal proxy of ε_sig (1: difference residuals) |
| `adv_dprime_sig_cap` | `"blind"` | cap of `auto_sig`: `"blind"` = (2D)^{1/4}, `"none"` |
| `adv_dprime_beh_fraction` | `0.363` | x* of `auto_beh` (fraction of the behavioural separation ε_beh) |
| `adv_dprime_beh_lags` | `(−8, −4, 0, 4, 8)` | behaviour lags (bins) of the behaviour model of `auto_beh` |
| `adv_dprime_beh_features` | `400` | random Fourier features of the behaviour model (0: linear) |
| `adv_dprime_signal_projection` | `None` | nuisance-only attack: `None` (off), `"jnd"` (remove the signal modes with ψ > max(1/T, 1.2·√(2C/n))), or a number of leading signal modes |
| `adv_dprime_nn_quantile` | `0.1` | quantile of the same-class NN whitened distances (ε_NN) |
| `adv_dprime_nn_bank` | `2000` | bank of candidate neighbours per class |
| `adv_dprime_num_classes` | `8` | k-means classes of continuous labels ("same-class") |
| `adv_dprime_det_auc` | `0.55` | maximum detector AUC of ε_det |
| `adv_dprime_det_grid` | `(0.0625, …, 16.0)` | ε grid of the detection curve |
| `adv_dprime_det_steps` | `300` | training steps of each detector (CNN, autoencoder) |
| `adv_dprime_warmup` | `0.1` | fraction of `max_iterations` of clean warm-up before ε_det ("auto" only) |
| `adv_dprime_curriculum` | `0.5` | fraction of the remaining steps of the curriculum min(0.25, ε*) → ε* |
| `adv_dprime_instance_adaptive` | `True` | per-trial budget ε_i = min(ε_t, ε_NN,i) (IAAT/MMA) |
| **Layer 1 (Sec. 1)** | | |
| `adv_dprime_residuals` | `"auto"` | `"auto"`, `"whole"`, `"class_mean"`, `"regression"`, `"difference"` (label-free fast fluctuations; with `temporal="white"`) |
| `adv_dprime_spatial` | `"ledoit_wolf"` | `"ledoit_wolf"`, `"oas"`, `"empirical"`, `"tyler"`, `"isotropic"` (control) |
| `adv_dprime_temporal` | `"welch"` | `"welch"`, `"ar"`, `"white"`, `"vanrossum"` |
| `adv_dprime_ar_order` | `4` | p of the AR(p) fit |
| `adv_dprime_vanrossum_tau` | `"auto"` | τ (bins) of the van Rossum metric, `"auto"` = fitted |
| `adv_dprime_kronecker_channels` | `8` | channels of the full-vs-Kronecker covariance check |
| `adv_dprime_cov_pool` | `None` | extra spatial covariances, one sampled per step: (C, C) arrays or estimator names applied to the recording (e.g. `("isotropic",)`: the pool {Σ_spatial, σ̄²I}) |
| **Layer 2 (Sec. 2)** | | |
| `adv_dprime_layer` | `"stationary"` | `"stationary"` (Layer 1) or `"trial_mask"` (Layer 2) |
| `adv_dprime_stft_nfft` | `16` | STFT size of the trial mask |
| `adv_dprime_stft_hop` | `4` | STFT hop |
| `adv_dprime_multitaper_nw` | `2.0` | DPSS NW (trial mask and spectral guards) |
| `adv_dprime_multitaper_k` | `3` | number of DPSS tapers |
| **Layer 3 (Sec. 3)** | | |
| `adv_dprime_guards` | `("band_power", "aperiodic", "riemann", "artifact")` | subset of these + `"erp"` |
| `adv_dprime_guard_mode` | `"backtrack"` | `"backtrack"` (+ final reject), `"final"`, `"off"` |
| `adv_dprime_guard_tau` | `1.0` | τ of "change ≤ τ × within-class SD" |
| `adv_dprime_guard_bands` | `None` | bands (units of the sampling rate); None = default bands |
| `adv_dprime_sampling_rate` | `1.0` | sampling rate of the bins |
| `adv_dprime_erp_window` | `None` | (start, stop) bins of the ERP guard (needed for `"erp"`; for continuous ERP data — on integer spike counts the peak latency of tied values jumps under any δ) |
| `adv_dprime_riemann_channels` | `32` | highest-variance channels of the Riemannian guard |
| `adv_dprime_artifact_rate` | `0.01` | clean rejection rate of the artifact thresholds |
| `adv_dprime_max_backtrack` | `3` | step halvings per PGD step |
| `adv_dprime_soft_riemann` | `0.0` | weight of the soft Riemannian penalty (0 = off) |
| `adv_dprime_guard_fit_windows` | `4096` | training windows used to fit the guards |
| **Attack / training (Sec. 4, 6)** | | |
| `adv_dprime_optimizer` | `"apgd"` | `"apgd"`, `"pgd"` or `"random"` (control: a uniformly random direction on the d′ sphere of radius ε, no optimisation; needs the guards off) |
| `adv_dprime_restarts` | `1` | restarts (≥ 1 random) |
| `adv_dprime_objective` | `"madry"` | `"madry"` or `"trades"` |
| `adv_dprime_trades_beta` | `6.0` | β of TRADES |
| **Extensions (Sec. 8)** | | |
| `adv_dprime_leadfield` | `None` | (C, S) leadfield: δ = L·s + n, budget in source space |
| `adv_dprime_leadfield_noise` | `0.0` | scale of the sensor noise n |
| **Report** | | |
| `adv_dprime_margin_decision` | `"chance"` | decision of the min-norm attack: `"chance"` or `"top1"` |
| `adv_dprime_margin_steps` | `100` | DDN steps of the robustness margin |
| `adv_dprime_seed` | `0` | seed of all d′ randomness |

After `fit`, `model.dprime_report_` holds: `settings`, `layer`, `noise_model` (residual mode,
estimators, Kronecker check, noise std), `eps_nn`, `guards` (tolerances, spectrum, disabled
guards), `epsilon` (ε_JND, ε_NN, ε_det + status, detection curve, ε*, which term binds),
`training` (mean d′, accept rate, ε_NN binding rate, backtracks, budget quantiles, realised
sizes in common units), `common_metrics`, `robustness_margin` (median d′ to the boundary,
quantiles, ratio = median / ε*) and `robustness_margin_reference` / `_isotropic` (the same in
the common metrics, ratio = median / ε_JND).

### Example

```python
import cebra

model = cebra.CEBRA(
    model_architecture="offset36-model-more-dropout",
    batch_size=512, max_iterations=10000, output_dimension=8,
    training_mode="adversarial", adv_steps=10,
    adv_epsilon_mode="dprime",
    adv_dprime_epsilon="auto",          # ε* = min(ε_JND, ε_NN, ε_det)
    adv_dprime_layer="stationary",      # or "trial_mask"
    adv_dprime_spatial="tyler",
    adv_dprime_temporal="welch",
    adv_dprime_objective="trades",
)
model.fit(neural_train, behavior_train)
print(model.dprime_report_["epsilon"]["eps_star"], model.dprime_report_["robustness_margin"]["ratio"])
model.save("model.pt", backend="sklearn")       # dprime_report_ is saved too
model = cebra.CEBRA.load("model.pt")
```

### Not implemented (and why)

* ICLabel (needs an ICA of an EEG montage; no analogue for spike data).
* Discrete spike jitter / insertion / deletion (not differentiable; the van Rossum metric is the
  differentiable spike-train extension that is implemented).
* Multi-session datasets (the noise model and ε_NN are per recording; a clear error is raised).
